package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerProviderConstants.class */
public final class ServiceWorkerProviderConstants {
    public static final String NAVIGATION_SERVICE_WORKER_SPEC = "navigation:service_worker";

    private ServiceWorkerProviderConstants() {
    }
}
