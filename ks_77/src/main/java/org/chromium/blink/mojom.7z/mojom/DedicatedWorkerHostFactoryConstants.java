package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactoryConstants.class */
public final class DedicatedWorkerHostFactoryConstants {
    public static final String NAVIGATION_DEDICATED_WORKER_SPEC = "navigation:dedicated_worker";

    private DedicatedWorkerHostFactoryConstants() {
    }
}
