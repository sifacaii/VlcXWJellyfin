package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerObjectConstants.class */
public final class ServiceWorkerObjectConstants {
    public static final long INVALID_SERVICE_WORKER_VERSION_ID = -1;

    private ServiceWorkerObjectConstants() {
    }
}
