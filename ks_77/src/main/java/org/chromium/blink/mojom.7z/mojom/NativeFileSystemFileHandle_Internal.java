package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.NativeFileSystemFileHandle;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.InterfaceRequest;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal.class */
class NativeFileSystemFileHandle_Internal {
    public static final Interface.Manager<NativeFileSystemFileHandle, NativeFileSystemFileHandle.Proxy> MANAGER = new Interface.Manager<NativeFileSystemFileHandle, NativeFileSystemFileHandle.Proxy>() { // from class: org.chromium.blink.mojom.NativeFileSystemFileHandle_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.NativeFileSystemFileHandle";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public NativeFileSystemFileHandle.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, NativeFileSystemFileHandle impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public NativeFileSystemFileHandle[] buildArray(int size) {
            return new NativeFileSystemFileHandle[size];
        }
    };
    private static final int GET_PERMISSION_STATUS_ORDINAL = 0;
    private static final int REQUEST_PERMISSION_ORDINAL = 1;
    private static final int AS_BLOB_ORDINAL = 2;
    private static final int REMOVE_ORDINAL = 3;
    private static final int CREATE_FILE_WRITER_ORDINAL = 4;
    private static final int TRANSFER_ORDINAL = 5;

    NativeFileSystemFileHandle_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements NativeFileSystemFileHandle.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void getPermissionStatus(boolean writable, NativeFileSystemFileHandle.GetPermissionStatusResponse callback) {
            NativeFileSystemFileHandleGetPermissionStatusParams _message = new NativeFileSystemFileHandleGetPermissionStatusParams();
            _message.writable = writable;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new NativeFileSystemFileHandleGetPermissionStatusResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void requestPermission(boolean writable, NativeFileSystemFileHandle.RequestPermissionResponse callback) {
            NativeFileSystemFileHandleRequestPermissionParams _message = new NativeFileSystemFileHandleRequestPermissionParams();
            _message.writable = writable;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new NativeFileSystemFileHandleRequestPermissionResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void asBlob(NativeFileSystemFileHandle.AsBlobResponse callback) {
            NativeFileSystemFileHandleAsBlobParams _message = new NativeFileSystemFileHandleAsBlobParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new NativeFileSystemFileHandleAsBlobResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void remove(NativeFileSystemFileHandle.RemoveResponse callback) {
            NativeFileSystemFileHandleRemoveParams _message = new NativeFileSystemFileHandleRemoveParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new NativeFileSystemFileHandleRemoveResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void createFileWriter(NativeFileSystemFileHandle.CreateFileWriterResponse callback) {
            NativeFileSystemFileHandleCreateFileWriterParams _message = new NativeFileSystemFileHandleCreateFileWriterParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4, 1, 0L)), new NativeFileSystemFileHandleCreateFileWriterResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileHandle
        public void transfer(InterfaceRequest<NativeFileSystemTransferToken> token) {
            NativeFileSystemFileHandleTransferParams _message = new NativeFileSystemFileHandleTransferParams();
            _message.token = token;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<NativeFileSystemFileHandle> {
        Stub(Core core, NativeFileSystemFileHandle impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(NativeFileSystemFileHandle_Internal.MANAGER, messageWithHeader);
                    case 5:
                        NativeFileSystemFileHandleTransferParams data = NativeFileSystemFileHandleTransferParams.deserialize(messageWithHeader.getPayload());
                        getImpl().transfer(data.token);
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), NativeFileSystemFileHandle_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        NativeFileSystemFileHandleGetPermissionStatusParams data = NativeFileSystemFileHandleGetPermissionStatusParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getPermissionStatus(data.writable, new NativeFileSystemFileHandleGetPermissionStatusResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        NativeFileSystemFileHandleRequestPermissionParams data2 = NativeFileSystemFileHandleRequestPermissionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().requestPermission(data2.writable, new NativeFileSystemFileHandleRequestPermissionResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        NativeFileSystemFileHandleAsBlobParams.deserialize(messageWithHeader.getPayload());
                        getImpl().asBlob(new NativeFileSystemFileHandleAsBlobResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 3:
                        NativeFileSystemFileHandleRemoveParams.deserialize(messageWithHeader.getPayload());
                        getImpl().remove(new NativeFileSystemFileHandleRemoveResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 4:
                        NativeFileSystemFileHandleCreateFileWriterParams.deserialize(messageWithHeader.getPayload());
                        getImpl().createFileWriter(new NativeFileSystemFileHandleCreateFileWriterResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleGetPermissionStatusParams.class */
    static final class NativeFileSystemFileHandleGetPermissionStatusParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean writable;

        private NativeFileSystemFileHandleGetPermissionStatusParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleGetPermissionStatusParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleGetPermissionStatusParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleGetPermissionStatusParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleGetPermissionStatusParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleGetPermissionStatusParams result = new NativeFileSystemFileHandleGetPermissionStatusParams(elementsOrVersion);
                result.writable = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.writable, 8, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleGetPermissionStatusResponseParams.class */
    public static final class NativeFileSystemFileHandleGetPermissionStatusResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;

        private NativeFileSystemFileHandleGetPermissionStatusResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleGetPermissionStatusResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleGetPermissionStatusResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleGetPermissionStatusResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleGetPermissionStatusResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleGetPermissionStatusResponseParams result = new NativeFileSystemFileHandleGetPermissionStatusResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                PermissionStatus.validate(result.status);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleGetPermissionStatusResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileHandleGetPermissionStatusResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileHandle.GetPermissionStatusResponse mCallback;

        NativeFileSystemFileHandleGetPermissionStatusResponseParamsForwardToCallback(NativeFileSystemFileHandle.GetPermissionStatusResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                NativeFileSystemFileHandleGetPermissionStatusResponseParams response = NativeFileSystemFileHandleGetPermissionStatusResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleGetPermissionStatusResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileHandleGetPermissionStatusResponseParamsProxyToResponder implements NativeFileSystemFileHandle.GetPermissionStatusResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileHandleGetPermissionStatusResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer status) {
            NativeFileSystemFileHandleGetPermissionStatusResponseParams _response = new NativeFileSystemFileHandleGetPermissionStatusResponseParams();
            _response.status = status.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRequestPermissionParams.class */
    static final class NativeFileSystemFileHandleRequestPermissionParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean writable;

        private NativeFileSystemFileHandleRequestPermissionParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleRequestPermissionParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleRequestPermissionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleRequestPermissionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleRequestPermissionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleRequestPermissionParams result = new NativeFileSystemFileHandleRequestPermissionParams(elementsOrVersion);
                result.writable = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.writable, 8, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRequestPermissionResponseParams.class */
    public static final class NativeFileSystemFileHandleRequestPermissionResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;

        private NativeFileSystemFileHandleRequestPermissionResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleRequestPermissionResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleRequestPermissionResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleRequestPermissionResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleRequestPermissionResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleRequestPermissionResponseParams result = new NativeFileSystemFileHandleRequestPermissionResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                PermissionStatus.validate(result.status);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRequestPermissionResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileHandleRequestPermissionResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileHandle.RequestPermissionResponse mCallback;

        NativeFileSystemFileHandleRequestPermissionResponseParamsForwardToCallback(NativeFileSystemFileHandle.RequestPermissionResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                NativeFileSystemFileHandleRequestPermissionResponseParams response = NativeFileSystemFileHandleRequestPermissionResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRequestPermissionResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileHandleRequestPermissionResponseParamsProxyToResponder implements NativeFileSystemFileHandle.RequestPermissionResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileHandleRequestPermissionResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer status) {
            NativeFileSystemFileHandleRequestPermissionResponseParams _response = new NativeFileSystemFileHandleRequestPermissionResponseParams();
            _response.status = status.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleAsBlobParams.class */
    static final class NativeFileSystemFileHandleAsBlobParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemFileHandleAsBlobParams(int version) {
            super(8, version);
        }

        public NativeFileSystemFileHandleAsBlobParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleAsBlobParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleAsBlobParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleAsBlobParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleAsBlobParams result = new NativeFileSystemFileHandleAsBlobParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleAsBlobResponseParams.class */
    public static final class NativeFileSystemFileHandleAsBlobResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public SerializedBlob blob;

        private NativeFileSystemFileHandleAsBlobResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemFileHandleAsBlobResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleAsBlobResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleAsBlobResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleAsBlobResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleAsBlobResponseParams result = new NativeFileSystemFileHandleAsBlobResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, true);
                result.blob = SerializedBlob.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode((Struct) this.blob, 16, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleAsBlobResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileHandleAsBlobResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileHandle.AsBlobResponse mCallback;

        NativeFileSystemFileHandleAsBlobResponseParamsForwardToCallback(NativeFileSystemFileHandle.AsBlobResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                NativeFileSystemFileHandleAsBlobResponseParams response = NativeFileSystemFileHandleAsBlobResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.blob);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleAsBlobResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileHandleAsBlobResponseParamsProxyToResponder implements NativeFileSystemFileHandle.AsBlobResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileHandleAsBlobResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, SerializedBlob blob) {
            NativeFileSystemFileHandleAsBlobResponseParams _response = new NativeFileSystemFileHandleAsBlobResponseParams();
            _response.result = result;
            _response.blob = blob;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRemoveParams.class */
    static final class NativeFileSystemFileHandleRemoveParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemFileHandleRemoveParams(int version) {
            super(8, version);
        }

        public NativeFileSystemFileHandleRemoveParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleRemoveParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleRemoveParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleRemoveParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleRemoveParams result = new NativeFileSystemFileHandleRemoveParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRemoveResponseParams.class */
    public static final class NativeFileSystemFileHandleRemoveResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;

        private NativeFileSystemFileHandleRemoveResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleRemoveResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleRemoveResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleRemoveResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleRemoveResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleRemoveResponseParams result = new NativeFileSystemFileHandleRemoveResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRemoveResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileHandleRemoveResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileHandle.RemoveResponse mCallback;

        NativeFileSystemFileHandleRemoveResponseParamsForwardToCallback(NativeFileSystemFileHandle.RemoveResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                NativeFileSystemFileHandleRemoveResponseParams response = NativeFileSystemFileHandleRemoveResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleRemoveResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileHandleRemoveResponseParamsProxyToResponder implements NativeFileSystemFileHandle.RemoveResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileHandleRemoveResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(NativeFileSystemError result) {
            NativeFileSystemFileHandleRemoveResponseParams _response = new NativeFileSystemFileHandleRemoveResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleCreateFileWriterParams.class */
    static final class NativeFileSystemFileHandleCreateFileWriterParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemFileHandleCreateFileWriterParams(int version) {
            super(8, version);
        }

        public NativeFileSystemFileHandleCreateFileWriterParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleCreateFileWriterParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleCreateFileWriterParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleCreateFileWriterParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleCreateFileWriterParams result = new NativeFileSystemFileHandleCreateFileWriterParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleCreateFileWriterResponseParams.class */
    public static final class NativeFileSystemFileHandleCreateFileWriterResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemFileWriter writer;

        private NativeFileSystemFileHandleCreateFileWriterResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemFileHandleCreateFileWriterResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleCreateFileWriterResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleCreateFileWriterResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleCreateFileWriterResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleCreateFileWriterResponseParams result = new NativeFileSystemFileHandleCreateFileWriterResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.writer = (NativeFileSystemFileWriter) decoder0.readServiceInterface(16, true, NativeFileSystemFileWriter.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode((Encoder) this.writer, 16, true, (Interface.Manager<Encoder, ?>) NativeFileSystemFileWriter.MANAGER);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleCreateFileWriterResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileHandleCreateFileWriterResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileHandle.CreateFileWriterResponse mCallback;

        NativeFileSystemFileHandleCreateFileWriterResponseParamsForwardToCallback(NativeFileSystemFileHandle.CreateFileWriterResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(4, 2)) {
                    return false;
                }
                NativeFileSystemFileHandleCreateFileWriterResponseParams response = NativeFileSystemFileHandleCreateFileWriterResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.writer);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleCreateFileWriterResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileHandleCreateFileWriterResponseParamsProxyToResponder implements NativeFileSystemFileHandle.CreateFileWriterResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileHandleCreateFileWriterResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemFileWriter writer) {
            NativeFileSystemFileHandleCreateFileWriterResponseParams _response = new NativeFileSystemFileHandleCreateFileWriterResponseParams();
            _response.result = result;
            _response.writer = writer;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(4, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileHandle_Internal$NativeFileSystemFileHandleTransferParams.class */
    static final class NativeFileSystemFileHandleTransferParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public InterfaceRequest<NativeFileSystemTransferToken> token;

        private NativeFileSystemFileHandleTransferParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileHandleTransferParams() {
            this(0);
        }

        public static NativeFileSystemFileHandleTransferParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileHandleTransferParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileHandleTransferParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileHandleTransferParams result = new NativeFileSystemFileHandleTransferParams(elementsOrVersion);
                result.token = decoder0.readInterfaceRequest(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((InterfaceRequest) this.token, 8, false);
        }
    }
}
