package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerFactoryConstants.class */
public final class SharedWorkerFactoryConstants {
    public static final String NAVIGATION_SHARED_WORKER_SPEC = "navigation:shared_worker";

    private SharedWorkerFactoryConstants() {
    }
}
