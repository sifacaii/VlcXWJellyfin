package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.NativeFileSystemFileWriter;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.mojo.system.DataPipe;
import org.chromium.mojo.system.Handle;
import org.chromium.mojo.system.InvalidHandle;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal.class */
class NativeFileSystemFileWriter_Internal {
    public static final Interface.Manager<NativeFileSystemFileWriter, NativeFileSystemFileWriter.Proxy> MANAGER = new Interface.Manager<NativeFileSystemFileWriter, NativeFileSystemFileWriter.Proxy>() { // from class: org.chromium.blink.mojom.NativeFileSystemFileWriter_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.NativeFileSystemFileWriter";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public NativeFileSystemFileWriter.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, NativeFileSystemFileWriter impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public NativeFileSystemFileWriter[] buildArray(int size) {
            return new NativeFileSystemFileWriter[size];
        }
    };
    private static final int WRITE_ORDINAL = 0;
    private static final int WRITE_STREAM_ORDINAL = 1;
    private static final int TRUNCATE_ORDINAL = 2;
    private static final int CLOSE_ORDINAL = 3;

    NativeFileSystemFileWriter_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements NativeFileSystemFileWriter.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileWriter
        public void write(long offset, Blob data, NativeFileSystemFileWriter.WriteResponse callback) {
            NativeFileSystemFileWriterWriteParams _message = new NativeFileSystemFileWriterWriteParams();
            _message.offset = offset;
            _message.data = data;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new NativeFileSystemFileWriterWriteResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileWriter
        public void writeStream(long offset, DataPipe.ConsumerHandle stream, NativeFileSystemFileWriter.WriteStreamResponse callback) {
            NativeFileSystemFileWriterWriteStreamParams _message = new NativeFileSystemFileWriterWriteStreamParams();
            _message.offset = offset;
            _message.stream = stream;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new NativeFileSystemFileWriterWriteStreamResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileWriter
        public void truncate(long length, NativeFileSystemFileWriter.TruncateResponse callback) {
            NativeFileSystemFileWriterTruncateParams _message = new NativeFileSystemFileWriterTruncateParams();
            _message.length = length;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new NativeFileSystemFileWriterTruncateResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemFileWriter
        public void close(NativeFileSystemFileWriter.CloseResponse callback) {
            NativeFileSystemFileWriterCloseParams _message = new NativeFileSystemFileWriterCloseParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new NativeFileSystemFileWriterCloseResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<NativeFileSystemFileWriter> {
        Stub(Core core, NativeFileSystemFileWriter impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(NativeFileSystemFileWriter_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), NativeFileSystemFileWriter_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        NativeFileSystemFileWriterWriteParams data = NativeFileSystemFileWriterWriteParams.deserialize(messageWithHeader.getPayload());
                        getImpl().write(data.offset, data.data, new NativeFileSystemFileWriterWriteResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        NativeFileSystemFileWriterWriteStreamParams data2 = NativeFileSystemFileWriterWriteStreamParams.deserialize(messageWithHeader.getPayload());
                        getImpl().writeStream(data2.offset, data2.stream, new NativeFileSystemFileWriterWriteStreamResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        getImpl().truncate(NativeFileSystemFileWriterTruncateParams.deserialize(messageWithHeader.getPayload()).length, new NativeFileSystemFileWriterTruncateResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 3:
                        NativeFileSystemFileWriterCloseParams.deserialize(messageWithHeader.getPayload());
                        getImpl().close(new NativeFileSystemFileWriterCloseResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteParams.class */
    static final class NativeFileSystemFileWriterWriteParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public long offset;
        public Blob data;

        private NativeFileSystemFileWriterWriteParams(int version) {
            super(24, version);
        }

        public NativeFileSystemFileWriterWriteParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterWriteParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterWriteParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterWriteParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterWriteParams result = new NativeFileSystemFileWriterWriteParams(elementsOrVersion);
                result.offset = decoder0.readLong(8);
                result.data = (Blob) decoder0.readServiceInterface(16, false, Blob.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.offset, 8);
            encoder0.encode((Encoder) this.data, 16, false, (Interface.Manager<Encoder, ?>) Blob.MANAGER);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteResponseParams.class */
    public static final class NativeFileSystemFileWriterWriteResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public long bytesWritten;

        private NativeFileSystemFileWriterWriteResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemFileWriterWriteResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterWriteResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterWriteResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterWriteResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterWriteResponseParams result = new NativeFileSystemFileWriterWriteResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.bytesWritten = decoder0.readLong(16);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode(this.bytesWritten, 16);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileWriterWriteResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileWriter.WriteResponse mCallback;

        NativeFileSystemFileWriterWriteResponseParamsForwardToCallback(NativeFileSystemFileWriter.WriteResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                NativeFileSystemFileWriterWriteResponseParams response = NativeFileSystemFileWriterWriteResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, Long.valueOf(response.bytesWritten));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileWriterWriteResponseParamsProxyToResponder implements NativeFileSystemFileWriter.WriteResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileWriterWriteResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, Long bytesWritten) {
            NativeFileSystemFileWriterWriteResponseParams _response = new NativeFileSystemFileWriterWriteResponseParams();
            _response.result = result;
            _response.bytesWritten = bytesWritten.longValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteStreamParams.class */
    static final class NativeFileSystemFileWriterWriteStreamParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public long offset;
        public DataPipe.ConsumerHandle stream;

        private NativeFileSystemFileWriterWriteStreamParams(int version) {
            super(24, version);
            this.stream = InvalidHandle.INSTANCE;
        }

        public NativeFileSystemFileWriterWriteStreamParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterWriteStreamParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterWriteStreamParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterWriteStreamParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterWriteStreamParams result = new NativeFileSystemFileWriterWriteStreamParams(elementsOrVersion);
                result.offset = decoder0.readLong(8);
                result.stream = decoder0.readConsumerHandle(16, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.offset, 8);
            encoder0.encode((Handle) this.stream, 16, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteStreamResponseParams.class */
    public static final class NativeFileSystemFileWriterWriteStreamResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public long bytesWritten;

        private NativeFileSystemFileWriterWriteStreamResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemFileWriterWriteStreamResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterWriteStreamResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterWriteStreamResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterWriteStreamResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterWriteStreamResponseParams result = new NativeFileSystemFileWriterWriteStreamResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.bytesWritten = decoder0.readLong(16);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode(this.bytesWritten, 16);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteStreamResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileWriterWriteStreamResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileWriter.WriteStreamResponse mCallback;

        NativeFileSystemFileWriterWriteStreamResponseParamsForwardToCallback(NativeFileSystemFileWriter.WriteStreamResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                NativeFileSystemFileWriterWriteStreamResponseParams response = NativeFileSystemFileWriterWriteStreamResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, Long.valueOf(response.bytesWritten));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterWriteStreamResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileWriterWriteStreamResponseParamsProxyToResponder implements NativeFileSystemFileWriter.WriteStreamResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileWriterWriteStreamResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, Long bytesWritten) {
            NativeFileSystemFileWriterWriteStreamResponseParams _response = new NativeFileSystemFileWriterWriteStreamResponseParams();
            _response.result = result;
            _response.bytesWritten = bytesWritten.longValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterTruncateParams.class */
    static final class NativeFileSystemFileWriterTruncateParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public long length;

        private NativeFileSystemFileWriterTruncateParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileWriterTruncateParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterTruncateParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterTruncateParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterTruncateParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterTruncateParams result = new NativeFileSystemFileWriterTruncateParams(elementsOrVersion);
                result.length = decoder0.readLong(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.length, 8);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterTruncateResponseParams.class */
    public static final class NativeFileSystemFileWriterTruncateResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;

        private NativeFileSystemFileWriterTruncateResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileWriterTruncateResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterTruncateResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterTruncateResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterTruncateResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterTruncateResponseParams result = new NativeFileSystemFileWriterTruncateResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterTruncateResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileWriterTruncateResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileWriter.TruncateResponse mCallback;

        NativeFileSystemFileWriterTruncateResponseParamsForwardToCallback(NativeFileSystemFileWriter.TruncateResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                NativeFileSystemFileWriterTruncateResponseParams response = NativeFileSystemFileWriterTruncateResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterTruncateResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileWriterTruncateResponseParamsProxyToResponder implements NativeFileSystemFileWriter.TruncateResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileWriterTruncateResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(NativeFileSystemError result) {
            NativeFileSystemFileWriterTruncateResponseParams _response = new NativeFileSystemFileWriterTruncateResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterCloseParams.class */
    static final class NativeFileSystemFileWriterCloseParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemFileWriterCloseParams(int version) {
            super(8, version);
        }

        public NativeFileSystemFileWriterCloseParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterCloseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterCloseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterCloseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterCloseParams result = new NativeFileSystemFileWriterCloseParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterCloseResponseParams.class */
    public static final class NativeFileSystemFileWriterCloseResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;

        private NativeFileSystemFileWriterCloseResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemFileWriterCloseResponseParams() {
            this(0);
        }

        public static NativeFileSystemFileWriterCloseResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemFileWriterCloseResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemFileWriterCloseResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemFileWriterCloseResponseParams result = new NativeFileSystemFileWriterCloseResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterCloseResponseParamsForwardToCallback.class */
    static class NativeFileSystemFileWriterCloseResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemFileWriter.CloseResponse mCallback;

        NativeFileSystemFileWriterCloseResponseParamsForwardToCallback(NativeFileSystemFileWriter.CloseResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                NativeFileSystemFileWriterCloseResponseParams response = NativeFileSystemFileWriterCloseResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemFileWriter_Internal$NativeFileSystemFileWriterCloseResponseParamsProxyToResponder.class */
    static class NativeFileSystemFileWriterCloseResponseParamsProxyToResponder implements NativeFileSystemFileWriter.CloseResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemFileWriterCloseResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(NativeFileSystemError result) {
            NativeFileSystemFileWriterCloseResponseParams _response = new NativeFileSystemFileWriterCloseResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
