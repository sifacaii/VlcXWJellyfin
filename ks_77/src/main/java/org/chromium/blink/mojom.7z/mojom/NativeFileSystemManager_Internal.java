package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.NativeFileSystemManager;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal.class */
class NativeFileSystemManager_Internal {
    public static final Interface.Manager<NativeFileSystemManager, NativeFileSystemManager.Proxy> MANAGER = new Interface.Manager<NativeFileSystemManager, NativeFileSystemManager.Proxy>() { // from class: org.chromium.blink.mojom.NativeFileSystemManager_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.NativeFileSystemManager";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public NativeFileSystemManager.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, NativeFileSystemManager impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public NativeFileSystemManager[] buildArray(int size) {
            return new NativeFileSystemManager[size];
        }
    };
    private static final int GET_SANDBOXED_FILE_SYSTEM_ORDINAL = 0;
    private static final int CHOOSE_ENTRIES_ORDINAL = 1;

    NativeFileSystemManager_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements NativeFileSystemManager.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemManager
        public void getSandboxedFileSystem(NativeFileSystemManager.GetSandboxedFileSystemResponse callback) {
            NativeFileSystemManagerGetSandboxedFileSystemParams _message = new NativeFileSystemManagerGetSandboxedFileSystemParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new NativeFileSystemManagerGetSandboxedFileSystemResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemManager
        public void chooseEntries(int type, ChooseFileSystemEntryAcceptsOption[] accepts, boolean includeAcceptsAll, NativeFileSystemManager.ChooseEntriesResponse callback) {
            NativeFileSystemManagerChooseEntriesParams _message = new NativeFileSystemManagerChooseEntriesParams();
            _message.type = type;
            _message.accepts = accepts;
            _message.includeAcceptsAll = includeAcceptsAll;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new NativeFileSystemManagerChooseEntriesResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<NativeFileSystemManager> {
        Stub(Core core, NativeFileSystemManager impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(NativeFileSystemManager_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), NativeFileSystemManager_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        NativeFileSystemManagerGetSandboxedFileSystemParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getSandboxedFileSystem(new NativeFileSystemManagerGetSandboxedFileSystemResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        NativeFileSystemManagerChooseEntriesParams data = NativeFileSystemManagerChooseEntriesParams.deserialize(messageWithHeader.getPayload());
                        getImpl().chooseEntries(data.type, data.accepts, data.includeAcceptsAll, new NativeFileSystemManagerChooseEntriesResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerGetSandboxedFileSystemParams.class */
    static final class NativeFileSystemManagerGetSandboxedFileSystemParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemManagerGetSandboxedFileSystemParams(int version) {
            super(8, version);
        }

        public NativeFileSystemManagerGetSandboxedFileSystemParams() {
            this(0);
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemManagerGetSandboxedFileSystemParams result = new NativeFileSystemManagerGetSandboxedFileSystemParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerGetSandboxedFileSystemResponseParams.class */
    public static final class NativeFileSystemManagerGetSandboxedFileSystemResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemDirectoryHandle directory;

        private NativeFileSystemManagerGetSandboxedFileSystemResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemManagerGetSandboxedFileSystemResponseParams() {
            this(0);
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemManagerGetSandboxedFileSystemResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemManagerGetSandboxedFileSystemResponseParams result = new NativeFileSystemManagerGetSandboxedFileSystemResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.directory = (NativeFileSystemDirectoryHandle) decoder0.readServiceInterface(16, true, NativeFileSystemDirectoryHandle.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode((Encoder) this.directory, 16, true, (Interface.Manager<Encoder, ?>) NativeFileSystemDirectoryHandle.MANAGER);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerGetSandboxedFileSystemResponseParamsForwardToCallback.class */
    static class NativeFileSystemManagerGetSandboxedFileSystemResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemManager.GetSandboxedFileSystemResponse mCallback;

        NativeFileSystemManagerGetSandboxedFileSystemResponseParamsForwardToCallback(NativeFileSystemManager.GetSandboxedFileSystemResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                NativeFileSystemManagerGetSandboxedFileSystemResponseParams response = NativeFileSystemManagerGetSandboxedFileSystemResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.directory);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerGetSandboxedFileSystemResponseParamsProxyToResponder.class */
    static class NativeFileSystemManagerGetSandboxedFileSystemResponseParamsProxyToResponder implements NativeFileSystemManager.GetSandboxedFileSystemResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemManagerGetSandboxedFileSystemResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemDirectoryHandle directory) {
            NativeFileSystemManagerGetSandboxedFileSystemResponseParams _response = new NativeFileSystemManagerGetSandboxedFileSystemResponseParams();
            _response.result = result;
            _response.directory = directory;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerChooseEntriesParams.class */
    static final class NativeFileSystemManagerChooseEntriesParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int type;
        public ChooseFileSystemEntryAcceptsOption[] accepts;
        public boolean includeAcceptsAll;

        private NativeFileSystemManagerChooseEntriesParams(int version) {
            super(24, version);
        }

        public NativeFileSystemManagerChooseEntriesParams() {
            this(0);
        }

        public static NativeFileSystemManagerChooseEntriesParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemManagerChooseEntriesParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemManagerChooseEntriesParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemManagerChooseEntriesParams result = new NativeFileSystemManagerChooseEntriesParams(elementsOrVersion);
                result.type = decoder0.readInt(8);
                ChooseFileSystemEntryType.validate(result.type);
                result.includeAcceptsAll = decoder0.readBoolean(12, 0);
                Decoder decoder1 = decoder0.readPointer(16, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.accepts = new ChooseFileSystemEntryAcceptsOption[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.accepts[i1] = ChooseFileSystemEntryAcceptsOption.decode(decoder2);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.type, 8);
            encoder0.encode(this.includeAcceptsAll, 12, 0);
            if (this.accepts == null) {
                encoder0.encodeNullPointer(16, false);
                return;
            }
            Encoder encoder1 = encoder0.encodePointerArray(this.accepts.length, 16, -1);
            for (int i0 = 0; i0 < this.accepts.length; i0++) {
                encoder1.encode((Struct) this.accepts[i0], 8 + (8 * i0), false);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerChooseEntriesResponseParams.class */
    public static final class NativeFileSystemManagerChooseEntriesResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemEntry[] entries;

        private NativeFileSystemManagerChooseEntriesResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemManagerChooseEntriesResponseParams() {
            this(0);
        }

        public static NativeFileSystemManagerChooseEntriesResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemManagerChooseEntriesResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemManagerChooseEntriesResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemManagerChooseEntriesResponseParams result = new NativeFileSystemManagerChooseEntriesResponseParams(elementsOrVersion);
                result.result = NativeFileSystemError.decode(decoder0.readPointer(8, false));
                Decoder decoder1 = decoder0.readPointer(16, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.entries = new NativeFileSystemEntry[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.entries[i1] = NativeFileSystemEntry.decode(decoder2);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            if (this.entries == null) {
                encoder0.encodeNullPointer(16, false);
                return;
            }
            Encoder encoder1 = encoder0.encodePointerArray(this.entries.length, 16, -1);
            for (int i0 = 0; i0 < this.entries.length; i0++) {
                encoder1.encode((Struct) this.entries[i0], 8 + (8 * i0), false);
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerChooseEntriesResponseParamsForwardToCallback.class */
    static class NativeFileSystemManagerChooseEntriesResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemManager.ChooseEntriesResponse mCallback;

        NativeFileSystemManagerChooseEntriesResponseParamsForwardToCallback(NativeFileSystemManager.ChooseEntriesResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                NativeFileSystemManagerChooseEntriesResponseParams response = NativeFileSystemManagerChooseEntriesResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.entries);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemManager_Internal$NativeFileSystemManagerChooseEntriesResponseParamsProxyToResponder.class */
    static class NativeFileSystemManagerChooseEntriesResponseParamsProxyToResponder implements NativeFileSystemManager.ChooseEntriesResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemManagerChooseEntriesResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemEntry[] entries) {
            NativeFileSystemManagerChooseEntriesResponseParams _response = new NativeFileSystemManagerChooseEntriesResponseParams();
            _response.result = result;
            _response.entries = entries;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
