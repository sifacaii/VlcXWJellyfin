package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.EmbeddedWorkerInstanceHost;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.mojo_base.mojom.String16;
import org.chromium.url.mojom.Url;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal.class */
class EmbeddedWorkerInstanceHost_Internal {
    public static final Interface.Manager<EmbeddedWorkerInstanceHost, EmbeddedWorkerInstanceHost.Proxy> MANAGER = new Interface.Manager<EmbeddedWorkerInstanceHost, EmbeddedWorkerInstanceHost.Proxy>() { // from class: org.chromium.blink.mojom.EmbeddedWorkerInstanceHost_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.EmbeddedWorkerInstanceHost";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public EmbeddedWorkerInstanceHost.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, EmbeddedWorkerInstanceHost impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public EmbeddedWorkerInstanceHost[] buildArray(int size) {
            return new EmbeddedWorkerInstanceHost[size];
        }
    };
    private static final int REQUEST_TERMINATION_ORDINAL = 0;
    private static final int COUNT_FEATURE_ORDINAL = 1;
    private static final int ON_READY_FOR_INSPECTION_ORDINAL = 2;
    private static final int ON_SCRIPT_LOADED_ORDINAL = 3;
    private static final int ON_SCRIPT_EVALUATION_START_ORDINAL = 4;
    private static final int ON_STARTED_ORDINAL = 5;
    private static final int ON_REPORT_EXCEPTION_ORDINAL = 6;
    private static final int ON_REPORT_CONSOLE_MESSAGE_ORDINAL = 7;
    private static final int ON_STOPPED_ORDINAL = 8;

    EmbeddedWorkerInstanceHost_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements EmbeddedWorkerInstanceHost.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void requestTermination(EmbeddedWorkerInstanceHost.RequestTerminationResponse callback) {
            EmbeddedWorkerInstanceHostRequestTerminationParams _message = new EmbeddedWorkerInstanceHostRequestTerminationParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new EmbeddedWorkerInstanceHostRequestTerminationResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void countFeature(int feature) {
            EmbeddedWorkerInstanceHostCountFeatureParams _message = new EmbeddedWorkerInstanceHostCountFeatureParams();
            _message.feature = feature;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onReadyForInspection() {
            EmbeddedWorkerInstanceHostOnReadyForInspectionParams _message = new EmbeddedWorkerInstanceHostOnReadyForInspectionParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onScriptLoaded() {
            EmbeddedWorkerInstanceHostOnScriptLoadedParams _message = new EmbeddedWorkerInstanceHostOnScriptLoadedParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onScriptEvaluationStart() {
            EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams _message = new EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onStarted(int status, int threadId, EmbeddedWorkerStartTiming startTiming) {
            EmbeddedWorkerInstanceHostOnStartedParams _message = new EmbeddedWorkerInstanceHostOnStartedParams();
            _message.status = status;
            _message.threadId = threadId;
            _message.startTiming = startTiming;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onReportException(String16 errorMessage, int lineNumber, int columnNumber, Url sourceUrl) {
            EmbeddedWorkerInstanceHostOnReportExceptionParams _message = new EmbeddedWorkerInstanceHostOnReportExceptionParams();
            _message.errorMessage = errorMessage;
            _message.lineNumber = lineNumber;
            _message.columnNumber = columnNumber;
            _message.sourceUrl = sourceUrl;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(6)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onReportConsoleMessage(int source, int messageLevel, String16 message, int lineNumber, Url sourceUrl) {
            EmbeddedWorkerInstanceHostOnReportConsoleMessageParams _message = new EmbeddedWorkerInstanceHostOnReportConsoleMessageParams();
            _message.source = source;
            _message.messageLevel = messageLevel;
            _message.message = message;
            _message.lineNumber = lineNumber;
            _message.sourceUrl = sourceUrl;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(7)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceHost
        public void onStopped() {
            EmbeddedWorkerInstanceHostOnStoppedParams _message = new EmbeddedWorkerInstanceHostOnStoppedParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(8)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<EmbeddedWorkerInstanceHost> {
        Stub(Core core, EmbeddedWorkerInstanceHost impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(EmbeddedWorkerInstanceHost_Internal.MANAGER, messageWithHeader);
                    case -1:
                    case 0:
                    default:
                        return false;
                    case 1:
                        getImpl().countFeature(EmbeddedWorkerInstanceHostCountFeatureParams.deserialize(messageWithHeader.getPayload()).feature);
                        return true;
                    case 2:
                        EmbeddedWorkerInstanceHostOnReadyForInspectionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onReadyForInspection();
                        return true;
                    case 3:
                        EmbeddedWorkerInstanceHostOnScriptLoadedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onScriptLoaded();
                        return true;
                    case 4:
                        EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onScriptEvaluationStart();
                        return true;
                    case 5:
                        EmbeddedWorkerInstanceHostOnStartedParams data = EmbeddedWorkerInstanceHostOnStartedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onStarted(data.status, data.threadId, data.startTiming);
                        return true;
                    case 6:
                        EmbeddedWorkerInstanceHostOnReportExceptionParams data2 = EmbeddedWorkerInstanceHostOnReportExceptionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onReportException(data2.errorMessage, data2.lineNumber, data2.columnNumber, data2.sourceUrl);
                        return true;
                    case 7:
                        EmbeddedWorkerInstanceHostOnReportConsoleMessageParams data3 = EmbeddedWorkerInstanceHostOnReportConsoleMessageParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onReportConsoleMessage(data3.source, data3.messageLevel, data3.message, data3.lineNumber, data3.sourceUrl);
                        return true;
                    case 8:
                        EmbeddedWorkerInstanceHostOnStoppedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onStopped();
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), EmbeddedWorkerInstanceHost_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        EmbeddedWorkerInstanceHostRequestTerminationParams.deserialize(messageWithHeader.getPayload());
                        getImpl().requestTermination(new EmbeddedWorkerInstanceHostRequestTerminationResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostRequestTerminationParams.class */
    static final class EmbeddedWorkerInstanceHostRequestTerminationParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceHostRequestTerminationParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceHostRequestTerminationParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostRequestTerminationParams result = new EmbeddedWorkerInstanceHostRequestTerminationParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostRequestTerminationResponseParams.class */
    public static final class EmbeddedWorkerInstanceHostRequestTerminationResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean willBeTerminated;

        private EmbeddedWorkerInstanceHostRequestTerminationResponseParams(int version) {
            super(16, version);
        }

        public EmbeddedWorkerInstanceHostRequestTerminationResponseParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostRequestTerminationResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostRequestTerminationResponseParams result = new EmbeddedWorkerInstanceHostRequestTerminationResponseParams(elementsOrVersion);
                result.willBeTerminated = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.willBeTerminated, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostRequestTerminationResponseParamsForwardToCallback.class */
    static class EmbeddedWorkerInstanceHostRequestTerminationResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final EmbeddedWorkerInstanceHost.RequestTerminationResponse mCallback;

        EmbeddedWorkerInstanceHostRequestTerminationResponseParamsForwardToCallback(EmbeddedWorkerInstanceHost.RequestTerminationResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                EmbeddedWorkerInstanceHostRequestTerminationResponseParams response = EmbeddedWorkerInstanceHostRequestTerminationResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.willBeTerminated));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostRequestTerminationResponseParamsProxyToResponder.class */
    static class EmbeddedWorkerInstanceHostRequestTerminationResponseParamsProxyToResponder implements EmbeddedWorkerInstanceHost.RequestTerminationResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        EmbeddedWorkerInstanceHostRequestTerminationResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean willBeTerminated) {
            EmbeddedWorkerInstanceHostRequestTerminationResponseParams _response = new EmbeddedWorkerInstanceHostRequestTerminationResponseParams();
            _response.willBeTerminated = willBeTerminated.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostCountFeatureParams.class */
    static final class EmbeddedWorkerInstanceHostCountFeatureParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int feature;

        private EmbeddedWorkerInstanceHostCountFeatureParams(int version) {
            super(16, version);
        }

        public EmbeddedWorkerInstanceHostCountFeatureParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostCountFeatureParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostCountFeatureParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostCountFeatureParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostCountFeatureParams result = new EmbeddedWorkerInstanceHostCountFeatureParams(elementsOrVersion);
                result.feature = decoder0.readInt(8);
                WebFeature.validate(result.feature);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.feature, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnReadyForInspectionParams.class */
    static final class EmbeddedWorkerInstanceHostOnReadyForInspectionParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceHostOnReadyForInspectionParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceHostOnReadyForInspectionParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnReadyForInspectionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnReadyForInspectionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnReadyForInspectionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnReadyForInspectionParams result = new EmbeddedWorkerInstanceHostOnReadyForInspectionParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnScriptLoadedParams.class */
    static final class EmbeddedWorkerInstanceHostOnScriptLoadedParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceHostOnScriptLoadedParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceHostOnScriptLoadedParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnScriptLoadedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnScriptLoadedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnScriptLoadedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnScriptLoadedParams result = new EmbeddedWorkerInstanceHostOnScriptLoadedParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams.class */
    static final class EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams result = new EmbeddedWorkerInstanceHostOnScriptEvaluationStartParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnStartedParams.class */
    static final class EmbeddedWorkerInstanceHostOnStartedParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;
        public int threadId;
        public EmbeddedWorkerStartTiming startTiming;

        private EmbeddedWorkerInstanceHostOnStartedParams(int version) {
            super(24, version);
        }

        public EmbeddedWorkerInstanceHostOnStartedParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnStartedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnStartedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnStartedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnStartedParams result = new EmbeddedWorkerInstanceHostOnStartedParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                ServiceWorkerStartStatus.validate(result.status);
                result.threadId = decoder0.readInt(12);
                Decoder decoder1 = decoder0.readPointer(16, false);
                result.startTiming = EmbeddedWorkerStartTiming.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
            encoder0.encode(this.threadId, 12);
            encoder0.encode((Struct) this.startTiming, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnReportExceptionParams.class */
    static final class EmbeddedWorkerInstanceHostOnReportExceptionParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 errorMessage;
        public int lineNumber;
        public int columnNumber;
        public Url sourceUrl;

        private EmbeddedWorkerInstanceHostOnReportExceptionParams(int version) {
            super(32, version);
        }

        public EmbeddedWorkerInstanceHostOnReportExceptionParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnReportExceptionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnReportExceptionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnReportExceptionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnReportExceptionParams result = new EmbeddedWorkerInstanceHostOnReportExceptionParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.errorMessage = String16.decode(decoder1);
                result.lineNumber = decoder0.readInt(16);
                result.columnNumber = decoder0.readInt(20);
                Decoder decoder12 = decoder0.readPointer(24, false);
                result.sourceUrl = Url.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.errorMessage, 8, false);
            encoder0.encode(this.lineNumber, 16);
            encoder0.encode(this.columnNumber, 20);
            encoder0.encode((Struct) this.sourceUrl, 24, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnReportConsoleMessageParams.class */
    static final class EmbeddedWorkerInstanceHostOnReportConsoleMessageParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int source;
        public int messageLevel;
        public String16 message;
        public int lineNumber;
        public Url sourceUrl;

        private EmbeddedWorkerInstanceHostOnReportConsoleMessageParams(int version) {
            super(40, version);
        }

        public EmbeddedWorkerInstanceHostOnReportConsoleMessageParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnReportConsoleMessageParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnReportConsoleMessageParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnReportConsoleMessageParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnReportConsoleMessageParams result = new EmbeddedWorkerInstanceHostOnReportConsoleMessageParams(elementsOrVersion);
                result.source = decoder0.readInt(8);
                ConsoleMessageSource.validate(result.source);
                result.messageLevel = decoder0.readInt(12);
                ConsoleMessageLevel.validate(result.messageLevel);
                Decoder decoder1 = decoder0.readPointer(16, false);
                result.message = String16.decode(decoder1);
                result.lineNumber = decoder0.readInt(24);
                Decoder decoder12 = decoder0.readPointer(32, false);
                result.sourceUrl = Url.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.source, 8);
            encoder0.encode(this.messageLevel, 12);
            encoder0.encode((Struct) this.message, 16, false);
            encoder0.encode(this.lineNumber, 24);
            encoder0.encode((Struct) this.sourceUrl, 32, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceHost_Internal$EmbeddedWorkerInstanceHostOnStoppedParams.class */
    static final class EmbeddedWorkerInstanceHostOnStoppedParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceHostOnStoppedParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceHostOnStoppedParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceHostOnStoppedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceHostOnStoppedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceHostOnStoppedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceHostOnStoppedParams result = new EmbeddedWorkerInstanceHostOnStoppedParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }
}
