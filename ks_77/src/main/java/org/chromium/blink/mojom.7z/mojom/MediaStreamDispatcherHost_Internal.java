package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.MediaStreamDispatcherHost;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal.class */
class MediaStreamDispatcherHost_Internal {
    public static final Interface.Manager<MediaStreamDispatcherHost, MediaStreamDispatcherHost.Proxy> MANAGER = new Interface.Manager<MediaStreamDispatcherHost, MediaStreamDispatcherHost.Proxy>() { // from class: org.chromium.blink.mojom.MediaStreamDispatcherHost_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.MediaStreamDispatcherHost";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public MediaStreamDispatcherHost.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, MediaStreamDispatcherHost impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public MediaStreamDispatcherHost[] buildArray(int size) {
            return new MediaStreamDispatcherHost[size];
        }
    };
    private static final int GENERATE_STREAM_ORDINAL = 0;
    private static final int CANCEL_REQUEST_ORDINAL = 1;
    private static final int STOP_STREAM_DEVICE_ORDINAL = 2;
    private static final int OPEN_DEVICE_ORDINAL = 3;
    private static final int CLOSE_DEVICE_ORDINAL = 4;
    private static final int SET_CAPTURING_LINK_SECURED_ORDINAL = 5;
    private static final int ON_STREAM_STARTED_ORDINAL = 6;

    MediaStreamDispatcherHost_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements MediaStreamDispatcherHost.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void generateStream(int requestId, StreamControls controls, boolean userGesture, MediaStreamDispatcherHost.GenerateStreamResponse callback) {
            MediaStreamDispatcherHostGenerateStreamParams _message = new MediaStreamDispatcherHostGenerateStreamParams();
            _message.requestId = requestId;
            _message.controls = controls;
            _message.userGesture = userGesture;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new MediaStreamDispatcherHostGenerateStreamResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void cancelRequest(int requestId) {
            MediaStreamDispatcherHostCancelRequestParams _message = new MediaStreamDispatcherHostCancelRequestParams();
            _message.requestId = requestId;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void stopStreamDevice(String deviceId, int sessionId) {
            MediaStreamDispatcherHostStopStreamDeviceParams _message = new MediaStreamDispatcherHostStopStreamDeviceParams();
            _message.deviceId = deviceId;
            _message.sessionId = sessionId;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void openDevice(int requestId, String deviceId, int type, MediaStreamDispatcherHost.OpenDeviceResponse callback) {
            MediaStreamDispatcherHostOpenDeviceParams _message = new MediaStreamDispatcherHostOpenDeviceParams();
            _message.requestId = requestId;
            _message.deviceId = deviceId;
            _message.type = type;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new MediaStreamDispatcherHostOpenDeviceResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void closeDevice(String label) {
            MediaStreamDispatcherHostCloseDeviceParams _message = new MediaStreamDispatcherHostCloseDeviceParams();
            _message.label = label;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4)));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void setCapturingLinkSecured(int sessionId, int type, boolean isSecure) {
            MediaStreamDispatcherHostSetCapturingLinkSecuredParams _message = new MediaStreamDispatcherHostSetCapturingLinkSecuredParams();
            _message.sessionId = sessionId;
            _message.type = type;
            _message.isSecure = isSecure;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5)));
        }

        @Override // org.chromium.blink.mojom.MediaStreamDispatcherHost
        public void onStreamStarted(String label) {
            MediaStreamDispatcherHostOnStreamStartedParams _message = new MediaStreamDispatcherHostOnStreamStartedParams();
            _message.label = label;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(6)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<MediaStreamDispatcherHost> {
        Stub(Core core, MediaStreamDispatcherHost impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(MediaStreamDispatcherHost_Internal.MANAGER, messageWithHeader);
                    case -1:
                    case 0:
                    case 3:
                    default:
                        return false;
                    case 1:
                        MediaStreamDispatcherHostCancelRequestParams data = MediaStreamDispatcherHostCancelRequestParams.deserialize(messageWithHeader.getPayload());
                        getImpl().cancelRequest(data.requestId);
                        return true;
                    case 2:
                        MediaStreamDispatcherHostStopStreamDeviceParams data2 = MediaStreamDispatcherHostStopStreamDeviceParams.deserialize(messageWithHeader.getPayload());
                        getImpl().stopStreamDevice(data2.deviceId, data2.sessionId);
                        return true;
                    case 4:
                        MediaStreamDispatcherHostCloseDeviceParams data3 = MediaStreamDispatcherHostCloseDeviceParams.deserialize(messageWithHeader.getPayload());
                        getImpl().closeDevice(data3.label);
                        return true;
                    case 5:
                        MediaStreamDispatcherHostSetCapturingLinkSecuredParams data4 = MediaStreamDispatcherHostSetCapturingLinkSecuredParams.deserialize(messageWithHeader.getPayload());
                        getImpl().setCapturingLinkSecured(data4.sessionId, data4.type, data4.isSecure);
                        return true;
                    case 6:
                        getImpl().onStreamStarted(MediaStreamDispatcherHostOnStreamStartedParams.deserialize(messageWithHeader.getPayload()).label);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), MediaStreamDispatcherHost_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        MediaStreamDispatcherHostGenerateStreamParams data = MediaStreamDispatcherHostGenerateStreamParams.deserialize(messageWithHeader.getPayload());
                        getImpl().generateStream(data.requestId, data.controls, data.userGesture, new MediaStreamDispatcherHostGenerateStreamResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                    case 2:
                    default:
                        return false;
                    case 3:
                        MediaStreamDispatcherHostOpenDeviceParams data2 = MediaStreamDispatcherHostOpenDeviceParams.deserialize(messageWithHeader.getPayload());
                        getImpl().openDevice(data2.requestId, data2.deviceId, data2.type, new MediaStreamDispatcherHostOpenDeviceResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostGenerateStreamParams.class */
    static final class MediaStreamDispatcherHostGenerateStreamParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int requestId;
        public StreamControls controls;
        public boolean userGesture;

        private MediaStreamDispatcherHostGenerateStreamParams(int version) {
            super(24, version);
        }

        public MediaStreamDispatcherHostGenerateStreamParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostGenerateStreamParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostGenerateStreamParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostGenerateStreamParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostGenerateStreamParams result = new MediaStreamDispatcherHostGenerateStreamParams(elementsOrVersion);
                result.requestId = decoder0.readInt(8);
                result.userGesture = decoder0.readBoolean(12, 0);
                Decoder decoder1 = decoder0.readPointer(16, false);
                result.controls = StreamControls.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.requestId, 8);
            encoder0.encode(this.userGesture, 12, 0);
            encoder0.encode((Struct) this.controls, 16, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostGenerateStreamResponseParams.class */
    public static final class MediaStreamDispatcherHostGenerateStreamResponseParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int result;
        public String label;
        public MediaStreamDevice[] audioDevices;
        public MediaStreamDevice[] videoDevices;

        private MediaStreamDispatcherHostGenerateStreamResponseParams(int version) {
            super(40, version);
        }

        public MediaStreamDispatcherHostGenerateStreamResponseParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostGenerateStreamResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostGenerateStreamResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostGenerateStreamResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostGenerateStreamResponseParams result = new MediaStreamDispatcherHostGenerateStreamResponseParams(elementsOrVersion);
                result.result = decoder0.readInt(8);
                MediaStreamRequestResult.validate(result.result);
                result.label = decoder0.readString(16, false);
                Decoder decoder1 = decoder0.readPointer(24, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.audioDevices = new MediaStreamDevice[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.audioDevices[i1] = MediaStreamDevice.decode(decoder2);
                }
                Decoder decoder12 = decoder0.readPointer(32, false);
                DataHeader si12 = decoder12.readDataHeaderForPointerArray(-1);
                result.videoDevices = new MediaStreamDevice[si12.elementsOrVersion];
                for (int i12 = 0; i12 < si12.elementsOrVersion; i12++) {
                    Decoder decoder22 = decoder12.readPointer(8 + (8 * i12), false);
                    result.videoDevices[i12] = MediaStreamDevice.decode(decoder22);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.result, 8);
            encoder0.encode(this.label, 16, false);
            if (this.audioDevices == null) {
                encoder0.encodeNullPointer(24, false);
            } else {
                Encoder encoder1 = encoder0.encodePointerArray(this.audioDevices.length, 24, -1);
                for (int i0 = 0; i0 < this.audioDevices.length; i0++) {
                    encoder1.encode((Struct) this.audioDevices[i0], 8 + (8 * i0), false);
                }
            }
            if (this.videoDevices == null) {
                encoder0.encodeNullPointer(32, false);
                return;
            }
            Encoder encoder12 = encoder0.encodePointerArray(this.videoDevices.length, 32, -1);
            for (int i02 = 0; i02 < this.videoDevices.length; i02++) {
                encoder12.encode((Struct) this.videoDevices[i02], 8 + (8 * i02), false);
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostGenerateStreamResponseParamsForwardToCallback.class */
    static class MediaStreamDispatcherHostGenerateStreamResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final MediaStreamDispatcherHost.GenerateStreamResponse mCallback;

        MediaStreamDispatcherHostGenerateStreamResponseParamsForwardToCallback(MediaStreamDispatcherHost.GenerateStreamResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                MediaStreamDispatcherHostGenerateStreamResponseParams response = MediaStreamDispatcherHostGenerateStreamResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.result), response.label, response.audioDevices, response.videoDevices);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostGenerateStreamResponseParamsProxyToResponder.class */
    static class MediaStreamDispatcherHostGenerateStreamResponseParamsProxyToResponder implements MediaStreamDispatcherHost.GenerateStreamResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        MediaStreamDispatcherHostGenerateStreamResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback4
        public void call(Integer result, String label, MediaStreamDevice[] audioDevices, MediaStreamDevice[] videoDevices) {
            MediaStreamDispatcherHostGenerateStreamResponseParams _response = new MediaStreamDispatcherHostGenerateStreamResponseParams();
            _response.result = result.intValue();
            _response.label = label;
            _response.audioDevices = audioDevices;
            _response.videoDevices = videoDevices;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostCancelRequestParams.class */
    static final class MediaStreamDispatcherHostCancelRequestParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int requestId;

        private MediaStreamDispatcherHostCancelRequestParams(int version) {
            super(16, version);
        }

        public MediaStreamDispatcherHostCancelRequestParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostCancelRequestParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostCancelRequestParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostCancelRequestParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostCancelRequestParams result = new MediaStreamDispatcherHostCancelRequestParams(elementsOrVersion);
                result.requestId = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.requestId, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostStopStreamDeviceParams.class */
    static final class MediaStreamDispatcherHostStopStreamDeviceParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String deviceId;
        public int sessionId;

        private MediaStreamDispatcherHostStopStreamDeviceParams(int version) {
            super(24, version);
        }

        public MediaStreamDispatcherHostStopStreamDeviceParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostStopStreamDeviceParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostStopStreamDeviceParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostStopStreamDeviceParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostStopStreamDeviceParams result = new MediaStreamDispatcherHostStopStreamDeviceParams(elementsOrVersion);
                result.deviceId = decoder0.readString(8, false);
                result.sessionId = decoder0.readInt(16);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.deviceId, 8, false);
            encoder0.encode(this.sessionId, 16);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostOpenDeviceParams.class */
    static final class MediaStreamDispatcherHostOpenDeviceParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int requestId;
        public String deviceId;
        public int type;

        private MediaStreamDispatcherHostOpenDeviceParams(int version) {
            super(24, version);
        }

        public MediaStreamDispatcherHostOpenDeviceParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostOpenDeviceParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostOpenDeviceParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostOpenDeviceParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostOpenDeviceParams result = new MediaStreamDispatcherHostOpenDeviceParams(elementsOrVersion);
                result.requestId = decoder0.readInt(8);
                result.type = decoder0.readInt(12);
                MediaStreamType.validate(result.type);
                result.deviceId = decoder0.readString(16, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.requestId, 8);
            encoder0.encode(this.type, 12);
            encoder0.encode(this.deviceId, 16, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostOpenDeviceResponseParams.class */
    public static final class MediaStreamDispatcherHostOpenDeviceResponseParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;
        public String label;
        public MediaStreamDevice device;

        private MediaStreamDispatcherHostOpenDeviceResponseParams(int version) {
            super(32, version);
        }

        public MediaStreamDispatcherHostOpenDeviceResponseParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostOpenDeviceResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostOpenDeviceResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostOpenDeviceResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostOpenDeviceResponseParams result = new MediaStreamDispatcherHostOpenDeviceResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                result.label = decoder0.readString(16, false);
                Decoder decoder1 = decoder0.readPointer(24, false);
                result.device = MediaStreamDevice.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
            encoder0.encode(this.label, 16, false);
            encoder0.encode((Struct) this.device, 24, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostOpenDeviceResponseParamsForwardToCallback.class */
    static class MediaStreamDispatcherHostOpenDeviceResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final MediaStreamDispatcherHost.OpenDeviceResponse mCallback;

        MediaStreamDispatcherHostOpenDeviceResponseParamsForwardToCallback(MediaStreamDispatcherHost.OpenDeviceResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                MediaStreamDispatcherHostOpenDeviceResponseParams response = MediaStreamDispatcherHostOpenDeviceResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success), response.label, response.device);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostOpenDeviceResponseParamsProxyToResponder.class */
    static class MediaStreamDispatcherHostOpenDeviceResponseParamsProxyToResponder implements MediaStreamDispatcherHost.OpenDeviceResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        MediaStreamDispatcherHostOpenDeviceResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback3
        public void call(Boolean success, String label, MediaStreamDevice device) {
            MediaStreamDispatcherHostOpenDeviceResponseParams _response = new MediaStreamDispatcherHostOpenDeviceResponseParams();
            _response.success = success.booleanValue();
            _response.label = label;
            _response.device = device;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostCloseDeviceParams.class */
    static final class MediaStreamDispatcherHostCloseDeviceParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String label;

        private MediaStreamDispatcherHostCloseDeviceParams(int version) {
            super(16, version);
        }

        public MediaStreamDispatcherHostCloseDeviceParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostCloseDeviceParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostCloseDeviceParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostCloseDeviceParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostCloseDeviceParams result = new MediaStreamDispatcherHostCloseDeviceParams(elementsOrVersion);
                result.label = decoder0.readString(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.label, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostSetCapturingLinkSecuredParams.class */
    static final class MediaStreamDispatcherHostSetCapturingLinkSecuredParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int sessionId;
        public int type;
        public boolean isSecure;

        private MediaStreamDispatcherHostSetCapturingLinkSecuredParams(int version) {
            super(24, version);
        }

        public MediaStreamDispatcherHostSetCapturingLinkSecuredParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostSetCapturingLinkSecuredParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostSetCapturingLinkSecuredParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostSetCapturingLinkSecuredParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostSetCapturingLinkSecuredParams result = new MediaStreamDispatcherHostSetCapturingLinkSecuredParams(elementsOrVersion);
                result.sessionId = decoder0.readInt(8);
                result.type = decoder0.readInt(12);
                MediaStreamType.validate(result.type);
                result.isSecure = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.sessionId, 8);
            encoder0.encode(this.type, 12);
            encoder0.encode(this.isSecure, 16, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/MediaStreamDispatcherHost_Internal$MediaStreamDispatcherHostOnStreamStartedParams.class */
    static final class MediaStreamDispatcherHostOnStreamStartedParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String label;

        private MediaStreamDispatcherHostOnStreamStartedParams(int version) {
            super(16, version);
        }

        public MediaStreamDispatcherHostOnStreamStartedParams() {
            this(0);
        }

        public static MediaStreamDispatcherHostOnStreamStartedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static MediaStreamDispatcherHostOnStreamStartedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static MediaStreamDispatcherHostOnStreamStartedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                MediaStreamDispatcherHostOnStreamStartedParams result = new MediaStreamDispatcherHostOnStreamStartedParams(elementsOrVersion);
                result.label = decoder0.readString(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.label, 8, false);
        }
    }
}
