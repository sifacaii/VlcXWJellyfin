package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.LockManager;
import org.chromium.mojo.bindings.AssociatedInterfaceNotSupported;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal.class */
class LockManager_Internal {
    public static final Interface.Manager<LockManager, LockManager.Proxy> MANAGER = new Interface.Manager<LockManager, LockManager.Proxy>() { // from class: org.chromium.blink.mojom.LockManager_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.LockManager";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public LockManager.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, LockManager impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public LockManager[] buildArray(int size) {
            return new LockManager[size];
        }
    };
    private static final int REQUEST_LOCK_ORDINAL = 0;
    private static final int QUERY_STATE_ORDINAL = 1;

    LockManager_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements LockManager.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.LockManager
        public void requestLock(String name, int mode, int wait, AssociatedInterfaceNotSupported request) {
            LockManagerRequestLockParams _message = new LockManagerRequestLockParams();
            _message.name = name;
            _message.mode = mode;
            _message.wait = wait;
            _message.request = request;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.LockManager
        public void queryState(LockManager.QueryStateResponse callback) {
            LockManagerQueryStateParams _message = new LockManagerQueryStateParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new LockManagerQueryStateResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<LockManager> {
        Stub(Core core, LockManager impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(LockManager_Internal.MANAGER, messageWithHeader);
                    case 0:
                        LockManagerRequestLockParams data = LockManagerRequestLockParams.deserialize(messageWithHeader.getPayload());
                        getImpl().requestLock(data.name, data.mode, data.wait, data.request);
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), LockManager_Internal.MANAGER, messageWithHeader, receiver);
                    case 1:
                        LockManagerQueryStateParams.deserialize(messageWithHeader.getPayload());
                        getImpl().queryState(new LockManagerQueryStateResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$LockManagerRequestLockParams.class */
    static final class LockManagerRequestLockParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String name;
        public int mode;
        public int wait;
        public AssociatedInterfaceNotSupported request;

        private LockManagerRequestLockParams(int version) {
            super(32, version);
        }

        public LockManagerRequestLockParams() {
            this(0);
        }

        public static LockManagerRequestLockParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static LockManagerRequestLockParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static LockManagerRequestLockParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                LockManagerRequestLockParams result = new LockManagerRequestLockParams(elementsOrVersion);
                result.name = decoder0.readString(8, false);
                result.mode = decoder0.readInt(16);
                LockMode.validate(result.mode);
                result.wait = decoder0.readInt(20);
                LockManager.WaitMode.validate(result.wait);
                result.request = decoder0.readAssociatedServiceInterfaceNotSupported(24, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.name, 8, false);
            encoder0.encode(this.mode, 16);
            encoder0.encode(this.wait, 20);
            encoder0.encode(this.request, 24, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$LockManagerQueryStateParams.class */
    static final class LockManagerQueryStateParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private LockManagerQueryStateParams(int version) {
            super(8, version);
        }

        public LockManagerQueryStateParams() {
            this(0);
        }

        public static LockManagerQueryStateParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static LockManagerQueryStateParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static LockManagerQueryStateParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                LockManagerQueryStateParams result = new LockManagerQueryStateParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$LockManagerQueryStateResponseParams.class */
    public static final class LockManagerQueryStateResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public LockInfo[] requested;
        public LockInfo[] held;

        private LockManagerQueryStateResponseParams(int version) {
            super(24, version);
        }

        public LockManagerQueryStateResponseParams() {
            this(0);
        }

        public static LockManagerQueryStateResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static LockManagerQueryStateResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static LockManagerQueryStateResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                LockManagerQueryStateResponseParams result = new LockManagerQueryStateResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.requested = new LockInfo[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.requested[i1] = LockInfo.decode(decoder2);
                }
                Decoder decoder12 = decoder0.readPointer(16, false);
                DataHeader si12 = decoder12.readDataHeaderForPointerArray(-1);
                result.held = new LockInfo[si12.elementsOrVersion];
                for (int i12 = 0; i12 < si12.elementsOrVersion; i12++) {
                    Decoder decoder22 = decoder12.readPointer(8 + (8 * i12), false);
                    result.held[i12] = LockInfo.decode(decoder22);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            if (this.requested == null) {
                encoder0.encodeNullPointer(8, false);
            } else {
                Encoder encoder1 = encoder0.encodePointerArray(this.requested.length, 8, -1);
                for (int i0 = 0; i0 < this.requested.length; i0++) {
                    encoder1.encode((Struct) this.requested[i0], 8 + (8 * i0), false);
                }
            }
            if (this.held == null) {
                encoder0.encodeNullPointer(16, false);
                return;
            }
            Encoder encoder12 = encoder0.encodePointerArray(this.held.length, 16, -1);
            for (int i02 = 0; i02 < this.held.length; i02++) {
                encoder12.encode((Struct) this.held[i02], 8 + (8 * i02), false);
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$LockManagerQueryStateResponseParamsForwardToCallback.class */
    static class LockManagerQueryStateResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final LockManager.QueryStateResponse mCallback;

        LockManagerQueryStateResponseParamsForwardToCallback(LockManager.QueryStateResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                LockManagerQueryStateResponseParams response = LockManagerQueryStateResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.requested, response.held);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/LockManager_Internal$LockManagerQueryStateResponseParamsProxyToResponder.class */
    static class LockManagerQueryStateResponseParamsProxyToResponder implements LockManager.QueryStateResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        LockManagerQueryStateResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(LockInfo[] requested, LockInfo[] held) {
            LockManagerQueryStateResponseParams _response = new LockManagerQueryStateResponseParams();
            _response.requested = requested;
            _response.held = held;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
