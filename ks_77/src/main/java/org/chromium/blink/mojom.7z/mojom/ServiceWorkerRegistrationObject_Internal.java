package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.ServiceWorkerRegistrationObject;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal.class */
class ServiceWorkerRegistrationObject_Internal {
    public static final Interface.Manager<ServiceWorkerRegistrationObject, ServiceWorkerRegistrationObject.Proxy> MANAGER = new Interface.Manager<ServiceWorkerRegistrationObject, ServiceWorkerRegistrationObject.Proxy>() { // from class: org.chromium.blink.mojom.ServiceWorkerRegistrationObject_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.ServiceWorkerRegistrationObject";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public ServiceWorkerRegistrationObject.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, ServiceWorkerRegistrationObject impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public ServiceWorkerRegistrationObject[] buildArray(int size) {
            return new ServiceWorkerRegistrationObject[size];
        }
    };
    private static final int SET_SERVICE_WORKER_OBJECTS_ORDINAL = 0;
    private static final int SET_UPDATE_VIA_CACHE_ORDINAL = 1;
    private static final int UPDATE_FOUND_ORDINAL = 2;

    ServiceWorkerRegistrationObject_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements ServiceWorkerRegistrationObject.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerRegistrationObject
        public void setServiceWorkerObjects(ChangedServiceWorkerObjectsMask changedMask, ServiceWorkerObjectInfo installing, ServiceWorkerObjectInfo waiting, ServiceWorkerObjectInfo active) {
            ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams _message = new ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams();
            _message.changedMask = changedMask;
            _message.installing = installing;
            _message.waiting = waiting;
            _message.active = active;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerRegistrationObject
        public void setUpdateViaCache(int updateViaCache) {
            ServiceWorkerRegistrationObjectSetUpdateViaCacheParams _message = new ServiceWorkerRegistrationObjectSetUpdateViaCacheParams();
            _message.updateViaCache = updateViaCache;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerRegistrationObject
        public void updateFound() {
            ServiceWorkerRegistrationObjectUpdateFoundParams _message = new ServiceWorkerRegistrationObjectUpdateFoundParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<ServiceWorkerRegistrationObject> {
        Stub(Core core, ServiceWorkerRegistrationObject impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(ServiceWorkerRegistrationObject_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams data = ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams.deserialize(messageWithHeader.getPayload());
                        getImpl().setServiceWorkerObjects(data.changedMask, data.installing, data.waiting, data.active);
                        return true;
                    case 1:
                        getImpl().setUpdateViaCache(ServiceWorkerRegistrationObjectSetUpdateViaCacheParams.deserialize(messageWithHeader.getPayload()).updateViaCache);
                        return true;
                    case 2:
                        ServiceWorkerRegistrationObjectUpdateFoundParams.deserialize(messageWithHeader.getPayload());
                        getImpl().updateFound();
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), ServiceWorkerRegistrationObject_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal$ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams.class */
    static final class ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public ChangedServiceWorkerObjectsMask changedMask;
        public ServiceWorkerObjectInfo installing;
        public ServiceWorkerObjectInfo waiting;
        public ServiceWorkerObjectInfo active;

        private ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams(int version) {
            super(40, version);
        }

        public ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams() {
            this(0);
        }

        public static ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams result = new ServiceWorkerRegistrationObjectSetServiceWorkerObjectsParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.changedMask = ChangedServiceWorkerObjectsMask.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, true);
                result.installing = ServiceWorkerObjectInfo.decode(decoder12);
                Decoder decoder13 = decoder0.readPointer(24, true);
                result.waiting = ServiceWorkerObjectInfo.decode(decoder13);
                Decoder decoder14 = decoder0.readPointer(32, true);
                result.active = ServiceWorkerObjectInfo.decode(decoder14);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.changedMask, 8, false);
            encoder0.encode((Struct) this.installing, 16, true);
            encoder0.encode((Struct) this.waiting, 24, true);
            encoder0.encode((Struct) this.active, 32, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal$ServiceWorkerRegistrationObjectSetUpdateViaCacheParams.class */
    static final class ServiceWorkerRegistrationObjectSetUpdateViaCacheParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int updateViaCache;

        private ServiceWorkerRegistrationObjectSetUpdateViaCacheParams(int version) {
            super(16, version);
        }

        public ServiceWorkerRegistrationObjectSetUpdateViaCacheParams() {
            this(0);
        }

        public static ServiceWorkerRegistrationObjectSetUpdateViaCacheParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerRegistrationObjectSetUpdateViaCacheParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerRegistrationObjectSetUpdateViaCacheParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerRegistrationObjectSetUpdateViaCacheParams result = new ServiceWorkerRegistrationObjectSetUpdateViaCacheParams(elementsOrVersion);
                result.updateViaCache = decoder0.readInt(8);
                ServiceWorkerUpdateViaCache.validate(result.updateViaCache);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.updateViaCache, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationObject_Internal$ServiceWorkerRegistrationObjectUpdateFoundParams.class */
    static final class ServiceWorkerRegistrationObjectUpdateFoundParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private ServiceWorkerRegistrationObjectUpdateFoundParams(int version) {
            super(8, version);
        }

        public ServiceWorkerRegistrationObjectUpdateFoundParams() {
            this(0);
        }

        public static ServiceWorkerRegistrationObjectUpdateFoundParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerRegistrationObjectUpdateFoundParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerRegistrationObjectUpdateFoundParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerRegistrationObjectUpdateFoundParams result = new ServiceWorkerRegistrationObjectUpdateFoundParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }
}
