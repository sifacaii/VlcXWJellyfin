package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/CssPropertyIdConstants.class */
public final class CssPropertyIdConstants {
    public static final int MAXIMUM_CSS_SAMPLE_ID = 645;
    public static final int TOTAL_PAGES_MEASURED_CSS_SAMPLE_ID = 1;

    private CssPropertyIdConstants() {
    }
}
