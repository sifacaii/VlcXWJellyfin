package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.SharedWorkerFactory;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.InterfaceRequest;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.mojo_base.mojom.UnguessableToken;
import org.chromium.service_manager.mojom.InterfaceProvider;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerFactory_Internal.class */
class SharedWorkerFactory_Internal {
    public static final Interface.Manager<SharedWorkerFactory, SharedWorkerFactory.Proxy> MANAGER = new Interface.Manager<SharedWorkerFactory, SharedWorkerFactory.Proxy>() { // from class: org.chromium.blink.mojom.SharedWorkerFactory_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.SharedWorkerFactory";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public SharedWorkerFactory.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, SharedWorkerFactory impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public SharedWorkerFactory[] buildArray(int size) {
            return new SharedWorkerFactory[size];
        }
    };
    private static final int CREATE_SHARED_WORKER_ORDINAL = 0;

    SharedWorkerFactory_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerFactory_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements SharedWorkerFactory.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.SharedWorkerFactory
        public void createSharedWorker(SharedWorkerInfo info, boolean pauseOnStart, UnguessableToken devtoolsWorkerToken, RendererPreferences rendererPreferences, InterfaceRequest<RendererPreferenceWatcher> preferenceWatcherRequest, WorkerContentSettingsProxy contentSettings, ServiceWorkerProviderInfoForClient serviceWorkerProviderInfo, UnguessableToken appcacheHostId, WorkerMainScriptLoadParams mainScriptLoadParams, UrlLoaderFactoryBundle subresourceLoaderFactories, ControllerServiceWorkerInfo controllerInfo, SharedWorkerHost host, InterfaceRequest<SharedWorker> sharedWorker, InterfaceProvider interfaceProvider) {
            SharedWorkerFactoryCreateSharedWorkerParams _message = new SharedWorkerFactoryCreateSharedWorkerParams();
            _message.info = info;
            _message.pauseOnStart = pauseOnStart;
            _message.devtoolsWorkerToken = devtoolsWorkerToken;
            _message.rendererPreferences = rendererPreferences;
            _message.preferenceWatcherRequest = preferenceWatcherRequest;
            _message.contentSettings = contentSettings;
            _message.serviceWorkerProviderInfo = serviceWorkerProviderInfo;
            _message.appcacheHostId = appcacheHostId;
            _message.mainScriptLoadParams = mainScriptLoadParams;
            _message.subresourceLoaderFactories = subresourceLoaderFactories;
            _message.controllerInfo = controllerInfo;
            _message.host = host;
            _message.sharedWorker = sharedWorker;
            _message.interfaceProvider = interfaceProvider;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerFactory_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<SharedWorkerFactory> {
        Stub(Core core, SharedWorkerFactory impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(SharedWorkerFactory_Internal.MANAGER, messageWithHeader);
                    case 0:
                        SharedWorkerFactoryCreateSharedWorkerParams data = SharedWorkerFactoryCreateSharedWorkerParams.deserialize(messageWithHeader.getPayload());
                        getImpl().createSharedWorker(data.info, data.pauseOnStart, data.devtoolsWorkerToken, data.rendererPreferences, data.preferenceWatcherRequest, data.contentSettings, data.serviceWorkerProviderInfo, data.appcacheHostId, data.mainScriptLoadParams, data.subresourceLoaderFactories, data.controllerInfo, data.host, data.sharedWorker, data.interfaceProvider);
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), SharedWorkerFactory_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerFactory_Internal$SharedWorkerFactoryCreateSharedWorkerParams.class */
    static final class SharedWorkerFactoryCreateSharedWorkerParams extends Struct {
        private static final int STRUCT_SIZE = 112;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(112, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public SharedWorkerInfo info;
        public boolean pauseOnStart;
        public UnguessableToken devtoolsWorkerToken;
        public RendererPreferences rendererPreferences;
        public InterfaceRequest<RendererPreferenceWatcher> preferenceWatcherRequest;
        public WorkerContentSettingsProxy contentSettings;
        public ServiceWorkerProviderInfoForClient serviceWorkerProviderInfo;
        public UnguessableToken appcacheHostId;
        public WorkerMainScriptLoadParams mainScriptLoadParams;
        public UrlLoaderFactoryBundle subresourceLoaderFactories;
        public ControllerServiceWorkerInfo controllerInfo;
        public SharedWorkerHost host;
        public InterfaceRequest<SharedWorker> sharedWorker;
        public InterfaceProvider interfaceProvider;

        private SharedWorkerFactoryCreateSharedWorkerParams(int version) {
            super(112, version);
        }

        public SharedWorkerFactoryCreateSharedWorkerParams() {
            this(0);
        }

        public static SharedWorkerFactoryCreateSharedWorkerParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static SharedWorkerFactoryCreateSharedWorkerParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static SharedWorkerFactoryCreateSharedWorkerParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                SharedWorkerFactoryCreateSharedWorkerParams result = new SharedWorkerFactoryCreateSharedWorkerParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.info = SharedWorkerInfo.decode(decoder1);
                result.pauseOnStart = decoder0.readBoolean(16, 0);
                result.preferenceWatcherRequest = decoder0.readInterfaceRequest(20, false);
                Decoder decoder12 = decoder0.readPointer(24, false);
                result.devtoolsWorkerToken = UnguessableToken.decode(decoder12);
                Decoder decoder13 = decoder0.readPointer(32, false);
                result.rendererPreferences = RendererPreferences.decode(decoder13);
                result.contentSettings = (WorkerContentSettingsProxy) decoder0.readServiceInterface(40, false, WorkerContentSettingsProxy.MANAGER);
                Decoder decoder14 = decoder0.readPointer(48, true);
                result.serviceWorkerProviderInfo = ServiceWorkerProviderInfoForClient.decode(decoder14);
                Decoder decoder15 = decoder0.readPointer(56, true);
                result.appcacheHostId = UnguessableToken.decode(decoder15);
                Decoder decoder16 = decoder0.readPointer(64, false);
                result.mainScriptLoadParams = WorkerMainScriptLoadParams.decode(decoder16);
                Decoder decoder17 = decoder0.readPointer(72, false);
                result.subresourceLoaderFactories = UrlLoaderFactoryBundle.decode(decoder17);
                Decoder decoder18 = decoder0.readPointer(80, true);
                result.controllerInfo = ControllerServiceWorkerInfo.decode(decoder18);
                result.host = (SharedWorkerHost) decoder0.readServiceInterface(88, false, SharedWorkerHost.MANAGER);
                result.sharedWorker = decoder0.readInterfaceRequest(96, false);
                result.interfaceProvider = (InterfaceProvider) decoder0.readServiceInterface(100, false, InterfaceProvider.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.info, 8, false);
            encoder0.encode(this.pauseOnStart, 16, 0);
            encoder0.encode((InterfaceRequest) this.preferenceWatcherRequest, 20, false);
            encoder0.encode((Struct) this.devtoolsWorkerToken, 24, false);
            encoder0.encode((Struct) this.rendererPreferences, 32, false);
            encoder0.encode((Encoder) this.contentSettings, 40, false, (Interface.Manager<Encoder, ?>) WorkerContentSettingsProxy.MANAGER);
            encoder0.encode((Struct) this.serviceWorkerProviderInfo, 48, true);
            encoder0.encode((Struct) this.appcacheHostId, 56, true);
            encoder0.encode((Struct) this.mainScriptLoadParams, 64, false);
            encoder0.encode((Struct) this.subresourceLoaderFactories, 72, false);
            encoder0.encode((Struct) this.controllerInfo, 80, true);
            encoder0.encode((Encoder) this.host, 88, false, (Interface.Manager<Encoder, ?>) SharedWorkerHost.MANAGER);
            encoder0.encode((InterfaceRequest) this.sharedWorker, 96, false);
            encoder0.encode((Encoder) this.interfaceProvider, 100, false, (Interface.Manager<Encoder, ?>) InterfaceProvider.MANAGER);
        }
    }
}
