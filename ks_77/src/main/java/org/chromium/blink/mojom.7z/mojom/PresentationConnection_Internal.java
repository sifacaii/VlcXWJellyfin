package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.PresentationConnection;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.bindings.Union;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal.class */
class PresentationConnection_Internal {
    public static final Interface.Manager<PresentationConnection, PresentationConnection.Proxy> MANAGER = new Interface.Manager<PresentationConnection, PresentationConnection.Proxy>() { // from class: org.chromium.blink.mojom.PresentationConnection_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.PresentationConnection";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public PresentationConnection.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, PresentationConnection impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public PresentationConnection[] buildArray(int size) {
            return new PresentationConnection[size];
        }
    };
    private static final int ON_MESSAGE_ORDINAL = 0;
    private static final int DID_CHANGE_STATE_ORDINAL = 1;
    private static final int DID_CLOSE_ORDINAL = 2;

    PresentationConnection_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements PresentationConnection.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.PresentationConnection
        public void onMessage(PresentationConnectionMessage message) {
            PresentationConnectionOnMessageParams _message = new PresentationConnectionOnMessageParams();
            _message.message = message;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.PresentationConnection
        public void didChangeState(int state) {
            PresentationConnectionDidChangeStateParams _message = new PresentationConnectionDidChangeStateParams();
            _message.state = state;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.PresentationConnection
        public void didClose(int reason) {
            PresentationConnectionDidCloseParams _message = new PresentationConnectionDidCloseParams();
            _message.reason = reason;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<PresentationConnection> {
        Stub(Core core, PresentationConnection impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(PresentationConnection_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        PresentationConnectionOnMessageParams data = PresentationConnectionOnMessageParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onMessage(data.message);
                        return true;
                    case 1:
                        PresentationConnectionDidChangeStateParams data2 = PresentationConnectionDidChangeStateParams.deserialize(messageWithHeader.getPayload());
                        getImpl().didChangeState(data2.state);
                        return true;
                    case 2:
                        PresentationConnectionDidCloseParams data3 = PresentationConnectionDidCloseParams.deserialize(messageWithHeader.getPayload());
                        getImpl().didClose(data3.reason);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), PresentationConnection_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal$PresentationConnectionOnMessageParams.class */
    static final class PresentationConnectionOnMessageParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public PresentationConnectionMessage message;

        private PresentationConnectionOnMessageParams(int version) {
            super(24, version);
        }

        public PresentationConnectionOnMessageParams() {
            this(0);
        }

        public static PresentationConnectionOnMessageParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static PresentationConnectionOnMessageParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static PresentationConnectionOnMessageParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                PresentationConnectionOnMessageParams result = new PresentationConnectionOnMessageParams(elementsOrVersion);
                result.message = PresentationConnectionMessage.decode(decoder0, 8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Union) this.message, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal$PresentationConnectionDidChangeStateParams.class */
    static final class PresentationConnectionDidChangeStateParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int state;

        private PresentationConnectionDidChangeStateParams(int version) {
            super(16, version);
        }

        public PresentationConnectionDidChangeStateParams() {
            this(0);
        }

        public static PresentationConnectionDidChangeStateParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static PresentationConnectionDidChangeStateParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static PresentationConnectionDidChangeStateParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                PresentationConnectionDidChangeStateParams result = new PresentationConnectionDidChangeStateParams(elementsOrVersion);
                result.state = decoder0.readInt(8);
                PresentationConnectionState.validate(result.state);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.state, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PresentationConnection_Internal$PresentationConnectionDidCloseParams.class */
    static final class PresentationConnectionDidCloseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int reason;

        private PresentationConnectionDidCloseParams(int version) {
            super(16, version);
        }

        public PresentationConnectionDidCloseParams() {
            this(0);
        }

        public static PresentationConnectionDidCloseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static PresentationConnectionDidCloseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static PresentationConnectionDidCloseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                PresentationConnectionDidCloseParams result = new PresentationConnectionDidCloseParams(elementsOrVersion);
                result.reason = decoder0.readInt(8);
                PresentationConnectionCloseReason.validate(result.reason);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.reason, 8);
        }
    }
}
