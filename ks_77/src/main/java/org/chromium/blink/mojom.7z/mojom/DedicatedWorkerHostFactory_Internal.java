package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.DedicatedWorkerHostFactory;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.InterfaceRequest;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.network.mojom.CredentialsMode;
import org.chromium.service_manager.mojom.InterfaceProvider;
import org.chromium.url.mojom.Origin;
import org.chromium.url.mojom.Url;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactory_Internal.class */
class DedicatedWorkerHostFactory_Internal {
    public static final Interface.Manager<DedicatedWorkerHostFactory, DedicatedWorkerHostFactory.Proxy> MANAGER = new Interface.Manager<DedicatedWorkerHostFactory, DedicatedWorkerHostFactory.Proxy>() { // from class: org.chromium.blink.mojom.DedicatedWorkerHostFactory_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.DedicatedWorkerHostFactory";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public DedicatedWorkerHostFactory.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, DedicatedWorkerHostFactory impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public DedicatedWorkerHostFactory[] buildArray(int size) {
            return new DedicatedWorkerHostFactory[size];
        }
    };
    private static final int CREATE_WORKER_HOST_ORDINAL = 0;
    private static final int CREATE_WORKER_HOST_AND_START_SCRIPT_LOAD_ORDINAL = 1;

    DedicatedWorkerHostFactory_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactory_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements DedicatedWorkerHostFactory.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.DedicatedWorkerHostFactory
        public void createWorkerHost(Origin origin, InterfaceRequest<InterfaceProvider> workerInterfaceProvider) {
            DedicatedWorkerHostFactoryCreateWorkerHostParams _message = new DedicatedWorkerHostFactoryCreateWorkerHostParams();
            _message.origin = origin;
            _message.workerInterfaceProvider = workerInterfaceProvider;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.DedicatedWorkerHostFactory
        public void createWorkerHostAndStartScriptLoad(Url scriptUrl, Origin origin, int credentialsMode, FetchClientSettingsObject outsideFetchClientSettingsObject, BlobUrlToken blobUrlToken, DedicatedWorkerHostFactoryClient client) {
            DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams _message = new DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams();
            _message.scriptUrl = scriptUrl;
            _message.origin = origin;
            _message.credentialsMode = credentialsMode;
            _message.outsideFetchClientSettingsObject = outsideFetchClientSettingsObject;
            _message.blobUrlToken = blobUrlToken;
            _message.client = client;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactory_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<DedicatedWorkerHostFactory> {
        Stub(Core core, DedicatedWorkerHostFactory impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(DedicatedWorkerHostFactory_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        DedicatedWorkerHostFactoryCreateWorkerHostParams data = DedicatedWorkerHostFactoryCreateWorkerHostParams.deserialize(messageWithHeader.getPayload());
                        getImpl().createWorkerHost(data.origin, data.workerInterfaceProvider);
                        return true;
                    case 1:
                        DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams data2 = DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams.deserialize(messageWithHeader.getPayload());
                        getImpl().createWorkerHostAndStartScriptLoad(data2.scriptUrl, data2.origin, data2.credentialsMode, data2.outsideFetchClientSettingsObject, data2.blobUrlToken, data2.client);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), DedicatedWorkerHostFactory_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactory_Internal$DedicatedWorkerHostFactoryCreateWorkerHostParams.class */
    static final class DedicatedWorkerHostFactoryCreateWorkerHostParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public InterfaceRequest<InterfaceProvider> workerInterfaceProvider;

        private DedicatedWorkerHostFactoryCreateWorkerHostParams(int version) {
            super(24, version);
        }

        public DedicatedWorkerHostFactoryCreateWorkerHostParams() {
            this(0);
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                DedicatedWorkerHostFactoryCreateWorkerHostParams result = new DedicatedWorkerHostFactoryCreateWorkerHostParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                result.workerInterfaceProvider = decoder0.readInterfaceRequest(16, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode((InterfaceRequest) this.workerInterfaceProvider, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/DedicatedWorkerHostFactory_Internal$DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams.class */
    static final class DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams extends Struct {
        private static final int STRUCT_SIZE = 56;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(56, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Url scriptUrl;
        public Origin origin;
        public int credentialsMode;
        public FetchClientSettingsObject outsideFetchClientSettingsObject;
        public BlobUrlToken blobUrlToken;
        public DedicatedWorkerHostFactoryClient client;

        private DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams(int version) {
            super(56, version);
        }

        public DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams() {
            this(0);
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams result = new DedicatedWorkerHostFactoryCreateWorkerHostAndStartScriptLoadParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.scriptUrl = Url.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.origin = Origin.decode(decoder12);
                result.credentialsMode = decoder0.readInt(24);
                CredentialsMode.validate(result.credentialsMode);
                Decoder decoder13 = decoder0.readPointer(32, false);
                result.outsideFetchClientSettingsObject = FetchClientSettingsObject.decode(decoder13);
                result.blobUrlToken = (BlobUrlToken) decoder0.readServiceInterface(40, true, BlobUrlToken.MANAGER);
                result.client = (DedicatedWorkerHostFactoryClient) decoder0.readServiceInterface(48, false, DedicatedWorkerHostFactoryClient.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.scriptUrl, 8, false);
            encoder0.encode((Struct) this.origin, 16, false);
            encoder0.encode(this.credentialsMode, 24);
            encoder0.encode((Struct) this.outsideFetchClientSettingsObject, 32, false);
            encoder0.encode((Encoder) this.blobUrlToken, 40, true, (Interface.Manager<Encoder, ?>) BlobUrlToken.MANAGER);
            encoder0.encode((Encoder) this.client, 48, false, (Interface.Manager<Encoder, ?>) DedicatedWorkerHostFactoryClient.MANAGER);
        }
    }
}
