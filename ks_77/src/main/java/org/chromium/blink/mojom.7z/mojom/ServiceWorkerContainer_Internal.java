package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.ServiceWorkerContainer;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal.class */
class ServiceWorkerContainer_Internal {
    public static final Interface.Manager<ServiceWorkerContainer, ServiceWorkerContainer.Proxy> MANAGER = new Interface.Manager<ServiceWorkerContainer, ServiceWorkerContainer.Proxy>() { // from class: org.chromium.blink.mojom.ServiceWorkerContainer_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.ServiceWorkerContainer";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public ServiceWorkerContainer.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, ServiceWorkerContainer impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public ServiceWorkerContainer[] buildArray(int size) {
            return new ServiceWorkerContainer[size];
        }
    };
    private static final int SET_CONTROLLER_ORDINAL = 0;
    private static final int POST_MESSAGE_TO_CLIENT_ORDINAL = 1;
    private static final int COUNT_FEATURE_ORDINAL = 2;

    ServiceWorkerContainer_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements ServiceWorkerContainer.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerContainer
        public void setController(ControllerServiceWorkerInfo controllerInfo, boolean shouldNotifyControllerchange) {
            ServiceWorkerContainerSetControllerParams _message = new ServiceWorkerContainerSetControllerParams();
            _message.controllerInfo = controllerInfo;
            _message.shouldNotifyControllerchange = shouldNotifyControllerchange;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerContainer
        public void postMessageToClient(ServiceWorkerObjectInfo source, TransferableMessage message) {
            ServiceWorkerContainerPostMessageToClientParams _message = new ServiceWorkerContainerPostMessageToClientParams();
            _message.source = source;
            _message.message = message;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.ServiceWorkerContainer
        public void countFeature(int feature) {
            ServiceWorkerContainerCountFeatureParams _message = new ServiceWorkerContainerCountFeatureParams();
            _message.feature = feature;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<ServiceWorkerContainer> {
        Stub(Core core, ServiceWorkerContainer impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(ServiceWorkerContainer_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        ServiceWorkerContainerSetControllerParams data = ServiceWorkerContainerSetControllerParams.deserialize(messageWithHeader.getPayload());
                        getImpl().setController(data.controllerInfo, data.shouldNotifyControllerchange);
                        return true;
                    case 1:
                        ServiceWorkerContainerPostMessageToClientParams data2 = ServiceWorkerContainerPostMessageToClientParams.deserialize(messageWithHeader.getPayload());
                        getImpl().postMessageToClient(data2.source, data2.message);
                        return true;
                    case 2:
                        getImpl().countFeature(ServiceWorkerContainerCountFeatureParams.deserialize(messageWithHeader.getPayload()).feature);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), ServiceWorkerContainer_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal$ServiceWorkerContainerSetControllerParams.class */
    static final class ServiceWorkerContainerSetControllerParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public ControllerServiceWorkerInfo controllerInfo;
        public boolean shouldNotifyControllerchange;

        private ServiceWorkerContainerSetControllerParams(int version) {
            super(24, version);
        }

        public ServiceWorkerContainerSetControllerParams() {
            this(0);
        }

        public static ServiceWorkerContainerSetControllerParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerContainerSetControllerParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerContainerSetControllerParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerContainerSetControllerParams result = new ServiceWorkerContainerSetControllerParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.controllerInfo = ControllerServiceWorkerInfo.decode(decoder1);
                result.shouldNotifyControllerchange = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.controllerInfo, 8, false);
            encoder0.encode(this.shouldNotifyControllerchange, 16, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal$ServiceWorkerContainerPostMessageToClientParams.class */
    static final class ServiceWorkerContainerPostMessageToClientParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public ServiceWorkerObjectInfo source;
        public TransferableMessage message;

        private ServiceWorkerContainerPostMessageToClientParams(int version) {
            super(24, version);
        }

        public ServiceWorkerContainerPostMessageToClientParams() {
            this(0);
        }

        public static ServiceWorkerContainerPostMessageToClientParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerContainerPostMessageToClientParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerContainerPostMessageToClientParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerContainerPostMessageToClientParams result = new ServiceWorkerContainerPostMessageToClientParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.source = ServiceWorkerObjectInfo.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.message = TransferableMessage.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.source, 8, false);
            encoder0.encode((Struct) this.message, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerContainer_Internal$ServiceWorkerContainerCountFeatureParams.class */
    static final class ServiceWorkerContainerCountFeatureParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int feature;

        private ServiceWorkerContainerCountFeatureParams(int version) {
            super(16, version);
        }

        public ServiceWorkerContainerCountFeatureParams() {
            this(0);
        }

        public static ServiceWorkerContainerCountFeatureParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static ServiceWorkerContainerCountFeatureParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static ServiceWorkerContainerCountFeatureParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                ServiceWorkerContainerCountFeatureParams result = new ServiceWorkerContainerCountFeatureParams(elementsOrVersion);
                result.feature = decoder0.readInt(8);
                WebFeature.validate(result.feature);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.feature, 8);
        }
    }
}
