package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.FileChooser;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.mojo_base.mojom.FilePath;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal.class */
class FileChooser_Internal {
    public static final Interface.Manager<FileChooser, FileChooser.Proxy> MANAGER = new Interface.Manager<FileChooser, FileChooser.Proxy>() { // from class: org.chromium.blink.mojom.FileChooser_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.FileChooser";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public FileChooser.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, FileChooser impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public FileChooser[] buildArray(int size) {
            return new FileChooser[size];
        }
    };
    private static final int OPEN_FILE_CHOOSER_ORDINAL = 0;
    private static final int ENUMERATE_CHOSEN_DIRECTORY_ORDINAL = 1;

    FileChooser_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements FileChooser.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.FileChooser
        public void openFileChooser(FileChooserParams params, FileChooser.OpenFileChooserResponse callback) {
            FileChooserOpenFileChooserParams _message = new FileChooserOpenFileChooserParams();
            _message.params = params;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new FileChooserOpenFileChooserResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.FileChooser
        public void enumerateChosenDirectory(FilePath directoryPath, FileChooser.EnumerateChosenDirectoryResponse callback) {
            FileChooserEnumerateChosenDirectoryParams _message = new FileChooserEnumerateChosenDirectoryParams();
            _message.directoryPath = directoryPath;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new FileChooserEnumerateChosenDirectoryResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<FileChooser> {
        Stub(Core core, FileChooser impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(FileChooser_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), FileChooser_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        FileChooserOpenFileChooserParams data = FileChooserOpenFileChooserParams.deserialize(messageWithHeader.getPayload());
                        getImpl().openFileChooser(data.params, new FileChooserOpenFileChooserResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        FileChooserEnumerateChosenDirectoryParams data2 = FileChooserEnumerateChosenDirectoryParams.deserialize(messageWithHeader.getPayload());
                        getImpl().enumerateChosenDirectory(data2.directoryPath, new FileChooserEnumerateChosenDirectoryResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserOpenFileChooserParams.class */
    static final class FileChooserOpenFileChooserParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public FileChooserParams params;

        private FileChooserOpenFileChooserParams(int version) {
            super(16, version);
        }

        public FileChooserOpenFileChooserParams() {
            this(0);
        }

        public static FileChooserOpenFileChooserParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FileChooserOpenFileChooserParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FileChooserOpenFileChooserParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FileChooserOpenFileChooserParams result = new FileChooserOpenFileChooserParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.params = FileChooserParams.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.params, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserOpenFileChooserResponseParams.class */
    public static final class FileChooserOpenFileChooserResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public FileChooserResult result;

        private FileChooserOpenFileChooserResponseParams(int version) {
            super(16, version);
        }

        public FileChooserOpenFileChooserResponseParams() {
            this(0);
        }

        public static FileChooserOpenFileChooserResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FileChooserOpenFileChooserResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FileChooserOpenFileChooserResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FileChooserOpenFileChooserResponseParams result = new FileChooserOpenFileChooserResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, true);
                result.result = FileChooserResult.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserOpenFileChooserResponseParamsForwardToCallback.class */
    static class FileChooserOpenFileChooserResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final FileChooser.OpenFileChooserResponse mCallback;

        FileChooserOpenFileChooserResponseParamsForwardToCallback(FileChooser.OpenFileChooserResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                FileChooserOpenFileChooserResponseParams response = FileChooserOpenFileChooserResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserOpenFileChooserResponseParamsProxyToResponder.class */
    static class FileChooserOpenFileChooserResponseParamsProxyToResponder implements FileChooser.OpenFileChooserResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        FileChooserOpenFileChooserResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(FileChooserResult result) {
            FileChooserOpenFileChooserResponseParams _response = new FileChooserOpenFileChooserResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserEnumerateChosenDirectoryParams.class */
    static final class FileChooserEnumerateChosenDirectoryParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public FilePath directoryPath;

        private FileChooserEnumerateChosenDirectoryParams(int version) {
            super(16, version);
        }

        public FileChooserEnumerateChosenDirectoryParams() {
            this(0);
        }

        public static FileChooserEnumerateChosenDirectoryParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FileChooserEnumerateChosenDirectoryParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FileChooserEnumerateChosenDirectoryParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FileChooserEnumerateChosenDirectoryParams result = new FileChooserEnumerateChosenDirectoryParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.directoryPath = FilePath.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.directoryPath, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserEnumerateChosenDirectoryResponseParams.class */
    public static final class FileChooserEnumerateChosenDirectoryResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public FileChooserResult result;

        private FileChooserEnumerateChosenDirectoryResponseParams(int version) {
            super(16, version);
        }

        public FileChooserEnumerateChosenDirectoryResponseParams() {
            this(0);
        }

        public static FileChooserEnumerateChosenDirectoryResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FileChooserEnumerateChosenDirectoryResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FileChooserEnumerateChosenDirectoryResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FileChooserEnumerateChosenDirectoryResponseParams result = new FileChooserEnumerateChosenDirectoryResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, true);
                result.result = FileChooserResult.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserEnumerateChosenDirectoryResponseParamsForwardToCallback.class */
    static class FileChooserEnumerateChosenDirectoryResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final FileChooser.EnumerateChosenDirectoryResponse mCallback;

        FileChooserEnumerateChosenDirectoryResponseParamsForwardToCallback(FileChooser.EnumerateChosenDirectoryResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                FileChooserEnumerateChosenDirectoryResponseParams response = FileChooserEnumerateChosenDirectoryResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FileChooser_Internal$FileChooserEnumerateChosenDirectoryResponseParamsProxyToResponder.class */
    static class FileChooserEnumerateChosenDirectoryResponseParamsProxyToResponder implements FileChooser.EnumerateChosenDirectoryResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        FileChooserEnumerateChosenDirectoryResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(FileChooserResult result) {
            FileChooserEnumerateChosenDirectoryResponseParams _response = new FileChooserEnumerateChosenDirectoryResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
