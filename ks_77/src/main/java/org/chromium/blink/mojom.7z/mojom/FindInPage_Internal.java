package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.FindInPage;
import org.chromium.gfx.mojom.PointF;
import org.chromium.gfx.mojom.RectF;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal.class */
class FindInPage_Internal {
    public static final Interface.Manager<FindInPage, FindInPage.Proxy> MANAGER = new Interface.Manager<FindInPage, FindInPage.Proxy>() { // from class: org.chromium.blink.mojom.FindInPage_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.FindInPage";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public FindInPage.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, FindInPage impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public FindInPage[] buildArray(int size) {
            return new FindInPage[size];
        }
    };
    private static final int FIND_ORDINAL = 0;
    private static final int STOP_FINDING_ORDINAL = 1;
    private static final int CLEAR_ACTIVE_FIND_MATCH_ORDINAL = 2;
    private static final int GET_NEAREST_FIND_RESULT_ORDINAL = 3;
    private static final int ACTIVATE_NEAREST_FIND_RESULT_ORDINAL = 4;
    private static final int SET_CLIENT_ORDINAL = 5;
    private static final int FIND_MATCH_RECTS_ORDINAL = 6;

    FindInPage_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements FindInPage.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void find(int requestId, String searchText, FindOptions options) {
            FindInPageFindParams _message = new FindInPageFindParams();
            _message.requestId = requestId;
            _message.searchText = searchText;
            _message.options = options;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void stopFinding(int action) {
            FindInPageStopFindingParams _message = new FindInPageStopFindingParams();
            _message.action = action;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void clearActiveFindMatch() {
            FindInPageClearActiveFindMatchParams _message = new FindInPageClearActiveFindMatchParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void getNearestFindResult(PointF point, FindInPage.GetNearestFindResultResponse callback) {
            FindInPageGetNearestFindResultParams _message = new FindInPageGetNearestFindResultParams();
            _message.point = point;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new FindInPageGetNearestFindResultResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void activateNearestFindResult(int requestId, PointF point) {
            FindInPageActivateNearestFindResultParams _message = new FindInPageActivateNearestFindResultParams();
            _message.requestId = requestId;
            _message.point = point;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4)));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void setClient(FindInPageClient client) {
            FindInPageSetClientParams _message = new FindInPageSetClientParams();
            _message.client = client;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5)));
        }

        @Override // org.chromium.blink.mojom.FindInPage
        public void findMatchRects(int currentVersion, FindInPage.FindMatchRectsResponse callback) {
            FindInPageFindMatchRectsParams _message = new FindInPageFindMatchRectsParams();
            _message.currentVersion = currentVersion;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(6, 1, 0L)), new FindInPageFindMatchRectsResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<FindInPage> {
        Stub(Core core, FindInPage impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(FindInPage_Internal.MANAGER, messageWithHeader);
                    case -1:
                    case 3:
                    default:
                        return false;
                    case 0:
                        FindInPageFindParams data = FindInPageFindParams.deserialize(messageWithHeader.getPayload());
                        getImpl().find(data.requestId, data.searchText, data.options);
                        return true;
                    case 1:
                        FindInPageStopFindingParams data2 = FindInPageStopFindingParams.deserialize(messageWithHeader.getPayload());
                        getImpl().stopFinding(data2.action);
                        return true;
                    case 2:
                        FindInPageClearActiveFindMatchParams.deserialize(messageWithHeader.getPayload());
                        getImpl().clearActiveFindMatch();
                        return true;
                    case 4:
                        FindInPageActivateNearestFindResultParams data3 = FindInPageActivateNearestFindResultParams.deserialize(messageWithHeader.getPayload());
                        getImpl().activateNearestFindResult(data3.requestId, data3.point);
                        return true;
                    case 5:
                        getImpl().setClient(FindInPageSetClientParams.deserialize(messageWithHeader.getPayload()).client);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), FindInPage_Internal.MANAGER, messageWithHeader, receiver);
                    case 3:
                        FindInPageGetNearestFindResultParams data = FindInPageGetNearestFindResultParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getNearestFindResult(data.point, new FindInPageGetNearestFindResultResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 6:
                        FindInPageFindMatchRectsParams data2 = FindInPageFindMatchRectsParams.deserialize(messageWithHeader.getPayload());
                        getImpl().findMatchRects(data2.currentVersion, new FindInPageFindMatchRectsResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageFindParams.class */
    static final class FindInPageFindParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int requestId;
        public String searchText;
        public FindOptions options;

        private FindInPageFindParams(int version) {
            super(32, version);
        }

        public FindInPageFindParams() {
            this(0);
        }

        public static FindInPageFindParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageFindParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageFindParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageFindParams result = new FindInPageFindParams(elementsOrVersion);
                result.requestId = decoder0.readInt(8);
                result.searchText = decoder0.readString(16, false);
                Decoder decoder1 = decoder0.readPointer(24, false);
                result.options = FindOptions.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.requestId, 8);
            encoder0.encode(this.searchText, 16, false);
            encoder0.encode((Struct) this.options, 24, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageStopFindingParams.class */
    static final class FindInPageStopFindingParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int action;

        private FindInPageStopFindingParams(int version) {
            super(16, version);
        }

        public FindInPageStopFindingParams() {
            this(0);
        }

        public static FindInPageStopFindingParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageStopFindingParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageStopFindingParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageStopFindingParams result = new FindInPageStopFindingParams(elementsOrVersion);
                result.action = decoder0.readInt(8);
                StopFindAction.validate(result.action);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.action, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageClearActiveFindMatchParams.class */
    static final class FindInPageClearActiveFindMatchParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private FindInPageClearActiveFindMatchParams(int version) {
            super(8, version);
        }

        public FindInPageClearActiveFindMatchParams() {
            this(0);
        }

        public static FindInPageClearActiveFindMatchParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageClearActiveFindMatchParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageClearActiveFindMatchParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageClearActiveFindMatchParams result = new FindInPageClearActiveFindMatchParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageGetNearestFindResultParams.class */
    static final class FindInPageGetNearestFindResultParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public PointF point;

        private FindInPageGetNearestFindResultParams(int version) {
            super(16, version);
        }

        public FindInPageGetNearestFindResultParams() {
            this(0);
        }

        public static FindInPageGetNearestFindResultParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageGetNearestFindResultParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageGetNearestFindResultParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageGetNearestFindResultParams result = new FindInPageGetNearestFindResultParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.point = PointF.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.point, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageGetNearestFindResultResponseParams.class */
    public static final class FindInPageGetNearestFindResultResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public float distance;

        private FindInPageGetNearestFindResultResponseParams(int version) {
            super(16, version);
        }

        public FindInPageGetNearestFindResultResponseParams() {
            this(0);
        }

        public static FindInPageGetNearestFindResultResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageGetNearestFindResultResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageGetNearestFindResultResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageGetNearestFindResultResponseParams result = new FindInPageGetNearestFindResultResponseParams(elementsOrVersion);
                result.distance = decoder0.readFloat(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.distance, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageGetNearestFindResultResponseParamsForwardToCallback.class */
    static class FindInPageGetNearestFindResultResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final FindInPage.GetNearestFindResultResponse mCallback;

        FindInPageGetNearestFindResultResponseParamsForwardToCallback(FindInPage.GetNearestFindResultResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                FindInPageGetNearestFindResultResponseParams response = FindInPageGetNearestFindResultResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Float.valueOf(response.distance));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageGetNearestFindResultResponseParamsProxyToResponder.class */
    static class FindInPageGetNearestFindResultResponseParamsProxyToResponder implements FindInPage.GetNearestFindResultResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        FindInPageGetNearestFindResultResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Float distance) {
            FindInPageGetNearestFindResultResponseParams _response = new FindInPageGetNearestFindResultResponseParams();
            _response.distance = distance.floatValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageActivateNearestFindResultParams.class */
    static final class FindInPageActivateNearestFindResultParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int requestId;
        public PointF point;

        private FindInPageActivateNearestFindResultParams(int version) {
            super(24, version);
        }

        public FindInPageActivateNearestFindResultParams() {
            this(0);
        }

        public static FindInPageActivateNearestFindResultParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageActivateNearestFindResultParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageActivateNearestFindResultParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageActivateNearestFindResultParams result = new FindInPageActivateNearestFindResultParams(elementsOrVersion);
                result.requestId = decoder0.readInt(8);
                Decoder decoder1 = decoder0.readPointer(16, false);
                result.point = PointF.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.requestId, 8);
            encoder0.encode((Struct) this.point, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageSetClientParams.class */
    static final class FindInPageSetClientParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public FindInPageClient client;

        private FindInPageSetClientParams(int version) {
            super(16, version);
        }

        public FindInPageSetClientParams() {
            this(0);
        }

        public static FindInPageSetClientParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageSetClientParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageSetClientParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageSetClientParams result = new FindInPageSetClientParams(elementsOrVersion);
                result.client = (FindInPageClient) decoder0.readServiceInterface(8, false, FindInPageClient.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Encoder) this.client, 8, false, (Interface.Manager<Encoder, ?>) FindInPageClient.MANAGER);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageFindMatchRectsParams.class */
    static final class FindInPageFindMatchRectsParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int currentVersion;

        private FindInPageFindMatchRectsParams(int version) {
            super(16, version);
        }

        public FindInPageFindMatchRectsParams() {
            this(0);
        }

        public static FindInPageFindMatchRectsParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageFindMatchRectsParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageFindMatchRectsParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageFindMatchRectsParams result = new FindInPageFindMatchRectsParams(elementsOrVersion);
                result.currentVersion = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.currentVersion, 8);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageFindMatchRectsResponseParams.class */
    public static final class FindInPageFindMatchRectsResponseParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int version;
        public RectF[] rects;
        public RectF activeMatchRect;

        private FindInPageFindMatchRectsResponseParams(int version) {
            super(32, version);
        }

        public FindInPageFindMatchRectsResponseParams() {
            this(0);
        }

        public static FindInPageFindMatchRectsResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static FindInPageFindMatchRectsResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static FindInPageFindMatchRectsResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                FindInPageFindMatchRectsResponseParams result = new FindInPageFindMatchRectsResponseParams(elementsOrVersion);
                result.version = decoder0.readInt(8);
                Decoder decoder1 = decoder0.readPointer(16, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.rects = new RectF[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.rects[i1] = RectF.decode(decoder2);
                }
                result.activeMatchRect = RectF.decode(decoder0.readPointer(24, false));
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.version, 8);
            if (this.rects == null) {
                encoder0.encodeNullPointer(16, false);
            } else {
                Encoder encoder1 = encoder0.encodePointerArray(this.rects.length, 16, -1);
                for (int i0 = 0; i0 < this.rects.length; i0++) {
                    encoder1.encode((Struct) this.rects[i0], 8 + (8 * i0), false);
                }
            }
            encoder0.encode((Struct) this.activeMatchRect, 24, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageFindMatchRectsResponseParamsForwardToCallback.class */
    static class FindInPageFindMatchRectsResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final FindInPage.FindMatchRectsResponse mCallback;

        FindInPageFindMatchRectsResponseParamsForwardToCallback(FindInPage.FindMatchRectsResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(6, 2)) {
                    return false;
                }
                FindInPageFindMatchRectsResponseParams response = FindInPageFindMatchRectsResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.version), response.rects, response.activeMatchRect);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/FindInPage_Internal$FindInPageFindMatchRectsResponseParamsProxyToResponder.class */
    static class FindInPageFindMatchRectsResponseParamsProxyToResponder implements FindInPage.FindMatchRectsResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        FindInPageFindMatchRectsResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback3
        public void call(Integer version, RectF[] rects, RectF activeMatchRect) {
            FindInPageFindMatchRectsResponseParams _response = new FindInPageFindMatchRectsResponseParams();
            _response.version = version.intValue();
            _response.rects = rects;
            _response.activeMatchRect = activeMatchRect;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(6, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
