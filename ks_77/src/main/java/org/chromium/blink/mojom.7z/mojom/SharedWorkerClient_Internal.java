package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.SharedWorkerClient;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal.class */
class SharedWorkerClient_Internal {
    public static final Interface.Manager<SharedWorkerClient, SharedWorkerClient.Proxy> MANAGER = new Interface.Manager<SharedWorkerClient, SharedWorkerClient.Proxy>() { // from class: org.chromium.blink.mojom.SharedWorkerClient_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.SharedWorkerClient";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public SharedWorkerClient.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, SharedWorkerClient impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public SharedWorkerClient[] buildArray(int size) {
            return new SharedWorkerClient[size];
        }
    };
    private static final int ON_CREATED_ORDINAL = 0;
    private static final int ON_CONNECTED_ORDINAL = 1;
    private static final int ON_SCRIPT_LOAD_FAILED_ORDINAL = 2;
    private static final int ON_FEATURE_USED_ORDINAL = 3;

    SharedWorkerClient_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements SharedWorkerClient.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.SharedWorkerClient
        public void onCreated(int creationContextType) {
            SharedWorkerClientOnCreatedParams _message = new SharedWorkerClientOnCreatedParams();
            _message.creationContextType = creationContextType;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.SharedWorkerClient
        public void onConnected(int[] featuresUsed) {
            SharedWorkerClientOnConnectedParams _message = new SharedWorkerClientOnConnectedParams();
            _message.featuresUsed = featuresUsed;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.SharedWorkerClient
        public void onScriptLoadFailed() {
            SharedWorkerClientOnScriptLoadFailedParams _message = new SharedWorkerClientOnScriptLoadFailedParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.SharedWorkerClient
        public void onFeatureUsed(int feature) {
            SharedWorkerClientOnFeatureUsedParams _message = new SharedWorkerClientOnFeatureUsedParams();
            _message.feature = feature;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<SharedWorkerClient> {
        Stub(Core core, SharedWorkerClient impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(SharedWorkerClient_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        SharedWorkerClientOnCreatedParams data = SharedWorkerClientOnCreatedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onCreated(data.creationContextType);
                        return true;
                    case 1:
                        SharedWorkerClientOnConnectedParams data2 = SharedWorkerClientOnConnectedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onConnected(data2.featuresUsed);
                        return true;
                    case 2:
                        SharedWorkerClientOnScriptLoadFailedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onScriptLoadFailed();
                        return true;
                    case 3:
                        SharedWorkerClientOnFeatureUsedParams data3 = SharedWorkerClientOnFeatureUsedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onFeatureUsed(data3.feature);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), SharedWorkerClient_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$SharedWorkerClientOnCreatedParams.class */
    static final class SharedWorkerClientOnCreatedParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int creationContextType;

        private SharedWorkerClientOnCreatedParams(int version) {
            super(16, version);
        }

        public SharedWorkerClientOnCreatedParams() {
            this(0);
        }

        public static SharedWorkerClientOnCreatedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static SharedWorkerClientOnCreatedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static SharedWorkerClientOnCreatedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                SharedWorkerClientOnCreatedParams result = new SharedWorkerClientOnCreatedParams(elementsOrVersion);
                result.creationContextType = decoder0.readInt(8);
                SharedWorkerCreationContextType.validate(result.creationContextType);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.creationContextType, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$SharedWorkerClientOnConnectedParams.class */
    static final class SharedWorkerClientOnConnectedParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int[] featuresUsed;

        private SharedWorkerClientOnConnectedParams(int version) {
            super(16, version);
        }

        public SharedWorkerClientOnConnectedParams() {
            this(0);
        }

        public static SharedWorkerClientOnConnectedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static SharedWorkerClientOnConnectedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static SharedWorkerClientOnConnectedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                SharedWorkerClientOnConnectedParams result = new SharedWorkerClientOnConnectedParams(elementsOrVersion);
                result.featuresUsed = decoder0.readInts(8, 0, -1);
                for (int i0 = 0; i0 < result.featuresUsed.length; i0++) {
                    WebFeature.validate(result.featuresUsed[i0]);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.featuresUsed, 8, 0, -1);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$SharedWorkerClientOnScriptLoadFailedParams.class */
    static final class SharedWorkerClientOnScriptLoadFailedParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private SharedWorkerClientOnScriptLoadFailedParams(int version) {
            super(8, version);
        }

        public SharedWorkerClientOnScriptLoadFailedParams() {
            this(0);
        }

        public static SharedWorkerClientOnScriptLoadFailedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static SharedWorkerClientOnScriptLoadFailedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static SharedWorkerClientOnScriptLoadFailedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                SharedWorkerClientOnScriptLoadFailedParams result = new SharedWorkerClientOnScriptLoadFailedParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/SharedWorkerClient_Internal$SharedWorkerClientOnFeatureUsedParams.class */
    static final class SharedWorkerClientOnFeatureUsedParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int feature;

        private SharedWorkerClientOnFeatureUsedParams(int version) {
            super(16, version);
        }

        public SharedWorkerClientOnFeatureUsedParams() {
            this(0);
        }

        public static SharedWorkerClientOnFeatureUsedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static SharedWorkerClientOnFeatureUsedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static SharedWorkerClientOnFeatureUsedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                SharedWorkerClientOnFeatureUsedParams result = new SharedWorkerClientOnFeatureUsedParams(elementsOrVersion);
                result.feature = decoder0.readInt(8);
                WebFeature.validate(result.feature);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.feature, 8);
        }
    }
}
