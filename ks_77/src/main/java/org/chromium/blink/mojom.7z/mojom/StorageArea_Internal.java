package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.StorageArea;
import org.chromium.mojo.bindings.AssociatedInterfaceNotSupported;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal.class */
class StorageArea_Internal {
    public static final Interface.Manager<StorageArea, StorageArea.Proxy> MANAGER = new Interface.Manager<StorageArea, StorageArea.Proxy>() { // from class: org.chromium.blink.mojom.StorageArea_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.StorageArea";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public StorageArea.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, StorageArea impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public StorageArea[] buildArray(int size) {
            return new StorageArea[size];
        }
    };
    private static final int ADD_OBSERVER_ORDINAL = 0;
    private static final int PUT_ORDINAL = 1;
    private static final int DELETE_ORDINAL = 2;
    private static final int DELETE_ALL_ORDINAL = 3;
    private static final int GET_ORDINAL = 4;
    private static final int GET_ALL_ORDINAL = 5;

    StorageArea_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements StorageArea.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void addObserver(AssociatedInterfaceNotSupported observer) {
            StorageAreaAddObserverParams _message = new StorageAreaAddObserverParams();
            _message.observer = observer;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void put(byte[] key, byte[] value, byte[] clientOldValue, String source, StorageArea.PutResponse callback) {
            StorageAreaPutParams _message = new StorageAreaPutParams();
            _message.key = key;
            _message.value = value;
            _message.clientOldValue = clientOldValue;
            _message.source = source;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new StorageAreaPutResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void delete(byte[] key, byte[] clientOldValue, String source, StorageArea.DeleteResponse callback) {
            StorageAreaDeleteParams _message = new StorageAreaDeleteParams();
            _message.key = key;
            _message.clientOldValue = clientOldValue;
            _message.source = source;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new StorageAreaDeleteResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void deleteAll(String source, StorageArea.DeleteAllResponse callback) {
            StorageAreaDeleteAllParams _message = new StorageAreaDeleteAllParams();
            _message.source = source;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new StorageAreaDeleteAllResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void get(byte[] key, StorageArea.GetResponse callback) {
            StorageAreaGetParams _message = new StorageAreaGetParams();
            _message.key = key;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4, 1, 0L)), new StorageAreaGetResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.StorageArea
        public void getAll(AssociatedInterfaceNotSupported completeCallback, StorageArea.GetAllResponse callback) {
            StorageAreaGetAllParams _message = new StorageAreaGetAllParams();
            _message.completeCallback = completeCallback;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5, 1, 0L)), new StorageAreaGetAllResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<StorageArea> {
        Stub(Core core, StorageArea impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(StorageArea_Internal.MANAGER, messageWithHeader);
                    case 0:
                        StorageAreaAddObserverParams data = StorageAreaAddObserverParams.deserialize(messageWithHeader.getPayload());
                        getImpl().addObserver(data.observer);
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), StorageArea_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                    default:
                        return false;
                    case 1:
                        StorageAreaPutParams data = StorageAreaPutParams.deserialize(messageWithHeader.getPayload());
                        getImpl().put(data.key, data.value, data.clientOldValue, data.source, new StorageAreaPutResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        StorageAreaDeleteParams data2 = StorageAreaDeleteParams.deserialize(messageWithHeader.getPayload());
                        getImpl().delete(data2.key, data2.clientOldValue, data2.source, new StorageAreaDeleteResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 3:
                        StorageAreaDeleteAllParams data3 = StorageAreaDeleteAllParams.deserialize(messageWithHeader.getPayload());
                        getImpl().deleteAll(data3.source, new StorageAreaDeleteAllResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 4:
                        StorageAreaGetParams data4 = StorageAreaGetParams.deserialize(messageWithHeader.getPayload());
                        getImpl().get(data4.key, new StorageAreaGetResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 5:
                        StorageAreaGetAllParams data5 = StorageAreaGetAllParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getAll(data5.completeCallback, new StorageAreaGetAllResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaAddObserverParams.class */
    static final class StorageAreaAddObserverParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public AssociatedInterfaceNotSupported observer;

        private StorageAreaAddObserverParams(int version) {
            super(16, version);
        }

        public StorageAreaAddObserverParams() {
            this(0);
        }

        public static StorageAreaAddObserverParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaAddObserverParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaAddObserverParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaAddObserverParams result = new StorageAreaAddObserverParams(elementsOrVersion);
                result.observer = decoder0.readAssociatedServiceInterfaceNotSupported(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.observer, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaPutParams.class */
    static final class StorageAreaPutParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public byte[] key;
        public byte[] value;
        public byte[] clientOldValue;
        public String source;

        private StorageAreaPutParams(int version) {
            super(40, version);
        }

        public StorageAreaPutParams() {
            this(0);
        }

        public static StorageAreaPutParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaPutParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaPutParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaPutParams result = new StorageAreaPutParams(elementsOrVersion);
                result.key = decoder0.readBytes(8, 0, -1);
                result.value = decoder0.readBytes(16, 0, -1);
                result.clientOldValue = decoder0.readBytes(24, 1, -1);
                result.source = decoder0.readString(32, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.key, 8, 0, -1);
            encoder0.encode(this.value, 16, 0, -1);
            encoder0.encode(this.clientOldValue, 24, 1, -1);
            encoder0.encode(this.source, 32, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaPutResponseParams.class */
    public static final class StorageAreaPutResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;

        private StorageAreaPutResponseParams(int version) {
            super(16, version);
        }

        public StorageAreaPutResponseParams() {
            this(0);
        }

        public static StorageAreaPutResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaPutResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaPutResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaPutResponseParams result = new StorageAreaPutResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaPutResponseParamsForwardToCallback.class */
    static class StorageAreaPutResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final StorageArea.PutResponse mCallback;

        StorageAreaPutResponseParamsForwardToCallback(StorageArea.PutResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                StorageAreaPutResponseParams response = StorageAreaPutResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaPutResponseParamsProxyToResponder.class */
    static class StorageAreaPutResponseParamsProxyToResponder implements StorageArea.PutResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        StorageAreaPutResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean success) {
            StorageAreaPutResponseParams _response = new StorageAreaPutResponseParams();
            _response.success = success.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteParams.class */
    static final class StorageAreaDeleteParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public byte[] key;
        public byte[] clientOldValue;
        public String source;

        private StorageAreaDeleteParams(int version) {
            super(32, version);
        }

        public StorageAreaDeleteParams() {
            this(0);
        }

        public static StorageAreaDeleteParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaDeleteParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaDeleteParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaDeleteParams result = new StorageAreaDeleteParams(elementsOrVersion);
                result.key = decoder0.readBytes(8, 0, -1);
                result.clientOldValue = decoder0.readBytes(16, 1, -1);
                result.source = decoder0.readString(24, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.key, 8, 0, -1);
            encoder0.encode(this.clientOldValue, 16, 1, -1);
            encoder0.encode(this.source, 24, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteResponseParams.class */
    public static final class StorageAreaDeleteResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;

        private StorageAreaDeleteResponseParams(int version) {
            super(16, version);
        }

        public StorageAreaDeleteResponseParams() {
            this(0);
        }

        public static StorageAreaDeleteResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaDeleteResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaDeleteResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaDeleteResponseParams result = new StorageAreaDeleteResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteResponseParamsForwardToCallback.class */
    static class StorageAreaDeleteResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final StorageArea.DeleteResponse mCallback;

        StorageAreaDeleteResponseParamsForwardToCallback(StorageArea.DeleteResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                StorageAreaDeleteResponseParams response = StorageAreaDeleteResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteResponseParamsProxyToResponder.class */
    static class StorageAreaDeleteResponseParamsProxyToResponder implements StorageArea.DeleteResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        StorageAreaDeleteResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean success) {
            StorageAreaDeleteResponseParams _response = new StorageAreaDeleteResponseParams();
            _response.success = success.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteAllParams.class */
    static final class StorageAreaDeleteAllParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String source;

        private StorageAreaDeleteAllParams(int version) {
            super(16, version);
        }

        public StorageAreaDeleteAllParams() {
            this(0);
        }

        public static StorageAreaDeleteAllParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaDeleteAllParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaDeleteAllParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaDeleteAllParams result = new StorageAreaDeleteAllParams(elementsOrVersion);
                result.source = decoder0.readString(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.source, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteAllResponseParams.class */
    public static final class StorageAreaDeleteAllResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;

        private StorageAreaDeleteAllResponseParams(int version) {
            super(16, version);
        }

        public StorageAreaDeleteAllResponseParams() {
            this(0);
        }

        public static StorageAreaDeleteAllResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaDeleteAllResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaDeleteAllResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaDeleteAllResponseParams result = new StorageAreaDeleteAllResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteAllResponseParamsForwardToCallback.class */
    static class StorageAreaDeleteAllResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final StorageArea.DeleteAllResponse mCallback;

        StorageAreaDeleteAllResponseParamsForwardToCallback(StorageArea.DeleteAllResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                StorageAreaDeleteAllResponseParams response = StorageAreaDeleteAllResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaDeleteAllResponseParamsProxyToResponder.class */
    static class StorageAreaDeleteAllResponseParamsProxyToResponder implements StorageArea.DeleteAllResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        StorageAreaDeleteAllResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean success) {
            StorageAreaDeleteAllResponseParams _response = new StorageAreaDeleteAllResponseParams();
            _response.success = success.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetParams.class */
    static final class StorageAreaGetParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public byte[] key;

        private StorageAreaGetParams(int version) {
            super(16, version);
        }

        public StorageAreaGetParams() {
            this(0);
        }

        public static StorageAreaGetParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaGetParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaGetParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaGetParams result = new StorageAreaGetParams(elementsOrVersion);
                result.key = decoder0.readBytes(8, 0, -1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.key, 8, 0, -1);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetResponseParams.class */
    public static final class StorageAreaGetResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;
        public byte[] value;

        private StorageAreaGetResponseParams(int version) {
            super(24, version);
        }

        public StorageAreaGetResponseParams() {
            this(0);
        }

        public static StorageAreaGetResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaGetResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaGetResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaGetResponseParams result = new StorageAreaGetResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                result.value = decoder0.readBytes(16, 0, -1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
            encoder0.encode(this.value, 16, 0, -1);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetResponseParamsForwardToCallback.class */
    static class StorageAreaGetResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final StorageArea.GetResponse mCallback;

        StorageAreaGetResponseParamsForwardToCallback(StorageArea.GetResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(4, 2)) {
                    return false;
                }
                StorageAreaGetResponseParams response = StorageAreaGetResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success), response.value);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetResponseParamsProxyToResponder.class */
    static class StorageAreaGetResponseParamsProxyToResponder implements StorageArea.GetResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        StorageAreaGetResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(Boolean success, byte[] value) {
            StorageAreaGetResponseParams _response = new StorageAreaGetResponseParams();
            _response.success = success.booleanValue();
            _response.value = value;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(4, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetAllParams.class */
    static final class StorageAreaGetAllParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public AssociatedInterfaceNotSupported completeCallback;

        private StorageAreaGetAllParams(int version) {
            super(16, version);
        }

        public StorageAreaGetAllParams() {
            this(0);
        }

        public static StorageAreaGetAllParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaGetAllParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaGetAllParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaGetAllParams result = new StorageAreaGetAllParams(elementsOrVersion);
                result.completeCallback = decoder0.readAssociatedServiceInterfaceNotSupported(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.completeCallback, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetAllResponseParams.class */
    public static final class StorageAreaGetAllResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;
        public KeyValue[] data;

        private StorageAreaGetAllResponseParams(int version) {
            super(24, version);
        }

        public StorageAreaGetAllResponseParams() {
            this(0);
        }

        public static StorageAreaGetAllResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static StorageAreaGetAllResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static StorageAreaGetAllResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                StorageAreaGetAllResponseParams result = new StorageAreaGetAllResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                Decoder decoder1 = decoder0.readPointer(16, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.data = new KeyValue[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.data[i1] = KeyValue.decode(decoder2);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
            if (this.data == null) {
                encoder0.encodeNullPointer(16, false);
                return;
            }
            Encoder encoder1 = encoder0.encodePointerArray(this.data.length, 16, -1);
            for (int i0 = 0; i0 < this.data.length; i0++) {
                encoder1.encode((Struct) this.data[i0], 8 + (8 * i0), false);
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetAllResponseParamsForwardToCallback.class */
    static class StorageAreaGetAllResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final StorageArea.GetAllResponse mCallback;

        StorageAreaGetAllResponseParamsForwardToCallback(StorageArea.GetAllResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(5, 2)) {
                    return false;
                }
                StorageAreaGetAllResponseParams response = StorageAreaGetAllResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success), response.data);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/StorageArea_Internal$StorageAreaGetAllResponseParamsProxyToResponder.class */
    static class StorageAreaGetAllResponseParamsProxyToResponder implements StorageArea.GetAllResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        StorageAreaGetAllResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(Boolean success, KeyValue[] data) {
            StorageAreaGetAllResponseParams _response = new StorageAreaGetAllResponseParams();
            _response.success = success.booleanValue();
            _response.data = data;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(5, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
