package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerRegistrationConstants.class */
public final class ServiceWorkerRegistrationConstants {
    public static final long INVALID_SERVICE_WORKER_REGISTRATION_ID = -1;

    private ServiceWorkerRegistrationConstants() {
    }
}
