package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.InternalAuthenticator;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal.class */
class InternalAuthenticator_Internal {
    public static final Interface.Manager<InternalAuthenticator, InternalAuthenticator.Proxy> MANAGER = new Interface.Manager<InternalAuthenticator, InternalAuthenticator.Proxy>() { // from class: org.chromium.blink.mojom.InternalAuthenticator_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.InternalAuthenticator";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public InternalAuthenticator.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, InternalAuthenticator impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public InternalAuthenticator[] buildArray(int size) {
            return new InternalAuthenticator[size];
        }
    };
    private static final int MAKE_CREDENTIAL_ORDINAL = 0;
    private static final int GET_ASSERTION_ORDINAL = 1;
    private static final int IS_USER_VERIFYING_PLATFORM_AUTHENTICATOR_AVAILABLE_ORDINAL = 2;

    InternalAuthenticator_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements InternalAuthenticator.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.InternalAuthenticator
        public void makeCredential(PublicKeyCredentialCreationOptions options, InternalAuthenticator.MakeCredentialResponse callback) {
            InternalAuthenticatorMakeCredentialParams _message = new InternalAuthenticatorMakeCredentialParams();
            _message.options = options;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new InternalAuthenticatorMakeCredentialResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.InternalAuthenticator
        public void getAssertion(PublicKeyCredentialRequestOptions options, InternalAuthenticator.GetAssertionResponse callback) {
            InternalAuthenticatorGetAssertionParams _message = new InternalAuthenticatorGetAssertionParams();
            _message.options = options;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new InternalAuthenticatorGetAssertionResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.InternalAuthenticator
        public void isUserVerifyingPlatformAuthenticatorAvailable(InternalAuthenticator.IsUserVerifyingPlatformAuthenticatorAvailableResponse callback) {
            InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams _message = new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<InternalAuthenticator> {
        Stub(Core core, InternalAuthenticator impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(InternalAuthenticator_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), InternalAuthenticator_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        InternalAuthenticatorMakeCredentialParams data = InternalAuthenticatorMakeCredentialParams.deserialize(messageWithHeader.getPayload());
                        getImpl().makeCredential(data.options, new InternalAuthenticatorMakeCredentialResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        InternalAuthenticatorGetAssertionParams data2 = InternalAuthenticatorGetAssertionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getAssertion(data2.options, new InternalAuthenticatorGetAssertionResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams.deserialize(messageWithHeader.getPayload());
                        getImpl().isUserVerifyingPlatformAuthenticatorAvailable(new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorMakeCredentialParams.class */
    static final class InternalAuthenticatorMakeCredentialParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public PublicKeyCredentialCreationOptions options;

        private InternalAuthenticatorMakeCredentialParams(int version) {
            super(16, version);
        }

        public InternalAuthenticatorMakeCredentialParams() {
            this(0);
        }

        public static InternalAuthenticatorMakeCredentialParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorMakeCredentialParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorMakeCredentialParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorMakeCredentialParams result = new InternalAuthenticatorMakeCredentialParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.options = PublicKeyCredentialCreationOptions.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.options, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorMakeCredentialResponseParams.class */
    public static final class InternalAuthenticatorMakeCredentialResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;
        public MakeCredentialAuthenticatorResponse credential;

        private InternalAuthenticatorMakeCredentialResponseParams(int version) {
            super(24, version);
        }

        public InternalAuthenticatorMakeCredentialResponseParams() {
            this(0);
        }

        public static InternalAuthenticatorMakeCredentialResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorMakeCredentialResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorMakeCredentialResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorMakeCredentialResponseParams result = new InternalAuthenticatorMakeCredentialResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                AuthenticatorStatus.validate(result.status);
                Decoder decoder1 = decoder0.readPointer(16, true);
                result.credential = MakeCredentialAuthenticatorResponse.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
            encoder0.encode((Struct) this.credential, 16, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorMakeCredentialResponseParamsForwardToCallback.class */
    static class InternalAuthenticatorMakeCredentialResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final InternalAuthenticator.MakeCredentialResponse mCallback;

        InternalAuthenticatorMakeCredentialResponseParamsForwardToCallback(InternalAuthenticator.MakeCredentialResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                InternalAuthenticatorMakeCredentialResponseParams response = InternalAuthenticatorMakeCredentialResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status), response.credential);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorMakeCredentialResponseParamsProxyToResponder.class */
    static class InternalAuthenticatorMakeCredentialResponseParamsProxyToResponder implements InternalAuthenticator.MakeCredentialResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        InternalAuthenticatorMakeCredentialResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(Integer status, MakeCredentialAuthenticatorResponse credential) {
            InternalAuthenticatorMakeCredentialResponseParams _response = new InternalAuthenticatorMakeCredentialResponseParams();
            _response.status = status.intValue();
            _response.credential = credential;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorGetAssertionParams.class */
    static final class InternalAuthenticatorGetAssertionParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public PublicKeyCredentialRequestOptions options;

        private InternalAuthenticatorGetAssertionParams(int version) {
            super(16, version);
        }

        public InternalAuthenticatorGetAssertionParams() {
            this(0);
        }

        public static InternalAuthenticatorGetAssertionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorGetAssertionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorGetAssertionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorGetAssertionParams result = new InternalAuthenticatorGetAssertionParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.options = PublicKeyCredentialRequestOptions.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.options, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorGetAssertionResponseParams.class */
    public static final class InternalAuthenticatorGetAssertionResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;
        public GetAssertionAuthenticatorResponse credential;

        private InternalAuthenticatorGetAssertionResponseParams(int version) {
            super(24, version);
        }

        public InternalAuthenticatorGetAssertionResponseParams() {
            this(0);
        }

        public static InternalAuthenticatorGetAssertionResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorGetAssertionResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorGetAssertionResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorGetAssertionResponseParams result = new InternalAuthenticatorGetAssertionResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                AuthenticatorStatus.validate(result.status);
                Decoder decoder1 = decoder0.readPointer(16, true);
                result.credential = GetAssertionAuthenticatorResponse.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
            encoder0.encode((Struct) this.credential, 16, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorGetAssertionResponseParamsForwardToCallback.class */
    static class InternalAuthenticatorGetAssertionResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final InternalAuthenticator.GetAssertionResponse mCallback;

        InternalAuthenticatorGetAssertionResponseParamsForwardToCallback(InternalAuthenticator.GetAssertionResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                InternalAuthenticatorGetAssertionResponseParams response = InternalAuthenticatorGetAssertionResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status), response.credential);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorGetAssertionResponseParamsProxyToResponder.class */
    static class InternalAuthenticatorGetAssertionResponseParamsProxyToResponder implements InternalAuthenticator.GetAssertionResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        InternalAuthenticatorGetAssertionResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(Integer status, GetAssertionAuthenticatorResponse credential) {
            InternalAuthenticatorGetAssertionResponseParams _response = new InternalAuthenticatorGetAssertionResponseParams();
            _response.status = status.intValue();
            _response.credential = credential;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams.class */
    static final class InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams(int version) {
            super(8, version);
        }

        public InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams() {
            this(0);
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams result = new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams.class */
    public static final class InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean available;

        private InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams(int version) {
            super(16, version);
        }

        public InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams() {
            this(0);
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams result = new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams(elementsOrVersion);
                result.available = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.available, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsForwardToCallback.class */
    static class InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final InternalAuthenticator.IsUserVerifyingPlatformAuthenticatorAvailableResponse mCallback;

        InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsForwardToCallback(InternalAuthenticator.IsUserVerifyingPlatformAuthenticatorAvailableResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams response = InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.available));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/InternalAuthenticator_Internal$InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsProxyToResponder.class */
    static class InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsProxyToResponder implements InternalAuthenticator.IsUserVerifyingPlatformAuthenticatorAvailableResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean available) {
            InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams _response = new InternalAuthenticatorIsUserVerifyingPlatformAuthenticatorAvailableResponseParams();
            _response.available = available.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
