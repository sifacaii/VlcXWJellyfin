package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/ServiceWorkerConstants.class */
public final class ServiceWorkerConstants {
    public static final int PUSH_EVENT_TIMEOUT_SECONDS = 90;

    private ServiceWorkerConstants() {
    }
}
