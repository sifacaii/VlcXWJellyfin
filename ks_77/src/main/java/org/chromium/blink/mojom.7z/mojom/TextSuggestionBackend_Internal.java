package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.TextSuggestionBackend;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal.class */
class TextSuggestionBackend_Internal {
    public static final Interface.Manager<TextSuggestionBackend, TextSuggestionBackend.Proxy> MANAGER = new Interface.Manager<TextSuggestionBackend, TextSuggestionBackend.Proxy>() { // from class: org.chromium.blink.mojom.TextSuggestionBackend_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.TextSuggestionBackend";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public TextSuggestionBackend.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, TextSuggestionBackend impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public TextSuggestionBackend[] buildArray(int size) {
            return new TextSuggestionBackend[size];
        }
    };
    private static final int APPLY_SPELL_CHECK_SUGGESTION_ORDINAL = 0;
    private static final int APPLY_TEXT_SUGGESTION_ORDINAL = 1;
    private static final int DELETE_ACTIVE_SUGGESTION_RANGE_ORDINAL = 2;
    private static final int ON_NEW_WORD_ADDED_TO_DICTIONARY_ORDINAL = 3;
    private static final int ON_SUGGESTION_MENU_CLOSED_ORDINAL = 4;
    private static final int SUGGESTION_MENU_TIMEOUT_CALLBACK_ORDINAL = 5;

    TextSuggestionBackend_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements TextSuggestionBackend.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void applySpellCheckSuggestion(String suggestion) {
            TextSuggestionBackendApplySpellCheckSuggestionParams _message = new TextSuggestionBackendApplySpellCheckSuggestionParams();
            _message.suggestion = suggestion;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void applyTextSuggestion(int markerTag, int suggestionIndex) {
            TextSuggestionBackendApplyTextSuggestionParams _message = new TextSuggestionBackendApplyTextSuggestionParams();
            _message.markerTag = markerTag;
            _message.suggestionIndex = suggestionIndex;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void deleteActiveSuggestionRange() {
            TextSuggestionBackendDeleteActiveSuggestionRangeParams _message = new TextSuggestionBackendDeleteActiveSuggestionRangeParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void onNewWordAddedToDictionary(String suggestion) {
            TextSuggestionBackendOnNewWordAddedToDictionaryParams _message = new TextSuggestionBackendOnNewWordAddedToDictionaryParams();
            _message.suggestion = suggestion;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3)));
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void onSuggestionMenuClosed() {
            TextSuggestionBackendOnSuggestionMenuClosedParams _message = new TextSuggestionBackendOnSuggestionMenuClosedParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4)));
        }

        @Override // org.chromium.blink.mojom.TextSuggestionBackend
        public void suggestionMenuTimeoutCallback(int maxNumberOfSuggestions) {
            TextSuggestionBackendSuggestionMenuTimeoutCallbackParams _message = new TextSuggestionBackendSuggestionMenuTimeoutCallbackParams();
            _message.maxNumberOfSuggestions = maxNumberOfSuggestions;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<TextSuggestionBackend> {
        Stub(Core core, TextSuggestionBackend impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(TextSuggestionBackend_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        TextSuggestionBackendApplySpellCheckSuggestionParams data = TextSuggestionBackendApplySpellCheckSuggestionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().applySpellCheckSuggestion(data.suggestion);
                        return true;
                    case 1:
                        TextSuggestionBackendApplyTextSuggestionParams data2 = TextSuggestionBackendApplyTextSuggestionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().applyTextSuggestion(data2.markerTag, data2.suggestionIndex);
                        return true;
                    case 2:
                        TextSuggestionBackendDeleteActiveSuggestionRangeParams.deserialize(messageWithHeader.getPayload());
                        getImpl().deleteActiveSuggestionRange();
                        return true;
                    case 3:
                        TextSuggestionBackendOnNewWordAddedToDictionaryParams data3 = TextSuggestionBackendOnNewWordAddedToDictionaryParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onNewWordAddedToDictionary(data3.suggestion);
                        return true;
                    case 4:
                        TextSuggestionBackendOnSuggestionMenuClosedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().onSuggestionMenuClosed();
                        return true;
                    case 5:
                        TextSuggestionBackendSuggestionMenuTimeoutCallbackParams data4 = TextSuggestionBackendSuggestionMenuTimeoutCallbackParams.deserialize(messageWithHeader.getPayload());
                        getImpl().suggestionMenuTimeoutCallback(data4.maxNumberOfSuggestions);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), TextSuggestionBackend_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendApplySpellCheckSuggestionParams.class */
    static final class TextSuggestionBackendApplySpellCheckSuggestionParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String suggestion;

        private TextSuggestionBackendApplySpellCheckSuggestionParams(int version) {
            super(16, version);
        }

        public TextSuggestionBackendApplySpellCheckSuggestionParams() {
            this(0);
        }

        public static TextSuggestionBackendApplySpellCheckSuggestionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendApplySpellCheckSuggestionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendApplySpellCheckSuggestionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendApplySpellCheckSuggestionParams result = new TextSuggestionBackendApplySpellCheckSuggestionParams(elementsOrVersion);
                result.suggestion = decoder0.readString(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.suggestion, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendApplyTextSuggestionParams.class */
    static final class TextSuggestionBackendApplyTextSuggestionParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int markerTag;
        public int suggestionIndex;

        private TextSuggestionBackendApplyTextSuggestionParams(int version) {
            super(16, version);
        }

        public TextSuggestionBackendApplyTextSuggestionParams() {
            this(0);
        }

        public static TextSuggestionBackendApplyTextSuggestionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendApplyTextSuggestionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendApplyTextSuggestionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendApplyTextSuggestionParams result = new TextSuggestionBackendApplyTextSuggestionParams(elementsOrVersion);
                result.markerTag = decoder0.readInt(8);
                result.suggestionIndex = decoder0.readInt(12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.markerTag, 8);
            encoder0.encode(this.suggestionIndex, 12);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendDeleteActiveSuggestionRangeParams.class */
    static final class TextSuggestionBackendDeleteActiveSuggestionRangeParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private TextSuggestionBackendDeleteActiveSuggestionRangeParams(int version) {
            super(8, version);
        }

        public TextSuggestionBackendDeleteActiveSuggestionRangeParams() {
            this(0);
        }

        public static TextSuggestionBackendDeleteActiveSuggestionRangeParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendDeleteActiveSuggestionRangeParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendDeleteActiveSuggestionRangeParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendDeleteActiveSuggestionRangeParams result = new TextSuggestionBackendDeleteActiveSuggestionRangeParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendOnNewWordAddedToDictionaryParams.class */
    static final class TextSuggestionBackendOnNewWordAddedToDictionaryParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String suggestion;

        private TextSuggestionBackendOnNewWordAddedToDictionaryParams(int version) {
            super(16, version);
        }

        public TextSuggestionBackendOnNewWordAddedToDictionaryParams() {
            this(0);
        }

        public static TextSuggestionBackendOnNewWordAddedToDictionaryParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendOnNewWordAddedToDictionaryParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendOnNewWordAddedToDictionaryParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendOnNewWordAddedToDictionaryParams result = new TextSuggestionBackendOnNewWordAddedToDictionaryParams(elementsOrVersion);
                result.suggestion = decoder0.readString(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.suggestion, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendOnSuggestionMenuClosedParams.class */
    static final class TextSuggestionBackendOnSuggestionMenuClosedParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private TextSuggestionBackendOnSuggestionMenuClosedParams(int version) {
            super(8, version);
        }

        public TextSuggestionBackendOnSuggestionMenuClosedParams() {
            this(0);
        }

        public static TextSuggestionBackendOnSuggestionMenuClosedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendOnSuggestionMenuClosedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendOnSuggestionMenuClosedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendOnSuggestionMenuClosedParams result = new TextSuggestionBackendOnSuggestionMenuClosedParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/TextSuggestionBackend_Internal$TextSuggestionBackendSuggestionMenuTimeoutCallbackParams.class */
    static final class TextSuggestionBackendSuggestionMenuTimeoutCallbackParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int maxNumberOfSuggestions;

        private TextSuggestionBackendSuggestionMenuTimeoutCallbackParams(int version) {
            super(16, version);
        }

        public TextSuggestionBackendSuggestionMenuTimeoutCallbackParams() {
            this(0);
        }

        public static TextSuggestionBackendSuggestionMenuTimeoutCallbackParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static TextSuggestionBackendSuggestionMenuTimeoutCallbackParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static TextSuggestionBackendSuggestionMenuTimeoutCallbackParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                TextSuggestionBackendSuggestionMenuTimeoutCallbackParams result = new TextSuggestionBackendSuggestionMenuTimeoutCallbackParams(elementsOrVersion);
                result.maxNumberOfSuggestions = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.maxNumberOfSuggestions, 8);
        }
    }
}
