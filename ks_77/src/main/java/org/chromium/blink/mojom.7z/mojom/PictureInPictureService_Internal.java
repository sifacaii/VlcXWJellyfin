package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.PictureInPictureService;
import org.chromium.gfx.mojom.Size;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.viz.mojom.SurfaceId;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal.class */
class PictureInPictureService_Internal {
    public static final Interface.Manager<PictureInPictureService, PictureInPictureService.Proxy> MANAGER = new Interface.Manager<PictureInPictureService, PictureInPictureService.Proxy>() { // from class: org.chromium.blink.mojom.PictureInPictureService_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.PictureInPictureService";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public PictureInPictureService.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, PictureInPictureService impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public PictureInPictureService[] buildArray(int size) {
            return new PictureInPictureService[size];
        }
    };
    private static final int START_SESSION_ORDINAL = 0;

    PictureInPictureService_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements PictureInPictureService.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.PictureInPictureService
        public void startSession(int playerId, SurfaceId surfaceId, Size naturalSize, boolean showPlayPauseButton, boolean showMuteButton, PictureInPictureSessionObserver observer, PictureInPictureService.StartSessionResponse callback) {
            PictureInPictureServiceStartSessionParams _message = new PictureInPictureServiceStartSessionParams();
            _message.playerId = playerId;
            _message.surfaceId = surfaceId;
            _message.naturalSize = naturalSize;
            _message.showPlayPauseButton = showPlayPauseButton;
            _message.showMuteButton = showMuteButton;
            _message.observer = observer;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new PictureInPictureServiceStartSessionResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<PictureInPictureService> {
        Stub(Core core, PictureInPictureService impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(PictureInPictureService_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), PictureInPictureService_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        PictureInPictureServiceStartSessionParams data = PictureInPictureServiceStartSessionParams.deserialize(messageWithHeader.getPayload());
                        getImpl().startSession(data.playerId, data.surfaceId, data.naturalSize, data.showPlayPauseButton, data.showMuteButton, data.observer, new PictureInPictureServiceStartSessionResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$PictureInPictureServiceStartSessionParams.class */
    static final class PictureInPictureServiceStartSessionParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int playerId;
        public SurfaceId surfaceId;
        public Size naturalSize;
        public boolean showPlayPauseButton;
        public boolean showMuteButton;
        public PictureInPictureSessionObserver observer;

        private PictureInPictureServiceStartSessionParams(int version) {
            super(40, version);
        }

        public PictureInPictureServiceStartSessionParams() {
            this(0);
        }

        public static PictureInPictureServiceStartSessionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static PictureInPictureServiceStartSessionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static PictureInPictureServiceStartSessionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                PictureInPictureServiceStartSessionParams result = new PictureInPictureServiceStartSessionParams(elementsOrVersion);
                result.playerId = decoder0.readInt(8);
                result.showPlayPauseButton = decoder0.readBoolean(12, 0);
                result.showMuteButton = decoder0.readBoolean(12, 1);
                Decoder decoder1 = decoder0.readPointer(16, true);
                result.surfaceId = SurfaceId.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(24, false);
                result.naturalSize = Size.decode(decoder12);
                result.observer = (PictureInPictureSessionObserver) decoder0.readServiceInterface(32, false, PictureInPictureSessionObserver.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.playerId, 8);
            encoder0.encode(this.showPlayPauseButton, 12, 0);
            encoder0.encode(this.showMuteButton, 12, 1);
            encoder0.encode((Struct) this.surfaceId, 16, true);
            encoder0.encode((Struct) this.naturalSize, 24, false);
            encoder0.encode((Encoder) this.observer, 32, false, (Interface.Manager<Encoder, ?>) PictureInPictureSessionObserver.MANAGER);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$PictureInPictureServiceStartSessionResponseParams.class */
    public static final class PictureInPictureServiceStartSessionResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public PictureInPictureSession session;
        public Size size;

        private PictureInPictureServiceStartSessionResponseParams(int version) {
            super(24, version);
        }

        public PictureInPictureServiceStartSessionResponseParams() {
            this(0);
        }

        public static PictureInPictureServiceStartSessionResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static PictureInPictureServiceStartSessionResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static PictureInPictureServiceStartSessionResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                PictureInPictureServiceStartSessionResponseParams result = new PictureInPictureServiceStartSessionResponseParams(elementsOrVersion);
                result.session = (PictureInPictureSession) decoder0.readServiceInterface(8, true, PictureInPictureSession.MANAGER);
                Decoder decoder1 = decoder0.readPointer(16, false);
                result.size = Size.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Encoder) this.session, 8, true, (Interface.Manager<Encoder, ?>) PictureInPictureSession.MANAGER);
            encoder0.encode((Struct) this.size, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$PictureInPictureServiceStartSessionResponseParamsForwardToCallback.class */
    static class PictureInPictureServiceStartSessionResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final PictureInPictureService.StartSessionResponse mCallback;

        PictureInPictureServiceStartSessionResponseParamsForwardToCallback(PictureInPictureService.StartSessionResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                PictureInPictureServiceStartSessionResponseParams response = PictureInPictureServiceStartSessionResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.session, response.size);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/PictureInPictureService_Internal$PictureInPictureServiceStartSessionResponseParamsProxyToResponder.class */
    static class PictureInPictureServiceStartSessionResponseParamsProxyToResponder implements PictureInPictureService.StartSessionResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        PictureInPictureServiceStartSessionResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(PictureInPictureSession session, Size size) {
            PictureInPictureServiceStartSessionResponseParams _response = new PictureInPictureServiceStartSessionResponseParams();
            _response.session = session;
            _response.size = size;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
