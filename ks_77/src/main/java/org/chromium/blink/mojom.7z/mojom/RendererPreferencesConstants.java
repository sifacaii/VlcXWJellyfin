package org.chromium.blink.mojom;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RendererPreferencesConstants.class */
public final class RendererPreferencesConstants {
    public static final long DEFAULT_CARET_BLINK_INTERVAL_IN_MILLISECONDS = 500;

    private RendererPreferencesConstants() {
    }
}
