package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.WebDatabaseHost;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.mojo_base.mojom.File;
import org.chromium.mojo_base.mojom.String16;
import org.chromium.url.mojom.Origin;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal.class */
class WebDatabaseHost_Internal {
    public static final Interface.Manager<WebDatabaseHost, WebDatabaseHost.Proxy> MANAGER = new Interface.Manager<WebDatabaseHost, WebDatabaseHost.Proxy>() { // from class: org.chromium.blink.mojom.WebDatabaseHost_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.WebDatabaseHost";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public WebDatabaseHost.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, WebDatabaseHost impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public WebDatabaseHost[] buildArray(int size) {
            return new WebDatabaseHost[size];
        }
    };
    private static final int OPEN_FILE_ORDINAL = 0;
    private static final int DELETE_FILE_ORDINAL = 1;
    private static final int GET_FILE_ATTRIBUTES_ORDINAL = 2;
    private static final int GET_FILE_SIZE_ORDINAL = 3;
    private static final int SET_FILE_SIZE_ORDINAL = 4;
    private static final int GET_SPACE_AVAILABLE_ORDINAL = 5;
    private static final int OPENED_ORDINAL = 6;
    private static final int MODIFIED_ORDINAL = 7;
    private static final int CLOSED_ORDINAL = 8;
    private static final int HANDLE_SQLITE_ERROR_ORDINAL = 9;

    WebDatabaseHost_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements WebDatabaseHost.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void openFile(String16 vfsFileName, int desiredFlags, WebDatabaseHost.OpenFileResponse callback) {
            WebDatabaseHostOpenFileParams _message = new WebDatabaseHostOpenFileParams();
            _message.vfsFileName = vfsFileName;
            _message.desiredFlags = desiredFlags;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new WebDatabaseHostOpenFileResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void deleteFile(String16 vfsFileName, boolean syncDir, WebDatabaseHost.DeleteFileResponse callback) {
            WebDatabaseHostDeleteFileParams _message = new WebDatabaseHostDeleteFileParams();
            _message.vfsFileName = vfsFileName;
            _message.syncDir = syncDir;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new WebDatabaseHostDeleteFileResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void getFileAttributes(String16 vfsFileName, WebDatabaseHost.GetFileAttributesResponse callback) {
            WebDatabaseHostGetFileAttributesParams _message = new WebDatabaseHostGetFileAttributesParams();
            _message.vfsFileName = vfsFileName;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new WebDatabaseHostGetFileAttributesResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void getFileSize(String16 vfsFileName, WebDatabaseHost.GetFileSizeResponse callback) {
            WebDatabaseHostGetFileSizeParams _message = new WebDatabaseHostGetFileSizeParams();
            _message.vfsFileName = vfsFileName;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new WebDatabaseHostGetFileSizeResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void setFileSize(String16 vfsFileName, long expectedSize, WebDatabaseHost.SetFileSizeResponse callback) {
            WebDatabaseHostSetFileSizeParams _message = new WebDatabaseHostSetFileSizeParams();
            _message.vfsFileName = vfsFileName;
            _message.expectedSize = expectedSize;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4, 1, 0L)), new WebDatabaseHostSetFileSizeResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void getSpaceAvailable(Origin origin, WebDatabaseHost.GetSpaceAvailableResponse callback) {
            WebDatabaseHostGetSpaceAvailableParams _message = new WebDatabaseHostGetSpaceAvailableParams();
            _message.origin = origin;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5, 1, 0L)), new WebDatabaseHostGetSpaceAvailableResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void opened(Origin origin, String16 databaseName, String16 databaseDescription, long estimatedSize) {
            WebDatabaseHostOpenedParams _message = new WebDatabaseHostOpenedParams();
            _message.origin = origin;
            _message.databaseName = databaseName;
            _message.databaseDescription = databaseDescription;
            _message.estimatedSize = estimatedSize;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(6)));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void modified(Origin origin, String16 databaseName) {
            WebDatabaseHostModifiedParams _message = new WebDatabaseHostModifiedParams();
            _message.origin = origin;
            _message.databaseName = databaseName;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(7)));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void closed(Origin origin, String16 databaseName) {
            WebDatabaseHostClosedParams _message = new WebDatabaseHostClosedParams();
            _message.origin = origin;
            _message.databaseName = databaseName;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(8)));
        }

        @Override // org.chromium.blink.mojom.WebDatabaseHost
        public void handleSqliteError(Origin origin, String16 databaseName, int error) {
            WebDatabaseHostHandleSqliteErrorParams _message = new WebDatabaseHostHandleSqliteErrorParams();
            _message.origin = origin;
            _message.databaseName = databaseName;
            _message.error = error;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(9)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<WebDatabaseHost> {
        Stub(Core core, WebDatabaseHost impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(WebDatabaseHost_Internal.MANAGER, messageWithHeader);
                    case -1:
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    default:
                        return false;
                    case 6:
                        WebDatabaseHostOpenedParams data = WebDatabaseHostOpenedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().opened(data.origin, data.databaseName, data.databaseDescription, data.estimatedSize);
                        return true;
                    case 7:
                        WebDatabaseHostModifiedParams data2 = WebDatabaseHostModifiedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().modified(data2.origin, data2.databaseName);
                        return true;
                    case 8:
                        WebDatabaseHostClosedParams data3 = WebDatabaseHostClosedParams.deserialize(messageWithHeader.getPayload());
                        getImpl().closed(data3.origin, data3.databaseName);
                        return true;
                    case 9:
                        WebDatabaseHostHandleSqliteErrorParams data4 = WebDatabaseHostHandleSqliteErrorParams.deserialize(messageWithHeader.getPayload());
                        getImpl().handleSqliteError(data4.origin, data4.databaseName, data4.error);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), WebDatabaseHost_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        WebDatabaseHostOpenFileParams data = WebDatabaseHostOpenFileParams.deserialize(messageWithHeader.getPayload());
                        getImpl().openFile(data.vfsFileName, data.desiredFlags, new WebDatabaseHostOpenFileResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        WebDatabaseHostDeleteFileParams data2 = WebDatabaseHostDeleteFileParams.deserialize(messageWithHeader.getPayload());
                        getImpl().deleteFile(data2.vfsFileName, data2.syncDir, new WebDatabaseHostDeleteFileResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        WebDatabaseHostGetFileAttributesParams data3 = WebDatabaseHostGetFileAttributesParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getFileAttributes(data3.vfsFileName, new WebDatabaseHostGetFileAttributesResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 3:
                        WebDatabaseHostGetFileSizeParams data4 = WebDatabaseHostGetFileSizeParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getFileSize(data4.vfsFileName, new WebDatabaseHostGetFileSizeResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 4:
                        WebDatabaseHostSetFileSizeParams data5 = WebDatabaseHostSetFileSizeParams.deserialize(messageWithHeader.getPayload());
                        getImpl().setFileSize(data5.vfsFileName, data5.expectedSize, new WebDatabaseHostSetFileSizeResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 5:
                        getImpl().getSpaceAvailable(WebDatabaseHostGetSpaceAvailableParams.deserialize(messageWithHeader.getPayload()).origin, new WebDatabaseHostGetSpaceAvailableResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostOpenFileParams.class */
    static final class WebDatabaseHostOpenFileParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 vfsFileName;
        public int desiredFlags;

        private WebDatabaseHostOpenFileParams(int version) {
            super(24, version);
        }

        public WebDatabaseHostOpenFileParams() {
            this(0);
        }

        public static WebDatabaseHostOpenFileParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostOpenFileParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostOpenFileParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostOpenFileParams result = new WebDatabaseHostOpenFileParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.vfsFileName = String16.decode(decoder1);
                result.desiredFlags = decoder0.readInt(16);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.vfsFileName, 8, false);
            encoder0.encode(this.desiredFlags, 16);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostOpenFileResponseParams.class */
    public static final class WebDatabaseHostOpenFileResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public File file;

        private WebDatabaseHostOpenFileResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostOpenFileResponseParams() {
            this(0);
        }

        public static WebDatabaseHostOpenFileResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostOpenFileResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostOpenFileResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostOpenFileResponseParams result = new WebDatabaseHostOpenFileResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, true);
                result.file = File.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.file, 8, true);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostOpenFileResponseParamsForwardToCallback.class */
    static class WebDatabaseHostOpenFileResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.OpenFileResponse mCallback;

        WebDatabaseHostOpenFileResponseParamsForwardToCallback(WebDatabaseHost.OpenFileResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                WebDatabaseHostOpenFileResponseParams response = WebDatabaseHostOpenFileResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.file);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostOpenFileResponseParamsProxyToResponder.class */
    static class WebDatabaseHostOpenFileResponseParamsProxyToResponder implements WebDatabaseHost.OpenFileResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostOpenFileResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(File file) {
            WebDatabaseHostOpenFileResponseParams _response = new WebDatabaseHostOpenFileResponseParams();
            _response.file = file;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostDeleteFileParams.class */
    static final class WebDatabaseHostDeleteFileParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 vfsFileName;
        public boolean syncDir;

        private WebDatabaseHostDeleteFileParams(int version) {
            super(24, version);
        }

        public WebDatabaseHostDeleteFileParams() {
            this(0);
        }

        public static WebDatabaseHostDeleteFileParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostDeleteFileParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostDeleteFileParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostDeleteFileParams result = new WebDatabaseHostDeleteFileParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.vfsFileName = String16.decode(decoder1);
                result.syncDir = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.vfsFileName, 8, false);
            encoder0.encode(this.syncDir, 16, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostDeleteFileResponseParams.class */
    public static final class WebDatabaseHostDeleteFileResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int sqliteErrorCode;

        private WebDatabaseHostDeleteFileResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostDeleteFileResponseParams() {
            this(0);
        }

        public static WebDatabaseHostDeleteFileResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostDeleteFileResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostDeleteFileResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostDeleteFileResponseParams result = new WebDatabaseHostDeleteFileResponseParams(elementsOrVersion);
                result.sqliteErrorCode = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.sqliteErrorCode, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostDeleteFileResponseParamsForwardToCallback.class */
    static class WebDatabaseHostDeleteFileResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.DeleteFileResponse mCallback;

        WebDatabaseHostDeleteFileResponseParamsForwardToCallback(WebDatabaseHost.DeleteFileResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                WebDatabaseHostDeleteFileResponseParams response = WebDatabaseHostDeleteFileResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.sqliteErrorCode));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostDeleteFileResponseParamsProxyToResponder.class */
    static class WebDatabaseHostDeleteFileResponseParamsProxyToResponder implements WebDatabaseHost.DeleteFileResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostDeleteFileResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer sqliteErrorCode) {
            WebDatabaseHostDeleteFileResponseParams _response = new WebDatabaseHostDeleteFileResponseParams();
            _response.sqliteErrorCode = sqliteErrorCode.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileAttributesParams.class */
    static final class WebDatabaseHostGetFileAttributesParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 vfsFileName;

        private WebDatabaseHostGetFileAttributesParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetFileAttributesParams() {
            this(0);
        }

        public static WebDatabaseHostGetFileAttributesParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetFileAttributesParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetFileAttributesParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetFileAttributesParams result = new WebDatabaseHostGetFileAttributesParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.vfsFileName = String16.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.vfsFileName, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileAttributesResponseParams.class */
    public static final class WebDatabaseHostGetFileAttributesResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int attributes;

        private WebDatabaseHostGetFileAttributesResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetFileAttributesResponseParams() {
            this(0);
        }

        public static WebDatabaseHostGetFileAttributesResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetFileAttributesResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetFileAttributesResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetFileAttributesResponseParams result = new WebDatabaseHostGetFileAttributesResponseParams(elementsOrVersion);
                result.attributes = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.attributes, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileAttributesResponseParamsForwardToCallback.class */
    static class WebDatabaseHostGetFileAttributesResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.GetFileAttributesResponse mCallback;

        WebDatabaseHostGetFileAttributesResponseParamsForwardToCallback(WebDatabaseHost.GetFileAttributesResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                WebDatabaseHostGetFileAttributesResponseParams response = WebDatabaseHostGetFileAttributesResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.attributes));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileAttributesResponseParamsProxyToResponder.class */
    static class WebDatabaseHostGetFileAttributesResponseParamsProxyToResponder implements WebDatabaseHost.GetFileAttributesResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostGetFileAttributesResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer attributes) {
            WebDatabaseHostGetFileAttributesResponseParams _response = new WebDatabaseHostGetFileAttributesResponseParams();
            _response.attributes = attributes.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileSizeParams.class */
    static final class WebDatabaseHostGetFileSizeParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 vfsFileName;

        private WebDatabaseHostGetFileSizeParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetFileSizeParams() {
            this(0);
        }

        public static WebDatabaseHostGetFileSizeParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetFileSizeParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetFileSizeParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetFileSizeParams result = new WebDatabaseHostGetFileSizeParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.vfsFileName = String16.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.vfsFileName, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileSizeResponseParams.class */
    public static final class WebDatabaseHostGetFileSizeResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public long size;

        private WebDatabaseHostGetFileSizeResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetFileSizeResponseParams() {
            this(0);
        }

        public static WebDatabaseHostGetFileSizeResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetFileSizeResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetFileSizeResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetFileSizeResponseParams result = new WebDatabaseHostGetFileSizeResponseParams(elementsOrVersion);
                result.size = decoder0.readLong(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.size, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileSizeResponseParamsForwardToCallback.class */
    static class WebDatabaseHostGetFileSizeResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.GetFileSizeResponse mCallback;

        WebDatabaseHostGetFileSizeResponseParamsForwardToCallback(WebDatabaseHost.GetFileSizeResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                WebDatabaseHostGetFileSizeResponseParams response = WebDatabaseHostGetFileSizeResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Long.valueOf(response.size));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetFileSizeResponseParamsProxyToResponder.class */
    static class WebDatabaseHostGetFileSizeResponseParamsProxyToResponder implements WebDatabaseHost.GetFileSizeResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostGetFileSizeResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Long size) {
            WebDatabaseHostGetFileSizeResponseParams _response = new WebDatabaseHostGetFileSizeResponseParams();
            _response.size = size.longValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostSetFileSizeParams.class */
    static final class WebDatabaseHostSetFileSizeParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String16 vfsFileName;
        public long expectedSize;

        private WebDatabaseHostSetFileSizeParams(int version) {
            super(24, version);
        }

        public WebDatabaseHostSetFileSizeParams() {
            this(0);
        }

        public static WebDatabaseHostSetFileSizeParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostSetFileSizeParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostSetFileSizeParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostSetFileSizeParams result = new WebDatabaseHostSetFileSizeParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.vfsFileName = String16.decode(decoder1);
                result.expectedSize = decoder0.readLong(16);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.vfsFileName, 8, false);
            encoder0.encode(this.expectedSize, 16);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostSetFileSizeResponseParams.class */
    public static final class WebDatabaseHostSetFileSizeResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean success;

        private WebDatabaseHostSetFileSizeResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostSetFileSizeResponseParams() {
            this(0);
        }

        public static WebDatabaseHostSetFileSizeResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostSetFileSizeResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostSetFileSizeResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostSetFileSizeResponseParams result = new WebDatabaseHostSetFileSizeResponseParams(elementsOrVersion);
                result.success = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.success, 8, 0);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostSetFileSizeResponseParamsForwardToCallback.class */
    static class WebDatabaseHostSetFileSizeResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.SetFileSizeResponse mCallback;

        WebDatabaseHostSetFileSizeResponseParamsForwardToCallback(WebDatabaseHost.SetFileSizeResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(4, 2)) {
                    return false;
                }
                WebDatabaseHostSetFileSizeResponseParams response = WebDatabaseHostSetFileSizeResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Boolean.valueOf(response.success));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostSetFileSizeResponseParamsProxyToResponder.class */
    static class WebDatabaseHostSetFileSizeResponseParamsProxyToResponder implements WebDatabaseHost.SetFileSizeResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostSetFileSizeResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Boolean success) {
            WebDatabaseHostSetFileSizeResponseParams _response = new WebDatabaseHostSetFileSizeResponseParams();
            _response.success = success.booleanValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(4, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetSpaceAvailableParams.class */
    static final class WebDatabaseHostGetSpaceAvailableParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;

        private WebDatabaseHostGetSpaceAvailableParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetSpaceAvailableParams() {
            this(0);
        }

        public static WebDatabaseHostGetSpaceAvailableParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetSpaceAvailableParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetSpaceAvailableParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetSpaceAvailableParams result = new WebDatabaseHostGetSpaceAvailableParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetSpaceAvailableResponseParams.class */
    public static final class WebDatabaseHostGetSpaceAvailableResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public long spaceAvailable;

        private WebDatabaseHostGetSpaceAvailableResponseParams(int version) {
            super(16, version);
        }

        public WebDatabaseHostGetSpaceAvailableResponseParams() {
            this(0);
        }

        public static WebDatabaseHostGetSpaceAvailableResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostGetSpaceAvailableResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostGetSpaceAvailableResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostGetSpaceAvailableResponseParams result = new WebDatabaseHostGetSpaceAvailableResponseParams(elementsOrVersion);
                result.spaceAvailable = decoder0.readLong(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.spaceAvailable, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetSpaceAvailableResponseParamsForwardToCallback.class */
    static class WebDatabaseHostGetSpaceAvailableResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final WebDatabaseHost.GetSpaceAvailableResponse mCallback;

        WebDatabaseHostGetSpaceAvailableResponseParamsForwardToCallback(WebDatabaseHost.GetSpaceAvailableResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(5, 2)) {
                    return false;
                }
                WebDatabaseHostGetSpaceAvailableResponseParams response = WebDatabaseHostGetSpaceAvailableResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Long.valueOf(response.spaceAvailable));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostGetSpaceAvailableResponseParamsProxyToResponder.class */
    static class WebDatabaseHostGetSpaceAvailableResponseParamsProxyToResponder implements WebDatabaseHost.GetSpaceAvailableResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        WebDatabaseHostGetSpaceAvailableResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Long spaceAvailable) {
            WebDatabaseHostGetSpaceAvailableResponseParams _response = new WebDatabaseHostGetSpaceAvailableResponseParams();
            _response.spaceAvailable = spaceAvailable.longValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(5, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostOpenedParams.class */
    static final class WebDatabaseHostOpenedParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public String16 databaseName;
        public String16 databaseDescription;
        public long estimatedSize;

        private WebDatabaseHostOpenedParams(int version) {
            super(40, version);
        }

        public WebDatabaseHostOpenedParams() {
            this(0);
        }

        public static WebDatabaseHostOpenedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostOpenedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostOpenedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostOpenedParams result = new WebDatabaseHostOpenedParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.databaseName = String16.decode(decoder12);
                Decoder decoder13 = decoder0.readPointer(24, false);
                result.databaseDescription = String16.decode(decoder13);
                result.estimatedSize = decoder0.readLong(32);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode((Struct) this.databaseName, 16, false);
            encoder0.encode((Struct) this.databaseDescription, 24, false);
            encoder0.encode(this.estimatedSize, 32);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostModifiedParams.class */
    static final class WebDatabaseHostModifiedParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public String16 databaseName;

        private WebDatabaseHostModifiedParams(int version) {
            super(24, version);
        }

        public WebDatabaseHostModifiedParams() {
            this(0);
        }

        public static WebDatabaseHostModifiedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostModifiedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostModifiedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostModifiedParams result = new WebDatabaseHostModifiedParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.databaseName = String16.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode((Struct) this.databaseName, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostClosedParams.class */
    static final class WebDatabaseHostClosedParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public String16 databaseName;

        private WebDatabaseHostClosedParams(int version) {
            super(24, version);
        }

        public WebDatabaseHostClosedParams() {
            this(0);
        }

        public static WebDatabaseHostClosedParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostClosedParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostClosedParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostClosedParams result = new WebDatabaseHostClosedParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.databaseName = String16.decode(decoder12);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode((Struct) this.databaseName, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/WebDatabaseHost_Internal$WebDatabaseHostHandleSqliteErrorParams.class */
    static final class WebDatabaseHostHandleSqliteErrorParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public String16 databaseName;
        public int error;

        private WebDatabaseHostHandleSqliteErrorParams(int version) {
            super(32, version);
        }

        public WebDatabaseHostHandleSqliteErrorParams() {
            this(0);
        }

        public static WebDatabaseHostHandleSqliteErrorParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static WebDatabaseHostHandleSqliteErrorParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static WebDatabaseHostHandleSqliteErrorParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                WebDatabaseHostHandleSqliteErrorParams result = new WebDatabaseHostHandleSqliteErrorParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                Decoder decoder12 = decoder0.readPointer(16, false);
                result.databaseName = String16.decode(decoder12);
                result.error = decoder0.readInt(24);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode((Struct) this.databaseName, 16, false);
            encoder0.encode(this.error, 24);
        }
    }
}
