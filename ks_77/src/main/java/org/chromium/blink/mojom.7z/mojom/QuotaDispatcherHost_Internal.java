package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.QuotaDispatcherHost;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;
import org.chromium.url.mojom.Origin;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal.class */
class QuotaDispatcherHost_Internal {
    public static final Interface.Manager<QuotaDispatcherHost, QuotaDispatcherHost.Proxy> MANAGER = new Interface.Manager<QuotaDispatcherHost, QuotaDispatcherHost.Proxy>() { // from class: org.chromium.blink.mojom.QuotaDispatcherHost_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.QuotaDispatcherHost";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public QuotaDispatcherHost.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, QuotaDispatcherHost impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public QuotaDispatcherHost[] buildArray(int size) {
            return new QuotaDispatcherHost[size];
        }
    };
    private static final int QUERY_STORAGE_USAGE_AND_QUOTA_ORDINAL = 0;
    private static final int REQUEST_STORAGE_QUOTA_ORDINAL = 1;

    QuotaDispatcherHost_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements QuotaDispatcherHost.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.QuotaDispatcherHost
        public void queryStorageUsageAndQuota(Origin origin, int storageType, QuotaDispatcherHost.QueryStorageUsageAndQuotaResponse callback) {
            QuotaDispatcherHostQueryStorageUsageAndQuotaParams _message = new QuotaDispatcherHostQueryStorageUsageAndQuotaParams();
            _message.origin = origin;
            _message.storageType = storageType;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.QuotaDispatcherHost
        public void requestStorageQuota(Origin origin, int storageType, long requestedSize, QuotaDispatcherHost.RequestStorageQuotaResponse callback) {
            QuotaDispatcherHostRequestStorageQuotaParams _message = new QuotaDispatcherHostRequestStorageQuotaParams();
            _message.origin = origin;
            _message.storageType = storageType;
            _message.requestedSize = requestedSize;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new QuotaDispatcherHostRequestStorageQuotaResponseParamsForwardToCallback(callback));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<QuotaDispatcherHost> {
        Stub(Core core, QuotaDispatcherHost impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(QuotaDispatcherHost_Internal.MANAGER, messageWithHeader);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), QuotaDispatcherHost_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        QuotaDispatcherHostQueryStorageUsageAndQuotaParams data = QuotaDispatcherHostQueryStorageUsageAndQuotaParams.deserialize(messageWithHeader.getPayload());
                        getImpl().queryStorageUsageAndQuota(data.origin, data.storageType, new QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        QuotaDispatcherHostRequestStorageQuotaParams data2 = QuotaDispatcherHostRequestStorageQuotaParams.deserialize(messageWithHeader.getPayload());
                        getImpl().requestStorageQuota(data2.origin, data2.storageType, data2.requestedSize, new QuotaDispatcherHostRequestStorageQuotaResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostQueryStorageUsageAndQuotaParams.class */
    static final class QuotaDispatcherHostQueryStorageUsageAndQuotaParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public int storageType;

        private QuotaDispatcherHostQueryStorageUsageAndQuotaParams(int version) {
            super(24, version);
        }

        public QuotaDispatcherHostQueryStorageUsageAndQuotaParams() {
            this(0);
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                QuotaDispatcherHostQueryStorageUsageAndQuotaParams result = new QuotaDispatcherHostQueryStorageUsageAndQuotaParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                result.storageType = decoder0.readInt(16);
                StorageType.validate(result.storageType);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode(this.storageType, 16);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams.class */
    public static final class QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams extends Struct {
        private static final int STRUCT_SIZE = 40;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(40, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int error;
        public long currentUsage;
        public long currentQuota;
        public UsageBreakdown usageBreakdown;

        private QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams(int version) {
            super(40, version);
        }

        public QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams() {
            this(0);
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams result = new QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams(elementsOrVersion);
                result.error = decoder0.readInt(8);
                QuotaStatusCode.validate(result.error);
                result.currentUsage = decoder0.readLong(16);
                result.currentQuota = decoder0.readLong(24);
                Decoder decoder1 = decoder0.readPointer(32, false);
                result.usageBreakdown = UsageBreakdown.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.error, 8);
            encoder0.encode(this.currentUsage, 16);
            encoder0.encode(this.currentQuota, 24);
            encoder0.encode((Struct) this.usageBreakdown, 32, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsForwardToCallback.class */
    static class QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final QuotaDispatcherHost.QueryStorageUsageAndQuotaResponse mCallback;

        QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsForwardToCallback(QuotaDispatcherHost.QueryStorageUsageAndQuotaResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams response = QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.error), Long.valueOf(response.currentUsage), Long.valueOf(response.currentQuota), response.usageBreakdown);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsProxyToResponder.class */
    static class QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsProxyToResponder implements QuotaDispatcherHost.QueryStorageUsageAndQuotaResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback4
        public void call(Integer error, Long currentUsage, Long currentQuota, UsageBreakdown usageBreakdown) {
            QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams _response = new QuotaDispatcherHostQueryStorageUsageAndQuotaResponseParams();
            _response.error = error.intValue();
            _response.currentUsage = currentUsage.longValue();
            _response.currentQuota = currentQuota.longValue();
            _response.usageBreakdown = usageBreakdown;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostRequestStorageQuotaParams.class */
    static final class QuotaDispatcherHostRequestStorageQuotaParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public Origin origin;
        public int storageType;
        public long requestedSize;

        private QuotaDispatcherHostRequestStorageQuotaParams(int version) {
            super(32, version);
        }

        public QuotaDispatcherHostRequestStorageQuotaParams() {
            this(0);
        }

        public static QuotaDispatcherHostRequestStorageQuotaParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static QuotaDispatcherHostRequestStorageQuotaParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static QuotaDispatcherHostRequestStorageQuotaParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                QuotaDispatcherHostRequestStorageQuotaParams result = new QuotaDispatcherHostRequestStorageQuotaParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.origin = Origin.decode(decoder1);
                result.storageType = decoder0.readInt(16);
                StorageType.validate(result.storageType);
                result.requestedSize = decoder0.readLong(24);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.origin, 8, false);
            encoder0.encode(this.storageType, 16);
            encoder0.encode(this.requestedSize, 24);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostRequestStorageQuotaResponseParams.class */
    public static final class QuotaDispatcherHostRequestStorageQuotaResponseParams extends Struct {
        private static final int STRUCT_SIZE = 32;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(32, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int error;
        public long currentUsage;
        public long grantedQuota;

        private QuotaDispatcherHostRequestStorageQuotaResponseParams(int version) {
            super(32, version);
        }

        public QuotaDispatcherHostRequestStorageQuotaResponseParams() {
            this(0);
        }

        public static QuotaDispatcherHostRequestStorageQuotaResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static QuotaDispatcherHostRequestStorageQuotaResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static QuotaDispatcherHostRequestStorageQuotaResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                QuotaDispatcherHostRequestStorageQuotaResponseParams result = new QuotaDispatcherHostRequestStorageQuotaResponseParams(elementsOrVersion);
                result.error = decoder0.readInt(8);
                QuotaStatusCode.validate(result.error);
                result.currentUsage = decoder0.readLong(16);
                result.grantedQuota = decoder0.readLong(24);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.error, 8);
            encoder0.encode(this.currentUsage, 16);
            encoder0.encode(this.grantedQuota, 24);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostRequestStorageQuotaResponseParamsForwardToCallback.class */
    static class QuotaDispatcherHostRequestStorageQuotaResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final QuotaDispatcherHost.RequestStorageQuotaResponse mCallback;

        QuotaDispatcherHostRequestStorageQuotaResponseParamsForwardToCallback(QuotaDispatcherHost.RequestStorageQuotaResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                QuotaDispatcherHostRequestStorageQuotaResponseParams response = QuotaDispatcherHostRequestStorageQuotaResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.error), Long.valueOf(response.currentUsage), Long.valueOf(response.grantedQuota));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/QuotaDispatcherHost_Internal$QuotaDispatcherHostRequestStorageQuotaResponseParamsProxyToResponder.class */
    static class QuotaDispatcherHostRequestStorageQuotaResponseParamsProxyToResponder implements QuotaDispatcherHost.RequestStorageQuotaResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        QuotaDispatcherHostRequestStorageQuotaResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback3
        public void call(Integer error, Long currentUsage, Long grantedQuota) {
            QuotaDispatcherHostRequestStorageQuotaResponseParams _response = new QuotaDispatcherHostRequestStorageQuotaResponseParams();
            _response.error = error.intValue();
            _response.currentUsage = currentUsage.longValue();
            _response.grantedQuota = grantedQuota.longValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }
}
