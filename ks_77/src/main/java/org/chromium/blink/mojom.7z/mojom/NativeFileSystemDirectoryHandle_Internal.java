package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.NativeFileSystemDirectoryHandle;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.InterfaceRequest;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.SideEffectFreeCloseable;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal.class */
class NativeFileSystemDirectoryHandle_Internal {
    public static final Interface.Manager<NativeFileSystemDirectoryHandle, NativeFileSystemDirectoryHandle.Proxy> MANAGER = new Interface.Manager<NativeFileSystemDirectoryHandle, NativeFileSystemDirectoryHandle.Proxy>() { // from class: org.chromium.blink.mojom.NativeFileSystemDirectoryHandle_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.NativeFileSystemDirectoryHandle";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public NativeFileSystemDirectoryHandle.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, NativeFileSystemDirectoryHandle impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public NativeFileSystemDirectoryHandle[] buildArray(int size) {
            return new NativeFileSystemDirectoryHandle[size];
        }
    };
    private static final int GET_PERMISSION_STATUS_ORDINAL = 0;
    private static final int REQUEST_PERMISSION_ORDINAL = 1;
    private static final int GET_FILE_ORDINAL = 2;
    private static final int GET_DIRECTORY_ORDINAL = 3;
    private static final int GET_ENTRIES_ORDINAL = 4;
    private static final int REMOVE_ENTRY_ORDINAL = 5;
    private static final int TRANSFER_ORDINAL = 6;

    NativeFileSystemDirectoryHandle_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements NativeFileSystemDirectoryHandle.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void getPermissionStatus(boolean writable, NativeFileSystemDirectoryHandle.GetPermissionStatusResponse callback) {
            NativeFileSystemDirectoryHandleGetPermissionStatusParams _message = new NativeFileSystemDirectoryHandleGetPermissionStatusParams();
            _message.writable = writable;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0, 1, 0L)), new NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void requestPermission(boolean writable, NativeFileSystemDirectoryHandle.RequestPermissionResponse callback) {
            NativeFileSystemDirectoryHandleRequestPermissionParams _message = new NativeFileSystemDirectoryHandleRequestPermissionParams();
            _message.writable = writable;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1, 1, 0L)), new NativeFileSystemDirectoryHandleRequestPermissionResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void getFile(String basename, boolean create, NativeFileSystemDirectoryHandle.GetFileResponse callback) {
            NativeFileSystemDirectoryHandleGetFileParams _message = new NativeFileSystemDirectoryHandleGetFileParams();
            _message.basename = basename;
            _message.create = create;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2, 1, 0L)), new NativeFileSystemDirectoryHandleGetFileResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void getDirectory(String basename, boolean create, NativeFileSystemDirectoryHandle.GetDirectoryResponse callback) {
            NativeFileSystemDirectoryHandleGetDirectoryParams _message = new NativeFileSystemDirectoryHandleGetDirectoryParams();
            _message.basename = basename;
            _message.create = create;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3, 1, 0L)), new NativeFileSystemDirectoryHandleGetDirectoryResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void getEntries(NativeFileSystemDirectoryHandle.GetEntriesResponse callback) {
            NativeFileSystemDirectoryHandleGetEntriesParams _message = new NativeFileSystemDirectoryHandleGetEntriesParams();
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4, 1, 0L)), new NativeFileSystemDirectoryHandleGetEntriesResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void removeEntry(String basename, boolean recurse, NativeFileSystemDirectoryHandle.RemoveEntryResponse callback) {
            NativeFileSystemDirectoryHandleRemoveEntryParams _message = new NativeFileSystemDirectoryHandleRemoveEntryParams();
            _message.basename = basename;
            _message.recurse = recurse;
            getProxyHandler().getMessageReceiver().acceptWithResponder(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(5, 1, 0L)), new NativeFileSystemDirectoryHandleRemoveEntryResponseParamsForwardToCallback(callback));
        }

        @Override // org.chromium.blink.mojom.NativeFileSystemDirectoryHandle
        public void transfer(InterfaceRequest<NativeFileSystemTransferToken> token) {
            NativeFileSystemDirectoryHandleTransferParams _message = new NativeFileSystemDirectoryHandleTransferParams();
            _message.token = token;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(6)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<NativeFileSystemDirectoryHandle> {
        Stub(Core core, NativeFileSystemDirectoryHandle impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(NativeFileSystemDirectoryHandle_Internal.MANAGER, messageWithHeader);
                    case 6:
                        NativeFileSystemDirectoryHandleTransferParams data = NativeFileSystemDirectoryHandleTransferParams.deserialize(messageWithHeader.getPayload());
                        getImpl().transfer(data.token);
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), NativeFileSystemDirectoryHandle_Internal.MANAGER, messageWithHeader, receiver);
                    case 0:
                        getImpl().getPermissionStatus(NativeFileSystemDirectoryHandleGetPermissionStatusParams.deserialize(messageWithHeader.getPayload()).writable, new NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 1:
                        getImpl().requestPermission(NativeFileSystemDirectoryHandleRequestPermissionParams.deserialize(messageWithHeader.getPayload()).writable, new NativeFileSystemDirectoryHandleRequestPermissionResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 2:
                        NativeFileSystemDirectoryHandleGetFileParams data = NativeFileSystemDirectoryHandleGetFileParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getFile(data.basename, data.create, new NativeFileSystemDirectoryHandleGetFileResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 3:
                        NativeFileSystemDirectoryHandleGetDirectoryParams data2 = NativeFileSystemDirectoryHandleGetDirectoryParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getDirectory(data2.basename, data2.create, new NativeFileSystemDirectoryHandleGetDirectoryResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 4:
                        NativeFileSystemDirectoryHandleGetEntriesParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getEntries(new NativeFileSystemDirectoryHandleGetEntriesResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    case 5:
                        NativeFileSystemDirectoryHandleRemoveEntryParams data3 = NativeFileSystemDirectoryHandleRemoveEntryParams.deserialize(messageWithHeader.getPayload());
                        getImpl().removeEntry(data3.basename, data3.recurse, new NativeFileSystemDirectoryHandleRemoveEntryResponseParamsProxyToResponder(getCore(), receiver, header.getRequestId()));
                        return true;
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetPermissionStatusParams.class */
    static final class NativeFileSystemDirectoryHandleGetPermissionStatusParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean writable;

        private NativeFileSystemDirectoryHandleGetPermissionStatusParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleGetPermissionStatusParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetPermissionStatusParams result = new NativeFileSystemDirectoryHandleGetPermissionStatusParams(elementsOrVersion);
                result.writable = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.writable, 8, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;

        private NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams result = new NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                PermissionStatus.validate(result.status);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.GetPermissionStatusResponse mCallback;

        NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.GetPermissionStatusResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams response = NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.GetPermissionStatusResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleGetPermissionStatusResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer status) {
            NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams _response = new NativeFileSystemDirectoryHandleGetPermissionStatusResponseParams();
            _response.status = status.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(0, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRequestPermissionParams.class */
    static final class NativeFileSystemDirectoryHandleRequestPermissionParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public boolean writable;

        private NativeFileSystemDirectoryHandleRequestPermissionParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleRequestPermissionParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleRequestPermissionParams result = new NativeFileSystemDirectoryHandleRequestPermissionParams(elementsOrVersion);
                result.writable = decoder0.readBoolean(8, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.writable, 8, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRequestPermissionResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleRequestPermissionResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int status;

        private NativeFileSystemDirectoryHandleRequestPermissionResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleRequestPermissionResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleRequestPermissionResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleRequestPermissionResponseParams result = new NativeFileSystemDirectoryHandleRequestPermissionResponseParams(elementsOrVersion);
                result.status = decoder0.readInt(8);
                PermissionStatus.validate(result.status);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.status, 8);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRequestPermissionResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleRequestPermissionResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.RequestPermissionResponse mCallback;

        NativeFileSystemDirectoryHandleRequestPermissionResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.RequestPermissionResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleRequestPermissionResponseParams response = NativeFileSystemDirectoryHandleRequestPermissionResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(Integer.valueOf(response.status));
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRequestPermissionResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleRequestPermissionResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.RequestPermissionResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleRequestPermissionResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(Integer status) {
            NativeFileSystemDirectoryHandleRequestPermissionResponseParams _response = new NativeFileSystemDirectoryHandleRequestPermissionResponseParams();
            _response.status = status.intValue();
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(1, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetFileParams.class */
    static final class NativeFileSystemDirectoryHandleGetFileParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String basename;
        public boolean create;

        private NativeFileSystemDirectoryHandleGetFileParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleGetFileParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetFileParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetFileParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetFileParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetFileParams result = new NativeFileSystemDirectoryHandleGetFileParams(elementsOrVersion);
                result.basename = decoder0.readString(8, false);
                result.create = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.basename, 8, false);
            encoder0.encode(this.create, 16, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetFileResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleGetFileResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemFileHandle file;

        private NativeFileSystemDirectoryHandleGetFileResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleGetFileResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetFileResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetFileResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetFileResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetFileResponseParams result = new NativeFileSystemDirectoryHandleGetFileResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.file = (NativeFileSystemFileHandle) decoder0.readServiceInterface(16, true, NativeFileSystemFileHandle.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode((Encoder) this.file, 16, true, (Interface.Manager<Encoder, ?>) NativeFileSystemFileHandle.MANAGER);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetFileResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleGetFileResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.GetFileResponse mCallback;

        NativeFileSystemDirectoryHandleGetFileResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.GetFileResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(2, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleGetFileResponseParams response = NativeFileSystemDirectoryHandleGetFileResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.file);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetFileResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleGetFileResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.GetFileResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleGetFileResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemFileHandle file) {
            NativeFileSystemDirectoryHandleGetFileResponseParams _response = new NativeFileSystemDirectoryHandleGetFileResponseParams();
            _response.result = result;
            _response.file = file;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(2, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetDirectoryParams.class */
    static final class NativeFileSystemDirectoryHandleGetDirectoryParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String basename;
        public boolean create;

        private NativeFileSystemDirectoryHandleGetDirectoryParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleGetDirectoryParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetDirectoryParams result = new NativeFileSystemDirectoryHandleGetDirectoryParams(elementsOrVersion);
                result.basename = decoder0.readString(8, false);
                result.create = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.basename, 8, false);
            encoder0.encode(this.create, 16, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetDirectoryResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleGetDirectoryResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemDirectoryHandle directory;

        private NativeFileSystemDirectoryHandleGetDirectoryResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleGetDirectoryResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetDirectoryResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetDirectoryResponseParams result = new NativeFileSystemDirectoryHandleGetDirectoryResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                result.directory = (NativeFileSystemDirectoryHandle) decoder0.readServiceInterface(16, true, NativeFileSystemDirectoryHandle.MANAGER);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            encoder0.encode((Encoder) this.directory, 16, true, (Interface.Manager<Encoder, ?>) NativeFileSystemDirectoryHandle.MANAGER);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetDirectoryResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleGetDirectoryResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.GetDirectoryResponse mCallback;

        NativeFileSystemDirectoryHandleGetDirectoryResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.GetDirectoryResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(3, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleGetDirectoryResponseParams response = NativeFileSystemDirectoryHandleGetDirectoryResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.directory);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetDirectoryResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleGetDirectoryResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.GetDirectoryResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleGetDirectoryResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemDirectoryHandle directory) {
            NativeFileSystemDirectoryHandleGetDirectoryResponseParams _response = new NativeFileSystemDirectoryHandleGetDirectoryResponseParams();
            _response.result = result;
            _response.directory = directory;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(3, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetEntriesParams.class */
    static final class NativeFileSystemDirectoryHandleGetEntriesParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private NativeFileSystemDirectoryHandleGetEntriesParams(int version) {
            super(8, version);
        }

        public NativeFileSystemDirectoryHandleGetEntriesParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetEntriesParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetEntriesParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetEntriesParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetEntriesParams result = new NativeFileSystemDirectoryHandleGetEntriesParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetEntriesResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleGetEntriesResponseParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;
        public NativeFileSystemEntry[] entries;

        private NativeFileSystemDirectoryHandleGetEntriesResponseParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleGetEntriesResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleGetEntriesResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleGetEntriesResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleGetEntriesResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleGetEntriesResponseParams result = new NativeFileSystemDirectoryHandleGetEntriesResponseParams(elementsOrVersion);
                result.result = NativeFileSystemError.decode(decoder0.readPointer(8, false));
                Decoder decoder1 = decoder0.readPointer(16, false);
                DataHeader si1 = decoder1.readDataHeaderForPointerArray(-1);
                result.entries = new NativeFileSystemEntry[si1.elementsOrVersion];
                for (int i1 = 0; i1 < si1.elementsOrVersion; i1++) {
                    Decoder decoder2 = decoder1.readPointer(8 + (8 * i1), false);
                    result.entries[i1] = NativeFileSystemEntry.decode(decoder2);
                }
                return result;
            } finally {
                decoder0.decreaseStackDepth();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
            if (this.entries == null) {
                encoder0.encodeNullPointer(16, false);
                return;
            }
            Encoder encoder1 = encoder0.encodePointerArray(this.entries.length, 16, -1);
            for (int i0 = 0; i0 < this.entries.length; i0++) {
                encoder1.encode((Struct) this.entries[i0], 8 + (8 * i0), false);
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetEntriesResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleGetEntriesResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.GetEntriesResponse mCallback;

        NativeFileSystemDirectoryHandleGetEntriesResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.GetEntriesResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(4, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleGetEntriesResponseParams response = NativeFileSystemDirectoryHandleGetEntriesResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result, response.entries);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleGetEntriesResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleGetEntriesResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.GetEntriesResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleGetEntriesResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback2
        public void call(NativeFileSystemError result, NativeFileSystemEntry[] entries) {
            NativeFileSystemDirectoryHandleGetEntriesResponseParams _response = new NativeFileSystemDirectoryHandleGetEntriesResponseParams();
            _response.result = result;
            _response.entries = entries;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(4, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRemoveEntryParams.class */
    static final class NativeFileSystemDirectoryHandleRemoveEntryParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public String basename;
        public boolean recurse;

        private NativeFileSystemDirectoryHandleRemoveEntryParams(int version) {
            super(24, version);
        }

        public NativeFileSystemDirectoryHandleRemoveEntryParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleRemoveEntryParams result = new NativeFileSystemDirectoryHandleRemoveEntryParams(elementsOrVersion);
                result.basename = decoder0.readString(8, false);
                result.recurse = decoder0.readBoolean(16, 0);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.basename, 8, false);
            encoder0.encode(this.recurse, 16, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRemoveEntryResponseParams.class */
    public static final class NativeFileSystemDirectoryHandleRemoveEntryResponseParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public NativeFileSystemError result;

        private NativeFileSystemDirectoryHandleRemoveEntryResponseParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleRemoveEntryResponseParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryResponseParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryResponseParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleRemoveEntryResponseParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleRemoveEntryResponseParams result = new NativeFileSystemDirectoryHandleRemoveEntryResponseParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.result = NativeFileSystemError.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.result, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRemoveEntryResponseParamsForwardToCallback.class */
    static class NativeFileSystemDirectoryHandleRemoveEntryResponseParamsForwardToCallback extends SideEffectFreeCloseable implements MessageReceiver {
        private final NativeFileSystemDirectoryHandle.RemoveEntryResponse mCallback;

        NativeFileSystemDirectoryHandleRemoveEntryResponseParamsForwardToCallback(NativeFileSystemDirectoryHandle.RemoveEntryResponse callback) {
            this.mCallback = callback;
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(5, 2)) {
                    return false;
                }
                NativeFileSystemDirectoryHandleRemoveEntryResponseParams response = NativeFileSystemDirectoryHandleRemoveEntryResponseParams.deserialize(messageWithHeader.getPayload());
                this.mCallback.call(response.result);
                return true;
            } catch (DeserializationException e) {
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleRemoveEntryResponseParamsProxyToResponder.class */
    static class NativeFileSystemDirectoryHandleRemoveEntryResponseParamsProxyToResponder implements NativeFileSystemDirectoryHandle.RemoveEntryResponse {
        private final Core mCore;
        private final MessageReceiver mMessageReceiver;
        private final long mRequestId;

        NativeFileSystemDirectoryHandleRemoveEntryResponseParamsProxyToResponder(Core core, MessageReceiver messageReceiver, long requestId) {
            this.mCore = core;
            this.mMessageReceiver = messageReceiver;
            this.mRequestId = requestId;
        }

        @Override // org.chromium.mojo.bindings.Callbacks.Callback1
        public void call(NativeFileSystemError result) {
            NativeFileSystemDirectoryHandleRemoveEntryResponseParams _response = new NativeFileSystemDirectoryHandleRemoveEntryResponseParams();
            _response.result = result;
            ServiceMessage _message = _response.serializeWithHeader(this.mCore, new MessageHeader(5, 2, this.mRequestId));
            this.mMessageReceiver.accept(_message);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/NativeFileSystemDirectoryHandle_Internal$NativeFileSystemDirectoryHandleTransferParams.class */
    static final class NativeFileSystemDirectoryHandleTransferParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public InterfaceRequest<NativeFileSystemTransferToken> token;

        private NativeFileSystemDirectoryHandleTransferParams(int version) {
            super(16, version);
        }

        public NativeFileSystemDirectoryHandleTransferParams() {
            this(0);
        }

        public static NativeFileSystemDirectoryHandleTransferParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static NativeFileSystemDirectoryHandleTransferParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static NativeFileSystemDirectoryHandleTransferParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                NativeFileSystemDirectoryHandleTransferParams result = new NativeFileSystemDirectoryHandleTransferParams(elementsOrVersion);
                result.token = decoder0.readInterfaceRequest(8, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((InterfaceRequest) this.token, 8, false);
        }
    }
}
