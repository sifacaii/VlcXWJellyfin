package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.EmbeddedWorkerInstanceClient;
import org.chromium.mojo.bindings.AssociatedInterfaceNotSupported;
import org.chromium.mojo.bindings.AssociatedInterfaceRequestNotSupported;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal.class */
class EmbeddedWorkerInstanceClient_Internal {
    public static final Interface.Manager<EmbeddedWorkerInstanceClient, EmbeddedWorkerInstanceClient.Proxy> MANAGER = new Interface.Manager<EmbeddedWorkerInstanceClient, EmbeddedWorkerInstanceClient.Proxy>() { // from class: org.chromium.blink.mojom.EmbeddedWorkerInstanceClient_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.EmbeddedWorkerInstanceClient";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public EmbeddedWorkerInstanceClient.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, EmbeddedWorkerInstanceClient impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public EmbeddedWorkerInstanceClient[] buildArray(int size) {
            return new EmbeddedWorkerInstanceClient[size];
        }
    };
    private static final int START_WORKER_ORDINAL = 0;
    private static final int STOP_WORKER_ORDINAL = 1;
    private static final int RESUME_AFTER_DOWNLOAD_ORDINAL = 2;
    private static final int ADD_MESSAGE_TO_CONSOLE_ORDINAL = 3;
    private static final int BIND_DEV_TOOLS_AGENT_ORDINAL = 4;

    EmbeddedWorkerInstanceClient_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements EmbeddedWorkerInstanceClient.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceClient
        public void startWorker(EmbeddedWorkerStartParams params) {
            EmbeddedWorkerInstanceClientStartWorkerParams _message = new EmbeddedWorkerInstanceClientStartWorkerParams();
            _message.params = params;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceClient
        public void stopWorker() {
            EmbeddedWorkerInstanceClientStopWorkerParams _message = new EmbeddedWorkerInstanceClientStopWorkerParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceClient
        public void resumeAfterDownload() {
            EmbeddedWorkerInstanceClientResumeAfterDownloadParams _message = new EmbeddedWorkerInstanceClientResumeAfterDownloadParams();
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(2)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceClient
        public void addMessageToConsole(int level, String message) {
            EmbeddedWorkerInstanceClientAddMessageToConsoleParams _message = new EmbeddedWorkerInstanceClientAddMessageToConsoleParams();
            _message.level = level;
            _message.message = message;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(3)));
        }

        @Override // org.chromium.blink.mojom.EmbeddedWorkerInstanceClient
        public void bindDevToolsAgent(AssociatedInterfaceNotSupported agentHost, AssociatedInterfaceRequestNotSupported agent) {
            EmbeddedWorkerInstanceClientBindDevToolsAgentParams _message = new EmbeddedWorkerInstanceClientBindDevToolsAgentParams();
            _message.agentHost = agentHost;
            _message.agent = agent;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(4)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<EmbeddedWorkerInstanceClient> {
        Stub(Core core, EmbeddedWorkerInstanceClient impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(EmbeddedWorkerInstanceClient_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        getImpl().startWorker(EmbeddedWorkerInstanceClientStartWorkerParams.deserialize(messageWithHeader.getPayload()).params);
                        return true;
                    case 1:
                        EmbeddedWorkerInstanceClientStopWorkerParams.deserialize(messageWithHeader.getPayload());
                        getImpl().stopWorker();
                        return true;
                    case 2:
                        EmbeddedWorkerInstanceClientResumeAfterDownloadParams.deserialize(messageWithHeader.getPayload());
                        getImpl().resumeAfterDownload();
                        return true;
                    case 3:
                        EmbeddedWorkerInstanceClientAddMessageToConsoleParams data = EmbeddedWorkerInstanceClientAddMessageToConsoleParams.deserialize(messageWithHeader.getPayload());
                        getImpl().addMessageToConsole(data.level, data.message);
                        return true;
                    case 4:
                        EmbeddedWorkerInstanceClientBindDevToolsAgentParams data2 = EmbeddedWorkerInstanceClientBindDevToolsAgentParams.deserialize(messageWithHeader.getPayload());
                        getImpl().bindDevToolsAgent(data2.agentHost, data2.agent);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), EmbeddedWorkerInstanceClient_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$EmbeddedWorkerInstanceClientStartWorkerParams.class */
    static final class EmbeddedWorkerInstanceClientStartWorkerParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public EmbeddedWorkerStartParams params;

        private EmbeddedWorkerInstanceClientStartWorkerParams(int version) {
            super(16, version);
        }

        public EmbeddedWorkerInstanceClientStartWorkerParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceClientStartWorkerParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceClientStartWorkerParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceClientStartWorkerParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceClientStartWorkerParams result = new EmbeddedWorkerInstanceClientStartWorkerParams(elementsOrVersion);
                Decoder decoder1 = decoder0.readPointer(8, false);
                result.params = EmbeddedWorkerStartParams.decode(decoder1);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode((Struct) this.params, 8, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$EmbeddedWorkerInstanceClientStopWorkerParams.class */
    static final class EmbeddedWorkerInstanceClientStopWorkerParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceClientStopWorkerParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceClientStopWorkerParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceClientStopWorkerParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceClientStopWorkerParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceClientStopWorkerParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceClientStopWorkerParams result = new EmbeddedWorkerInstanceClientStopWorkerParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$EmbeddedWorkerInstanceClientResumeAfterDownloadParams.class */
    static final class EmbeddedWorkerInstanceClientResumeAfterDownloadParams extends Struct {
        private static final int STRUCT_SIZE = 8;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(8, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];

        private EmbeddedWorkerInstanceClientResumeAfterDownloadParams(int version) {
            super(8, version);
        }

        public EmbeddedWorkerInstanceClientResumeAfterDownloadParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceClientResumeAfterDownloadParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceClientResumeAfterDownloadParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceClientResumeAfterDownloadParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceClientResumeAfterDownloadParams result = new EmbeddedWorkerInstanceClientResumeAfterDownloadParams(elementsOrVersion);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$EmbeddedWorkerInstanceClientAddMessageToConsoleParams.class */
    static final class EmbeddedWorkerInstanceClientAddMessageToConsoleParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int level;
        public String message;

        private EmbeddedWorkerInstanceClientAddMessageToConsoleParams(int version) {
            super(24, version);
        }

        public EmbeddedWorkerInstanceClientAddMessageToConsoleParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceClientAddMessageToConsoleParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceClientAddMessageToConsoleParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceClientAddMessageToConsoleParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceClientAddMessageToConsoleParams result = new EmbeddedWorkerInstanceClientAddMessageToConsoleParams(elementsOrVersion);
                result.level = decoder0.readInt(8);
                ConsoleMessageLevel.validate(result.level);
                result.message = decoder0.readString(16, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.level, 8);
            encoder0.encode(this.message, 16, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/EmbeddedWorkerInstanceClient_Internal$EmbeddedWorkerInstanceClientBindDevToolsAgentParams.class */
    static final class EmbeddedWorkerInstanceClientBindDevToolsAgentParams extends Struct {
        private static final int STRUCT_SIZE = 24;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(24, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public AssociatedInterfaceNotSupported agentHost;
        public AssociatedInterfaceRequestNotSupported agent;

        private EmbeddedWorkerInstanceClientBindDevToolsAgentParams(int version) {
            super(24, version);
        }

        public EmbeddedWorkerInstanceClientBindDevToolsAgentParams() {
            this(0);
        }

        public static EmbeddedWorkerInstanceClientBindDevToolsAgentParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static EmbeddedWorkerInstanceClientBindDevToolsAgentParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static EmbeddedWorkerInstanceClientBindDevToolsAgentParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                EmbeddedWorkerInstanceClientBindDevToolsAgentParams result = new EmbeddedWorkerInstanceClientBindDevToolsAgentParams(elementsOrVersion);
                result.agentHost = decoder0.readAssociatedServiceInterfaceNotSupported(8, false);
                result.agent = decoder0.readAssociatedInterfaceRequestNotSupported(16, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.agentHost, 8, false);
            encoder0.encode(this.agent, 16, false);
        }
    }
}
