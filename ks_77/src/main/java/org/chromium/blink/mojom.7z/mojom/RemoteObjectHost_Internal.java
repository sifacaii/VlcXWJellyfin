package org.chromium.blink.mojom;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import org.chromium.blink.mojom.RemoteObjectHost;
import org.chromium.mojo.bindings.DataHeader;
import org.chromium.mojo.bindings.Decoder;
import org.chromium.mojo.bindings.DeserializationException;
import org.chromium.mojo.bindings.Encoder;
import org.chromium.mojo.bindings.Interface;
import org.chromium.mojo.bindings.InterfaceControlMessagesHelper;
import org.chromium.mojo.bindings.InterfaceRequest;
import org.chromium.mojo.bindings.Message;
import org.chromium.mojo.bindings.MessageHeader;
import org.chromium.mojo.bindings.MessageReceiver;
import org.chromium.mojo.bindings.MessageReceiverWithResponder;
import org.chromium.mojo.bindings.ServiceMessage;
import org.chromium.mojo.bindings.Struct;
import org.chromium.mojo.system.Core;

/* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RemoteObjectHost_Internal.class */
class RemoteObjectHost_Internal {
    public static final Interface.Manager<RemoteObjectHost, RemoteObjectHost.Proxy> MANAGER = new Interface.Manager<RemoteObjectHost, RemoteObjectHost.Proxy>() { // from class: org.chromium.blink.mojom.RemoteObjectHost_Internal.1
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public String getName() {
            return "blink.mojom.RemoteObjectHost";
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public int getVersion() {
            return 0;
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        /* renamed from: buildProxy */
        public RemoteObjectHost.Proxy buildProxy2(Core core, MessageReceiverWithResponder messageReceiver) {
            return new Proxy(core, messageReceiver);
        }

        @Override // org.chromium.mojo.bindings.Interface.Manager
        public Stub buildStub(Core core, RemoteObjectHost impl) {
            return new Stub(core, impl);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // org.chromium.mojo.bindings.Interface.Manager
        public RemoteObjectHost[] buildArray(int size) {
            return new RemoteObjectHost[size];
        }
    };
    private static final int GET_OBJECT_ORDINAL = 0;
    private static final int RELEASE_OBJECT_ORDINAL = 1;

    RemoteObjectHost_Internal() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RemoteObjectHost_Internal$Proxy.class */
    public static final class Proxy extends Interface.AbstractProxy implements RemoteObjectHost.Proxy {
        Proxy(Core core, MessageReceiverWithResponder messageReceiver) {
            super(core, messageReceiver);
        }

        @Override // org.chromium.blink.mojom.RemoteObjectHost
        public void getObject(int objectId, InterfaceRequest<RemoteObject> request) {
            RemoteObjectHostGetObjectParams _message = new RemoteObjectHostGetObjectParams();
            _message.objectId = objectId;
            _message.request = request;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(0)));
        }

        @Override // org.chromium.blink.mojom.RemoteObjectHost
        public void releaseObject(int objectId) {
            RemoteObjectHostReleaseObjectParams _message = new RemoteObjectHostReleaseObjectParams();
            _message.objectId = objectId;
            getProxyHandler().getMessageReceiver().accept(_message.serializeWithHeader(getProxyHandler().getCore(), new MessageHeader(1)));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RemoteObjectHost_Internal$Stub.class */
    public static final class Stub extends Interface.Stub<RemoteObjectHost> {
        Stub(Core core, RemoteObjectHost impl) {
            super(core, impl);
        }

        @Override // org.chromium.mojo.bindings.MessageReceiver
        public boolean accept(Message message) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(0)) {
                    return false;
                }
                switch (header.getType()) {
                    case -2:
                        return InterfaceControlMessagesHelper.handleRunOrClosePipe(RemoteObjectHost_Internal.MANAGER, messageWithHeader);
                    case -1:
                    default:
                        return false;
                    case 0:
                        RemoteObjectHostGetObjectParams data = RemoteObjectHostGetObjectParams.deserialize(messageWithHeader.getPayload());
                        getImpl().getObject(data.objectId, data.request);
                        return true;
                    case 1:
                        getImpl().releaseObject(RemoteObjectHostReleaseObjectParams.deserialize(messageWithHeader.getPayload()).objectId);
                        return true;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }

        @Override // org.chromium.mojo.bindings.MessageReceiverWithResponder
        public boolean acceptWithResponder(Message message, MessageReceiver receiver) {
            try {
                ServiceMessage messageWithHeader = message.asServiceMessage();
                MessageHeader header = messageWithHeader.getHeader();
                if (!header.validateHeader(1)) {
                    return false;
                }
                switch (header.getType()) {
                    case -1:
                        return InterfaceControlMessagesHelper.handleRun(getCore(), RemoteObjectHost_Internal.MANAGER, messageWithHeader, receiver);
                    default:
                        return false;
                }
            } catch (DeserializationException e) {
                System.err.println(e.toString());
                return false;
            }
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RemoteObjectHost_Internal$RemoteObjectHostGetObjectParams.class */
    static final class RemoteObjectHostGetObjectParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int objectId;
        public InterfaceRequest<RemoteObject> request;

        private RemoteObjectHostGetObjectParams(int version) {
            super(16, version);
        }

        public RemoteObjectHostGetObjectParams() {
            this(0);
        }

        public static RemoteObjectHostGetObjectParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static RemoteObjectHostGetObjectParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static RemoteObjectHostGetObjectParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                RemoteObjectHostGetObjectParams result = new RemoteObjectHostGetObjectParams(elementsOrVersion);
                result.objectId = decoder0.readInt(8);
                result.request = decoder0.readInterfaceRequest(12, false);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.objectId, 8);
            encoder0.encode((InterfaceRequest) this.request, 12, false);
        }
    }

    /* loaded from: xwalk_main_fat-77.3.aar:classes.jar:org/chromium/blink/mojom/RemoteObjectHost_Internal$RemoteObjectHostReleaseObjectParams.class */
    static final class RemoteObjectHostReleaseObjectParams extends Struct {
        private static final int STRUCT_SIZE = 16;
        private static final DataHeader[] VERSION_ARRAY = {new DataHeader(16, 0)};
        private static final DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[0];
        public int objectId;

        private RemoteObjectHostReleaseObjectParams(int version) {
            super(16, version);
        }

        public RemoteObjectHostReleaseObjectParams() {
            this(0);
        }

        public static RemoteObjectHostReleaseObjectParams deserialize(Message message) {
            return decode(new Decoder(message));
        }

        public static RemoteObjectHostReleaseObjectParams deserialize(ByteBuffer data) {
            return deserialize(new Message(data, new ArrayList()));
        }

        public static RemoteObjectHostReleaseObjectParams decode(Decoder decoder0) {
            if (decoder0 == null) {
                return null;
            }
            decoder0.increaseStackDepth();
            try {
                DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);
                int elementsOrVersion = mainDataHeader.elementsOrVersion;
                RemoteObjectHostReleaseObjectParams result = new RemoteObjectHostReleaseObjectParams(elementsOrVersion);
                result.objectId = decoder0.readInt(8);
                decoder0.decreaseStackDepth();
                return result;
            } catch (Throwable th) {
                decoder0.decreaseStackDepth();
                throw th;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // org.chromium.mojo.bindings.Struct
        public final void encode(Encoder encoder) {
            Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);
            encoder0.encode(this.objectId, 8);
        }
    }
}
